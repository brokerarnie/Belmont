import React from 'react';
import { View } from '../types';
import { Building, ShieldCheck, Home } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
}

const Footer: React.FC<Props> = ({ navigate }) => {
  return (
    <footer className="bg-slate-900 text-slate-400 py-10 px-4 border-t border-slate-800">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col items-center text-center">
          <Building className="h-6 w-6 text-blue-500 mb-2" />
          <h2 className="text-2xl font-black text-white tracking-tighter">BELMONT</h2>
          <p className="text-[10px] font-bold uppercase tracking-widest text-slate-600">Belmont Brokerage Inc.</p>
          
          <div className="mt-6 flex flex-wrap justify-center gap-x-8 gap-y-3 text-[9px] font-black uppercase tracking-[0.2em]">
            <button onClick={() => navigate(View.LEGAL)} className="hover:text-blue-400 transition">Terms of Use</button>
            <button onClick={() => navigate(View.LEGAL)} className="hover:text-blue-400 transition">Privacy Policy</button>
            <button onClick={() => navigate(View.LEGAL)} className="hover:text-red-500 transition">Compliance</button>
            <button className="hover:text-blue-400 transition">Accessibility</button>
          </div>

          <div className="mt-8 flex items-center justify-center gap-10 border-y border-slate-800 py-4 w-full max-w-4xl">
            <div className="flex items-center gap-3 opacity-60">
               <Home className="h-8 w-8 text-slate-400" />
               <div className="text-left leading-none">
                  <p className="text-[9px] font-black uppercase">Equal Housing</p>
                  <p className="text-[9px] font-black uppercase">Opportunity</p>
               </div>
            </div>
            <div className="w-px h-8 bg-slate-800 hidden sm:block"></div>
            <div className="flex items-center gap-3 opacity-60">
               <ShieldCheck className="h-8 w-8 text-slate-400" />
               <div className="text-left leading-none">
                  <p className="text-[9px] font-black uppercase">NAR Verified</p>
                  <p className="text-[9px] font-black uppercase">Brokerage</p>
               </div>
            </div>
          </div>

          <div className="mt-6 pt-4 w-full max-w-2xl">
            <p className="text-[9px] leading-relaxed opacity-50">
              © {new Date().getFullYear()} Belmont Brokerage Inc. All rights reserved. 
              DRE Corporate License #02065145. Fair Housing compliant. 
              Belmont fully supports the Equal Housing Opportunity principles. 
              Anti-Trust Notice: Commission rates are not set by law or any agency and are negotiable between Broker and Client.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;