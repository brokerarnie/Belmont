
import React, { useState, useEffect } from 'react';
import { View, User, Language, FontSize } from '../types';
import { Building, User as UserIcon, ChevronDown, LogOut, Glasses } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  onLogout: () => void;
  onToggleDarkMode: () => void;
}

const Navbar: React.FC<Props> = ({ navigate, user, onLogout, onToggleDarkMode }) => {
  const [showMenu, setShowMenu] = useState(false);
  const [showLang, setShowLang] = useState(false);
  const [showSize, setShowSize] = useState(false);
  const [time, setTime] = useState(new Date());
  const { language, setLanguage, t, fontSize, setFontSize } = useLanguage();

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const languages: { id: Language; label: string; flag: string }[] = [
    { id: 'en', label: 'English', flag: '🇺🇸' },
    { id: 'es', label: 'Español', flag: '🇲🇽' },
    { id: 'hy', label: 'Հայերեն', flag: '🇦🇲' },
    { id: 'ru', label: 'Русский', flag: '🇷🇺' },
    { id: 'ko', label: '한국어', flag: '🇰🇷' },
    { id: 'zh', label: '中文', flag: '🇨🇳' },
    { id: 'tl', label: 'Tagalog', flag: '🇵🇭' },
  ];

  const fontSizes: { id: FontSize; label: string; desc: string }[] = [
    { id: 'S', label: 'S', desc: 'Small' },
    { id: 'M', label: 'M', desc: 'Normal' },
    { id: 'L', label: 'L', desc: 'Large' },
    { id: 'XL', label: 'XL', desc: 'Extra Large' },
  ];

  const currentLangObj = languages.find(l => l.id === language) || languages[0];

  return (
    <nav className="bg-slate-900 text-white shadow-xl sticky top-0 z-50 h-24 flex items-center">
      <div className="absolute inset-0 opacity-10 pointer-events-none overflow-hidden">
        <svg className="w-full h-full" viewBox="0 0 1200 128" preserveAspectRatio="none">
          <polygon points="500,128 800,-30 1100,128" fill="white" />
          <polygon points="250,128 500,20 750,128" fill="white" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center group">
            <Building 
              className="h-10 w-10 text-blue-400 mr-4 stroke-[1.5] cursor-pointer hover:scale-110 active:scale-95 transition-transform" 
              onClick={(e) => { e.stopPropagation(); onToggleDarkMode(); }}
            />
            <div 
              className="flex flex-col cursor-pointer"
              onClick={() => navigate(View.HOME)}
            >
              <span className="font-extrabold text-3xl tracking-tighter group-hover:text-slate-200 transition">BELMONT</span>
              <div className="flex justify-between w-full text-[10px] font-mono text-blue-300 tracking-tighter uppercase mt-0.5 opacity-90">
                <span>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                <span className="text-blue-500 mx-1">|</span>
                <span>{time.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' })}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center space-x-3 sm:space-x-4">
            {/* Visual Aid Selector - Next to Flag */}
            <div className="relative">
              <button 
                onClick={() => { setShowSize(!showSize); setShowLang(false); setShowMenu(false); }} 
                className={`flex items-center justify-center bg-slate-800 hover:bg-slate-700 w-10 h-10 rounded-full transition-all border border-slate-700 text-slate-300 shadow-lg ${showSize ? 'ring-2 ring-blue-500 border-blue-500' : ''}`}
                title={`Visual Aid: ${fontSize}`}
              >
                <Glasses className="h-5 w-5" />
              </button>

              {showSize && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-2xl py-1 text-slate-800 border border-slate-200 animate-fadeIn z-[60]">
                   <div className="px-4 py-2 text-[9px] font-black text-slate-400 border-b border-slate-50 uppercase tracking-widest mb-1">Reading Level</div>
                   {fontSizes.map((size) => (
                     <button
                       key={size.id}
                       onClick={() => { setFontSize(size.id); setShowSize(false); }}
                       className={`w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center justify-between text-[11px] font-black transition-colors ${fontSize === size.id ? 'text-blue-600 bg-blue-50/50' : 'text-slate-700'}`}
                     >
                       <div className="flex items-center gap-3">
                         <Glasses className={`h-3.5 w-3.5 ${fontSize === size.id ? 'text-blue-600' : 'text-slate-400'}`} />
                         <span className="uppercase">{size.desc}</span>
                       </div>
                       <span className="text-[9px] font-mono opacity-50">[{size.label}]</span>
                     </button>
                   ))}
                </div>
              )}
            </div>

            {/* Language Selector - Flag Only */}
            <div className="relative">
              <button 
                onClick={() => { setShowLang(!showLang); setShowSize(false); setShowMenu(false); }} 
                className={`flex items-center justify-center bg-slate-800 hover:bg-slate-700 w-10 h-10 rounded-full transition-all border border-slate-700 text-lg shadow-lg ${showLang ? 'ring-2 ring-blue-500 border-blue-500' : ''}`}
                title={currentLangObj.label}
              >
                {currentLangObj.flag}
              </button>

              {showLang && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-2xl py-1 text-slate-800 border border-slate-200 animate-fadeIn z-[60]">
                   <div className="px-4 py-2 text-[9px] font-black text-slate-400 border-b border-slate-50 uppercase tracking-widest mb-1">Select Language</div>
                   {languages.map((lang) => (
                     <button
                       key={lang.id}
                       onClick={() => { setLanguage(lang.id); setShowLang(false); }}
                       className={`w-full text-left px-4 py-2 hover:bg-slate-50 flex items-center justify-between text-xs font-bold ${language === lang.id ? 'text-blue-600 bg-blue-50/50' : 'text-slate-700'}`}
                     >
                       <div className="flex items-center gap-3">
                         <span>{lang.flag}</span>
                         <span>{lang.label}</span>
                       </div>
                       {language === lang.id && <div className="w-1.5 h-1.5 bg-blue-600 rounded-full" />}
                     </button>
                   ))}
                </div>
              )}
            </div>

            <div className="relative">
              <button 
                onClick={() => { setShowMenu(!showMenu); setShowLang(false); setShowSize(false); }} 
                className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-md transition-all shadow-lg border border-blue-500"
              >
                <UserIcon className="h-4 w-4" />
                <span className="text-sm font-bold hidden sm:inline">{user ? user.name : t('login')}</span>
                <ChevronDown className={`h-4 w-4 transition-transform ${showMenu ? 'rotate-180' : ''}`} />
              </button>

              {showMenu && (
                <div className="absolute right-0 mt-2 w-56 bg-white rounded-md shadow-2xl py-1 text-slate-800 border border-slate-200 animate-fadeIn z-[60]">
                  {!user ? (
                    <>
                      <button 
                        onClick={() => { navigate(View.USER_LOGIN); setShowMenu(false); }} 
                        className="block w-full text-left px-4 py-3 hover:bg-slate-50 border-b border-slate-100"
                      >
                        <div className="font-bold text-sm">General Login</div>
                        <div className="text-[10px] text-slate-500 uppercase">Classifieds & Rentals</div>
                      </button>
                      <button 
                        onClick={() => { navigate(View.AGENT_LOGIN); setShowMenu(false); }} 
                        className="block w-full text-left px-4 py-3 hover:bg-slate-50 border-b border-slate-100"
                      >
                        <div className="font-bold text-sm text-blue-600">Agent Portal</div>
                        <div className="text-[10px] text-slate-500 uppercase">CRM & Professional Tools</div>
                      </button>
                    </>
                  ) : (
                    <>
                      {user.isAgent && (
                        <button 
                          onClick={() => { navigate(View.AGENT_PORTAL); setShowMenu(false); }} 
                          className="block w-full text-left px-4 py-3 hover:bg-slate-50 border-b border-slate-100"
                        >
                          <div className="font-bold text-sm">Dashboard</div>
                        </button>
                      )}
                      <button 
                        onClick={() => { onLogout(); setShowMenu(false); }} 
                        className="block w-full text-left px-4 py-3 hover:bg-red-50 text-red-600 flex items-center"
                      >
                        <LogOut className="h-4 w-4 mr-2" />
                        <div className="font-bold text-sm">{t('logout')}</div>
                      </button>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
