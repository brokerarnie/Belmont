
import React, { createContext, useContext, useState, ReactNode, useEffect } from 'react';
import { Language, FontSize } from '../types';
import { TRANSLATIONS } from '../translations';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  fontSize: FontSize;
  setFontSize: (size: FontSize) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => {
    return (localStorage.getItem('belmont_language') as Language) || 'en';
  });

  const [fontSize, setFontSizeState] = useState<FontSize>(() => {
    return (localStorage.getItem('belmont_font_size') as FontSize) || 'M';
  });

  useEffect(() => {
    const root = document.documentElement;
    switch (fontSize) {
      case 'S':
        root.style.fontSize = '14px';
        break;
      case 'L':
        root.style.fontSize = '20px';
        break;
      case 'XL':
        root.style.fontSize = '24px';
        break;
      default: // 'M'
        root.style.fontSize = '16px';
        break;
    }
  }, [fontSize]);

  const handleSetLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('belmont_language', lang);
  };

  const setFontSize = (size: FontSize) => {
    setFontSizeState(size);
    localStorage.setItem('belmont_font_size', size);
  };

  const t = (key: string): string => {
    return TRANSLATIONS[language][key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: handleSetLanguage, fontSize, setFontSize, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
