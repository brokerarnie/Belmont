
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const ANALYSIS_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    transcript: { type: Type.STRING, description: "Full transcription of the audio or text provided" },
    missedPoints: { type: Type.ARRAY, items: { type: Type.STRING } },
    suggestions: { type: Type.ARRAY, items: { type: Type.STRING } },
    reminders: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Specific tasks for the agent" },
    appointments: { 
      type: Type.ARRAY, 
      items: { 
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          date: { type: Type.STRING, description: "Descriptive date like 'Next Tuesday at 10am'" },
          location: { type: Type.STRING }
        },
        required: ["title", "date"]
      }
    }
  },
  required: ["transcript", "missedPoints", "suggestions", "reminders", "appointments"]
};

export const analyzeAudioOrText = async (data: { text?: string, audioBase64?: string, mimeType?: string }) => {
  try {
    const parts: any[] = [];
    
    if (data.text) {
      parts.push({ text: `Analyze this real estate interaction: ${data.text}` });
    }
    
    if (data.audioBase64 && data.mimeType) {
      parts.push({
        inlineData: {
          data: data.audioBase64,
          mimeType: data.mimeType
        }
      });
      parts.push({ text: "Transcribe this audio and analyze it for real estate tasks, missed points, and appointments." });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: ANALYSIS_SCHEMA
      }
    });
    
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Analysis error:", error);
    return null;
  }
};

export const analyzeCallTranscript = async (transcript: string) => {
  return analyzeAudioOrText({ text: transcript });
};

export const checkDesireRealism = async (desires: any) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Act as a brutal Real Estate Data Scientist. Evaluate if these client desires are realistic for the current California market (specifically San Fernando Valley/Greater LA).
      
      CLIENT DESIRES:
      Location: ${desires.locationPreference}
      Max Budget: $${desires.budgetMax}
      Beds: ${desires.minBeds}
      Baths: ${desires.minBaths}
      Features: ${desires.features?.join(', ')}
      
      Return a status (REALISTIC, UNREALISTIC, or OUT_OF_BUDGET) and a short tactical explanation.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            status: { type: Type.STRING },
            explanation: { type: Type.STRING },
            suggestedBudget: { type: Type.NUMBER },
            suggestedLocations: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["status", "explanation"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Realism check error:", error);
    return { status: "ERROR", explanation: "AI Syndicate offline." };
  }
};

export const suggestNextStepsFromNotes = async (notes: string[]) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Based on these agent notes for a client, suggest 3 concise next steps in JSON format:
      ["suggestion 1", "suggestion 2", "suggestion 3"]
      NOTES: ${notes.join(' | ')}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: { type: Type.STRING }
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Note suggestion error:", error);
    return [];
  }
};

export const generateCmaReport = async (address: string, details: string) => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `Generate a SHORT Comparative Market Analysis (CMA) for ${address}. 
      Property Specs: ${details}.
      
      STRICT REQUIREMENTS:
      1. NO Markdown. Absolutely no #, *, or _ characters. Use plain text only.
      2. Use ALL CAPS for headers.
      3. Identify 3 specific comparable properties that SOLD within the last 90 days and within a 0.5 mile radius. List their address, final sale price, and date sold.
      4. Total length must be under 250 words. Be very direct.
      5. Include a section at the very end titled CLIENT SCRIPT: followed by a 2-3 sentence message the agent can copy/paste directly to the client (Buyer/Seller) explaining the valuation clearly.
      6. Format an image URL if found as [IMAGE_URL: https://...]`,
      config: {
        tools: [{ googleSearch: {} }],
      },
    });
    return response.text;
  } catch (error) {
    console.error("CMA report error:", error);
    return "Failed to generate report. Syndicate access denied.";
  }
};

export const analyzeCompliance = async (params: { text?: string; url?: string; files?: { name: string, data: string, mimeType: string }[] }) => {
  try {
    let prompt = "Analyze the following content for real estate compliance violations in California (Fair Housing Act, Anti-Trust, etc.).\n\n";
    const parts: any[] = [];

    if (params.text) {
      prompt += `TEXT CONTENT:\n${params.text}\n\n`;
    }
    if (params.url) {
      prompt += `LISTING URL:\n${params.url}\n\n`;
    }
    
    parts.push({ text: prompt });

    if (params.files && params.files.length > 0) {
      params.files.forEach(f => {
        parts.push({
          inlineData: {
            mimeType: f.mimeType,
            data: f.data
          }
        });
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            status: { type: Type.STRING, description: "PASS, FAIL, or WARNING" },
            findings: { type: Type.ARRAY, items: { type: Type.STRING } },
            recommendations: { type: Type.ARRAY, items: { type: Type.STRING } }
          },
          required: ["status", "findings", "recommendations"]
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Compliance audit error:", error);
    return { status: "ERROR", findings: ["Failed to connect to compliance engine."], recommendations: [] };
  }
};
