
import React, { useState, useEffect, useRef } from 'react';
import { View, User } from '../types';
import { 
  MessageSquare, X, ArrowLeft, SendHorizontal, Search, MoreHorizontal, Circle, Users
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  darkMode?: boolean;
}

interface Message {
  id: string;
  sender: string;
  text: string;
  timestamp: string;
  isMe: boolean;
}

const AgentChat: React.FC<Props> = ({ navigate, user, darkMode = false }) => {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', sender: 'Belmont AI', text: 'Secure internal channel active.', timestamp: '10:00 AM', isMe: false }
  ]);
  const [inputText, setInputText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      sender: user?.name || 'Me',
      text: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      isMe: true
    };

    setMessages([...messages, newMessage]);
    setInputText('');
  };

  return (
    <div className={`min-h-[calc(100vh-6rem)] p-2 sm:p-4 flex items-center justify-center font-sans transition-colors duration-300 ${darkMode ? 'bg-slate-950' : 'bg-slate-100'}`}>
      {/* COMPACT INTERNAL CHAT WINDOW */}
      <div className={`max-w-md w-full h-[550px] flex flex-col rounded-2xl shadow-2xl overflow-hidden border transition-all ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
        
        {/* Compact Header */}
        <div className={`px-4 py-3 border-b flex items-center justify-between transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
          <div className="flex items-center gap-3">
            <button 
              onClick={() => navigate(View.AGENT_PORTAL)}
              className={`p-1.5 rounded-lg transition-all ${darkMode ? 'hover:bg-slate-800 text-slate-400 hover:text-white' : 'hover:bg-slate-100 text-slate-500 hover:text-slate-900'}`}
              title="Back"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <div>
               <h2 className={`text-[10px] font-black uppercase tracking-tight ${darkMode ? 'text-white' : 'text-slate-900'}`}>Agent Network</h2>
               <div className="flex items-center gap-1 text-emerald-500 text-[8px] font-black uppercase">
                  <div className="w-1 h-1 bg-emerald-500 rounded-full animate-pulse" /> Live
               </div>
            </div>
          </div>
          <button className={`p-1.5 rounded-lg transition-colors ${darkMode ? 'hover:bg-slate-800 text-slate-500' : 'hover:bg-slate-50 text-slate-400'}`}><MoreHorizontal className="h-4 w-4" /></button>
        </div>

        {/* Message Feed */}
        <div 
          ref={scrollRef}
          className="flex-grow p-4 overflow-y-auto space-y-4 scroll-smooth scrollbar-hide"
        >
          {messages.map((msg) => (
            <div key={msg.id} className={`flex ${msg.isMe ? 'justify-end' : 'justify-start'} group animate-message`}>
               <div className={`max-w-[90%] ${msg.isMe ? 'items-end' : 'items-start'} flex flex-col`}>
                  <div className="flex items-center gap-2 mb-0.5 px-1">
                     <span className={`text-[8px] font-black uppercase ${darkMode ? 'text-slate-600' : 'text-slate-400'}`}>{msg.sender}</span>
                     <span className="text-[7px] text-slate-500 font-mono opacity-0 group-hover:opacity-100 transition-opacity">{msg.timestamp}</span>
                  </div>
                  <div className={`px-3 py-2 rounded-xl text-[11px] font-medium leading-relaxed shadow-sm transition-all ${
                    msg.isMe 
                      ? 'bg-blue-600 text-white rounded-tr-none' 
                      : (darkMode ? 'bg-slate-800 text-slate-200 rounded-tl-none border border-slate-700' : 'bg-slate-100 text-slate-800 rounded-tl-none')
                  }`}>
                     {msg.text}
                  </div>
               </div>
            </div>
          ))}
        </div>

        {/* Compact Input Bar */}
        <div className={`p-3 border-t transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
          <form onSubmit={handleSendMessage} className="relative flex items-center gap-2">
             <input 
               type="text"
               className={`flex-grow pl-4 pr-10 py-2.5 rounded-xl border focus:outline-none font-medium text-[11px] transition-all ${
                 darkMode 
                  ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' 
                  : 'bg-slate-50 border-slate-200 text-slate-900 focus:border-blue-500'
               }`}
               placeholder="Write message..."
               value={inputText}
               onChange={(e) => setInputText(e.target.value)}
             />
             <button 
               type="submit"
               disabled={!inputText.trim()}
               className={`absolute right-1.5 top-1/2 -translate-y-1/2 p-1.5 rounded-lg transition-all ${
                 inputText.trim() 
                  ? 'bg-blue-600 text-white shadow-md' 
                  : 'text-slate-300'
               }`}
             >
                <SendHorizontal className="h-3.5 w-3.5" />
             </button>
          </form>
        </div>
      </div>

      <style>{`
        @keyframes messageIn {
          from { opacity: 0; transform: translateY(4px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-message {
          animation: messageIn 0.2s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default AgentChat;
