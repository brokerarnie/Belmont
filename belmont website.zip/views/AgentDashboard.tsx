
import React, { useState, useEffect } from 'react';
import { View, User, Language, FontSize } from '../types';
import { 
  ClipboardList, Calendar, Home, Bot, 
  MessageCircle, GraduationCap, 
  Library, UserCircle, LogOut,
  Scale, FileText, Users, Mail, ExternalLink, Edit2, BrainCircuit, LayoutGrid,
  Newspaper, TrendingUp, Coins, Info, X, ArrowUpRight, Plus, MapPin, Trash2, CheckCircle2,
  Clock, Database, ShieldCheck, Lock, ShieldAlert, RefreshCw, ChevronDown, Settings, 
  Calculator, DollarSign, FileSpreadsheet, Glasses
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  logout: () => void;
  darkMode?: boolean;
  onToggleDarkMode: () => void;
}

interface TeamEvent {
  id: string;
  title: string;
  date: string;
  time: string;
  location: string;
  type: 'physical' | 'virtual';
  isMandatory: boolean;
}

const AgentDashboard: React.FC<Props> = ({ navigate, user, logout, darkMode = false, onToggleDarkMode }) => {
  const [time, setTime] = useState(new Date());
  const [showProfitSharingInfo, setShowProfitSharingInfo] = useState(false);
  const [showTeamEvents, setShowTeamEvents] = useState(false);
  const [activeNewsUrl, setActiveNewsUrl] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [showLang, setShowLang] = useState(false);
  const [showSize, setShowSize] = useState(false);
  const { language, setLanguage, t, fontSize, setFontSize } = useLanguage();
  
  // Payout State
  const [payoutTotal, setPayoutTotal] = useState<string>(() => localStorage.getItem('belmont_profit_sharing') || '0.00');
  const [isVerifyingEdit, setIsVerifyingEdit] = useState(false);
  const [isEditingPayout, setIsEditingPayout] = useState(false);
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [editAmount, setEditAmount] = useState(payoutTotal);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const [teamEvents, setTeamEvents] = useState<TeamEvent[]>([
    { id: '1', title: 'Q1 Sales Strategy Sync', date: '2025-02-15', time: '09:00 AM', location: 'Main Boardroom', type: 'physical', isMandatory: true },
    { id: '2', title: 'New Compliance Workshop', date: '2025-02-18', time: '11:30 AM', location: 'Zoom Link: belmont.vc/meeting', type: 'virtual', isMandatory: true },
    { id: '3', title: 'Belmont Spring Mixer', date: '2025-03-01', time: '06:00 PM', location: 'Topanga Sky Lounge', type: 'physical', isMandatory: false }
  ]);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const triggerToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const isOwner = user?.email === 'brokerarnie@gmail.com';
  const agentId = user?.id || 'PRO-001';

  const startPayoutEdit = () => {
    setIsVerifyingEdit(true);
    setOtp(['', '', '', '', '', '']);
    setError(null);
  };

  const handleOtpChange = (value: string, index: number) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    if (value && index < 5) document.getElementById(`otp-edit-${index + 1}`)?.focus();
  };

  const verifyForEdit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      if (otp.join('') === '123456') {
        setIsVerifyingEdit(false);
        setIsEditingPayout(true);
      } else {
        setError("Invalid security code.");
        setOtp(['', '', '', '', '', '']);
        document.getElementById('otp-edit-0')?.focus();
      }
    }, 1000);
  };

  const publishPayout = () => {
    const num = parseFloat(editAmount).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    localStorage.setItem('belmont_profit_sharing', num);
    setPayoutTotal(num);
    setIsEditingPayout(false);
    triggerToast("Published to Main Site");
  };

  const languages: { id: Language; label: string; flag: string }[] = [
    { id: 'en', label: 'English', flag: '🇺🇸' },
    { id: 'es', label: 'Español', flag: '🇲🇽' },
    { id: 'hy', label: 'Հայերեն', flag: '🇦🇲' },
    { id: 'ru', label: 'Русский', flag: '🇷🇺' },
    { id: 'ko', label: '한국어', flag: '🇰🇷' },
    { id: 'zh', label: '中文', flag: '🇨🇳' },
    { id: 'tl', label: 'Tagalog', flag: '🇵🇭' },
  ];

  const fontSizes: { id: FontSize; label: string; desc: string }[] = [
    { id: 'S', label: 'S', desc: 'Small' },
    { id: 'M', label: 'M', desc: 'Normal' },
    { id: 'L', label: 'L', desc: 'Large' },
    { id: 'XL', label: 'XL', desc: 'Extra Large' },
  ];

  const currentLangObj = languages.find(l => l.id === language) || languages[0];

  const newsItems = [
    { text: `GLOBAL ALERT: Total Belmont Profit Sharing Pool updated to $${payoutTotal}`, url: "#" },
    { text: "MARKET REPORT: San Fernando Valley inventory sees 12% increase in luxury listings.", url: "#" },
    { text: "COMPLIANCE ALERT: Updated disclosure requirements for all specialist transfers.", url: "#" },
    { text: "BELMONT NEWS: Professional referral bonuses increased for Q1 - Check MyMont.", url: "#" },
    { text: "INTEREST RATES: Fed signals potential pause as inflation stabilizes at 2.1%.", url: "#" }
  ];

  return (
    <div className={`min-h-screen font-sans transition-colors duration-300 pb-12 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      {toast && (
        <div className="fixed top-24 right-8 z-[100] animate-fadeIn">
          <div className="bg-[#436ca1] text-white px-6 py-3 border-2 border-white shadow-2xl flex items-center gap-3">
             <div className="bg-white/20 p-1 rounded-full"><CheckCircle2 className="h-4 w-4" /></div>
             <span className="text-xs font-black uppercase tracking-widest">{toast}</span>
          </div>
        </div>
      )}

      <header className="py-4 px-8 flex items-center justify-between bg-black border-b border-slate-800 text-white sticky top-0 z-50 shadow-2xl">
        <div className="flex items-center space-x-6">
          <button 
            onClick={onToggleDarkMode}
            className="text-amber-500 hover:scale-110 active:scale-95 transition-all transform duration-200 focus:outline-none flex items-center justify-center p-1 rounded-full hover:bg-white/5"
            title="Toggle Dark Mode"
          >
            <UserCircle className="h-10 w-10" strokeWidth={1.5} />
          </button>

          <div className="flex flex-col">
            <div className="flex items-baseline space-x-2">
              <button 
                onClick={() => navigate(View.AGENT_PORTAL)}
                className="text-amber-500 font-black text-2xl tracking-tighter hover:text-amber-400 transition-colors"
              >
                BELMONT
              </button>
              <span className="text-slate-400 font-mono text-sm uppercase opacity-80">{agentId}</span>
            </div>
            <div className="flex items-center space-x-2 text-[10px] font-mono text-amber-500/80 uppercase">
              <span>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
              <span className="text-slate-700">|</span>
              <span>{time.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3 sm:space-x-4">
          {/* Visual Aid Selector - Adjacent to Language */}
          <div className="relative">
            <button 
              onClick={() => { setShowSize(!showSize); setShowLang(false); }} 
              className={`flex items-center justify-center bg-slate-900 hover:bg-slate-800 w-10 h-10 rounded-full transition-all border border-slate-800 text-slate-300 shadow-lg ${showSize ? 'ring-2 ring-amber-500 border-amber-500' : ''}`}
              title={`Reading Level: ${fontSize}`}
            >
              <Glasses className="h-5 w-5" />
            </button>

            {showSize && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-2xl py-1 text-slate-800 border border-slate-200 animate-fadeIn z-[60]">
                 <div className="px-4 py-2 text-[9px] font-black text-slate-400 border-b border-slate-50 uppercase tracking-widest mb-1">Reading Level</div>
                 {fontSizes.map((size) => (
                   <button
                     key={size.id}
                     onClick={() => { setFontSize(size.id); setShowSize(false); }}
                     className={`w-full text-left px-4 py-2.5 hover:bg-slate-50 flex items-center justify-between text-[11px] font-black transition-colors ${fontSize === size.id ? 'text-blue-600 bg-blue-50/50' : 'text-slate-700'}`}
                   >
                     <div className="flex items-center gap-3">
                       <Glasses className={`h-3.5 w-3.5 ${fontSize === size.id ? 'text-blue-600' : 'text-slate-400'}`} />
                       <span className="uppercase">{size.desc}</span>
                     </div>
                     <span className="text-[9px] font-mono opacity-50">[{size.label}]</span>
                   </button>
                 ))}
              </div>
            )}
          </div>

          {/* Language Selector - Flag Only */}
          <div className="relative">
            <button 
              onClick={() => { setShowLang(!showLang); setShowSize(false); }} 
              className={`flex items-center justify-center bg-slate-900 hover:bg-slate-800 w-10 h-10 rounded-full transition-all border border-slate-800 text-lg shadow-lg ${showLang ? 'ring-2 ring-amber-500 border-amber-500' : ''}`}
              title={currentLangObj.label}
            >
              {currentLangObj.flag}
            </button>

            {showLang && (
              <div className="absolute right-0 mt-2 w-48 bg-white rounded-md shadow-2xl py-1 text-slate-800 border border-slate-200 animate-fadeIn z-[60]">
                 <div className="px-4 py-2 text-[9px] font-black text-slate-400 border-b border-slate-50 uppercase tracking-widest mb-1">Select Language</div>
                 {languages.map((lang) => (
                   <button
                     key={lang.id}
                     onClick={() => { setLanguage(lang.id); setShowLang(false); }}
                     className={`w-full text-left px-4 py-2 hover:bg-slate-50 flex items-center justify-between text-xs font-bold ${language === lang.id ? 'text-blue-600 bg-blue-50/50' : 'text-slate-700'}`}
                   >
                     <div className="flex items-center gap-3">
                       <span>{lang.flag}</span>
                       <span>{lang.label}</span>
                     </div>
                     {language === lang.id && <div className="w-1.5 h-1.5 bg-blue-600 rounded-full" />}
                   </button>
                 ))}
              </div>
            )}
          </div>

          <button 
            onClick={() => navigate(View.SETTINGS)}
            className="p-2 bg-slate-900 hover:bg-slate-800 text-slate-300 rounded-full transition-colors border border-slate-700"
            title="Account Settings"
          >
            <Settings className="h-5 w-5" />
          </button>

          {user?.isVerified && (
            <div className="bg-emerald-500/10 border border-emerald-500/30 p-1.5 rounded-full" title="Session Verified (2FA Active)">
               <ShieldCheck className="h-5 w-5 text-emerald-500" />
            </div>
          )}
          <button 
            onClick={logout}
            className="px-5 py-2 rounded-md font-bold text-xs transition border bg-slate-900 hover:bg-slate-800 text-slate-100 border-slate-700 uppercase"
          >
            {t('logout')}
          </button>
        </div>
      </header>

      {/* Cleaner ticker without fixed label */}
      <div className={`w-full overflow-hidden whitespace-nowrap py-1.5 border-b shadow-sm flex items-center relative z-40 transition-colors ${darkMode ? 'bg-blue-900/40 border-blue-800 text-blue-100' : 'bg-[#2563eb] border-blue-700 text-white'}`}>
        <div className="flex animate-scroll-text hover:[animation-play-state:paused] cursor-default">
          {[...newsItems, ...newsItems].map((item, i) => (
            <span key={i} className="inline-flex items-center px-8 text-[11px] font-bold tracking-tight group">
              <span className="opacity-50 mr-4 font-mono">[{new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}]</span>
              {item.text}
              <button 
                onClick={() => setActiveNewsUrl(item.text)}
                className="ml-4 w-6 h-6 bg-white/20 hover:bg-white/40 border border-white/30 rounded flex items-center justify-center transition-all shadow-sm active:scale-90 group-hover:border-white"
                title="View Full Story"
              >
                <ArrowUpRight className="h-3 w-3 text-white" />
              </button>
              <span className="ml-8 text-white/30">•</span>
            </span>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-8 pt-10">
        <div className="flex items-center justify-between mb-10">
          <div className="flex items-center gap-4">
            <h1 className={`text-3xl font-black tracking-tight transition-colors ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>{t('dashboard')}</h1>
            <div className="bg-red-500/10 border border-red-500/30 px-3 py-1 rounded-full flex items-center gap-2">
               <ShieldCheck className="h-3 w-3 text-red-500" />
               <span className="text-[8px] font-black text-red-500 uppercase tracking-widest">Compliance Monitor Active</span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* CORE TOOLS */}
          <section className={`rounded-xl shadow-sm border overflow-hidden flex flex-col transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
            <div className={`px-5 py-3 border-b flex justify-between items-center transition-colors ${darkMode ? 'bg-slate-800/50 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>
              <h2 className={`text-xs font-black uppercase tracking-widest ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>{t('coreTools')}</h2>
              <UserCircle className={`h-4 w-4 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`} />
            </div>
            <div className="p-6 space-y-4">
              <button onClick={() => navigate(View.AGENT_CRM)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
                <ClipboardList className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>{t('crm')}</span>
              </button>
              <button onClick={() => navigate(View.AGENT_CALENDAR)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
                <Calendar className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>{t('calendar')}</span>
              </button>
              <button onClick={() => navigate(View.AGENT_AI_CMA)} className={`flex items-center space-x-3 text-sm font-black w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-amber-400 hover:text-amber-300' : 'text-amber-700 hover:underline'}`}>
                <Bot className={`h-4 w-4 ${darkMode ? 'text-amber-400' : 'text-amber-500'}`} /> <span>{t('aiAnalysis')}</span>
              </button>
              <button onClick={() => navigate(View.AGENT_NET_SHEET)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-emerald-400 hover:text-emerald-300' : 'text-emerald-700 hover:underline'}`}>
                <FileSpreadsheet className={`h-4 w-4 ${darkMode ? 'text-emerald-400' : 'text-emerald-500'}`} /> <span>{t('netSheet')}</span>
              </button>
              <button onClick={() => navigate(View.AGENT_COMMISSION_CALC)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
                <Calculator className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>{t('commissionHub')}</span>
              </button>
              <button onClick={() => navigate(View.AGENT_COMPLIANCE_AUDIT)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-red-400 hover:text-red-300' : 'text-red-700 hover:underline'}`}>
                <Scale className={`h-4 w-4 ${darkMode ? 'text-red-400' : 'text-red-500'}`} /> <span>{t('complianceAudit')}</span>
              </button>
            </div>
          </section>

          {/* PROJECT & PIPELINE */}
          <section className={`rounded-xl shadow-sm border overflow-hidden flex flex-col transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
            <div className={`px-5 py-3 border-b flex justify-between items-center transition-colors ${darkMode ? 'bg-slate-800/50 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>
              <h2 className={`text-xs font-black uppercase tracking-widest ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>{t('projectPipeline')}</h2>
              <Home className={`h-4 w-4 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`} />
            </div>
            <div className="p-6 space-y-4">
              <button onClick={() => navigate(View.AGENT_LISTINGS)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
                <Home className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>{t('inventory')}</span>
              </button>
              <button onClick={() => navigate(View.AGENT_LEADS)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
                <Users className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>{t('leadGen')}</span>
              </button>
            </div>
          </section>

          {/* NETWORK & GROWTH */}
          <section className={`rounded-xl shadow-sm border overflow-hidden flex flex-col transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
            <div className={`px-5 py-3 border-b flex justify-between items-center transition-colors ${darkMode ? 'bg-slate-800/50 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>
              <h2 className={`text-xs font-black uppercase tracking-widest ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>{t('networkGrowth')}</h2>
              <LayoutGrid className={`h-4 w-4 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`} />
            </div>
            <div className="p-6 space-y-4">
              <div className="relative group">
                <button 
                  onClick={() => setShowProfitSharingInfo(true)}
                  className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 p-1 rounded-lg ${darkMode ? 'text-emerald-400 hover:bg-emerald-500/10' : 'text-emerald-700 hover:bg-emerald-50'}`}
                >
                  <Coins className={`h-5 w-5 ${darkMode ? 'text-emerald-400' : 'text-emerald-600'}`} /> 
                  <div className="flex flex-col">
                     <span className="font-black uppercase text-[12px] tracking-tight">{t('payouts')}</span>
                     <span className="text-[10px] font-black text-emerald-500 bg-emerald-500/10 px-1.5 py-0.5 rounded-sm w-fit mt-0.5">POOL: ${payoutTotal}</span>
                  </div>
                </button>
              </div>
              <button 
                onClick={() => setShowTeamEvents(true)}
                className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
                <Users className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> 
                <div className="flex flex-col">
                   <span>{t('syncs')}</span>
                   <span className="text-[9px] font-bold opacity-60">Next: {teamEvents[0]?.title || 'TBD'}</span>
                </div>
              </button>
              <button onClick={() => navigate(View.AGENT_CHAT)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
                <MessageCircle className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>{t('internalChat')}</span>
              </button>
            </div>
          </section>

          {/* DEVELOPMENT */}
          <section className={`rounded-xl shadow-sm border overflow-hidden flex flex-col transition-colors ${darkMode ? 'bg-slate-950 border-slate-800' : 'bg-white border-slate-100'}`}>
            <div className={`px-5 py-3 border-b flex justify-between items-center transition-colors ${darkMode ? 'bg-slate-800/50 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>
              <h2 className={`text-xs font-black uppercase tracking-widest ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>{t('development')}</h2>
              <BrainCircuit className={`h-4 w-4 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`} />
            </div>
            <div className="p-6 space-y-4">
              <button onClick={() => navigate(View.AGENT_QUIZ)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
                <GraduationCap className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>{t('iqQuiz')}</span>
              </button>
              <button onClick={() => navigate(View.AGENT_LIBRARY)} className={`flex items-center space-x-3 text-sm font-medium w-full text-left transition-all hover:bg-opacity-10 group ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
                <Library className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>{t('library')}</span>
              </button>
            </div>
          </section>
        </div>

        {/* BOOKMARKS SECTION */}
        <div className={`mt-12 rounded-xl shadow-sm border p-8 transition-colors ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-100'}`}>
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-3">
               <h3 className={`text-lg font-black tracking-tight ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>{t('toolbelt')}</h3>
               <span className="bg-blue-600/10 text-blue-500 text-[8px] font-black uppercase tracking-widest px-1.5 py-0.5 rounded-full border border-blue-500/20">Authorized Professionals</span>
            </div>
          </div>
          <div className="flex flex-wrap gap-x-10 gap-y-4">
            <a href="https://www.car.org/" target="_blank" rel="noreferrer" className={`flex items-center space-x-2 text-sm font-medium transition-all ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
              <ExternalLink className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>CAR.org</span>
            </a>
            <a href="https://ladbs.org/" target="_blank" rel="noreferrer" className={`flex items-center space-x-2 text-sm font-medium transition-all ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
              <ExternalLink className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>LADBS Docs</span>
            </a>
            <button onClick={() => navigate(View.AGENT_FILE_ARCHIVE)} className={`flex items-center space-x-2 text-sm font-medium transition-all ${darkMode ? 'text-blue-400 hover:text-blue-300' : 'text-blue-700 hover:underline'}`}>
              <Database className={`h-4 w-4 ${darkMode ? 'text-blue-400' : 'text-blue-500'}`} /> <span>Belmont Vault</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentDashboard;
