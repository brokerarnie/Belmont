
import React, { useState, useMemo, useRef } from 'react';
import { View, Contact, Task, Appointment } from '../types';
import { analyzeAudioOrText, checkDesireRealism } from '../services/gemini';
import { 
  Search, UserPlus, Mail, Phone, ArrowLeft, 
  X, Mic, Square, BrainCircuit, Zap, Plus,
  Upload, PhoneCall, ShieldCheck, Loader2,
  Calendar, ClipboardList, CheckCircle2, MoreVertical
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  contacts: Contact[];
  setContacts?: React.Dispatch<React.SetStateAction<Contact[]>>;
  darkMode?: boolean;
}

type Tab = 'people' | 'tasks' | 'deals';
type SmartList = 'all' | 'today' | 'hot' | 'closings';
type ClientTab = 'profile' | 'desires' | 'notes' | 'intelligence';

const CRM: React.FC<Props> = ({ navigate, contacts, setContacts, darkMode = false }) => {
  const [activeTab, setActiveTab] = useState<Tab>('people');
  const [activeSmartList, setActiveSmartList] = useState<SmartList>('all');
  const [selectedContactId, setSelectedContactId] = useState<number | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddLeadModal, setShowAddLeadModal] = useState(false);
  const [showToast, setShowToast] = useState(false);
  const [toastMsg, setToastMsg] = useState('');
  
  const [activeClientTab, setActiveClientTab] = useState<ClientTab>('profile');
  const [isRecording, setIsRecording] = useState(false);
  const [analyzingCall, setAnalyzingCall] = useState(false);
  const [isCheckingRealism, setIsCheckingRealism] = useState(false);
  const [realismResult, setRealismResult] = useState<any>(null);
  const [isPasting, setIsPasting] = useState(false);
  const [pastedText, setPastedText] = useState('');

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);

  const triggerToast = (msg: string) => {
    setToastMsg(msg);
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
  };

  const selectedContact = useMemo(() => 
    contacts.find(c => c.id === selectedContactId), 
  [contacts, selectedContactId]);

  const processAnalysisResult = (analysis: any) => {
    if (!analysis || !selectedContactId || !setContacts) return;

    const newTasks: Task[] = (analysis.reminders || []).map((r: string) => ({
      id: Math.random().toString(),
      title: r,
      dueDate: 'Today',
      completed: false
    }));

    const newAppointments: Appointment[] = (analysis.appointments || []).map((app: any) => ({
      id: Math.random().toString(),
      title: app.title,
      date: app.date,
      location: app.location || 'Office'
    }));

    setContacts(prev => prev.map(c => {
      if (c.id !== selectedContactId) return c;
      return {
        ...c,
        status: 'Hot',
        lastCheckIn: 'Just now',
        calls: [{
          id: Date.now().toString(),
          timestamp: new Date().toLocaleString(),
          duration: '--',
          transcript: analysis.transcript,
          aiAnalysis: analysis
        }, ...(c.calls || [])],
        tasks: [...(c.tasks || []), ...newTasks],
        appointments: [...(c.appointments || []), ...newAppointments]
      };
    }));

    setAnalyzingCall(false);
    triggerToast("Synthesis Complete");
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const reader = new FileReader();
        reader.readAsDataURL(audioBlob);
        reader.onloadend = async () => {
          const base64Audio = (reader.result as string).split(',')[1];
          setAnalyzingCall(true);
          const result = await analyzeAudioOrText({ audioBase64: base64Audio, mimeType: 'audio/webm' });
          processAnalysisResult(result);
        };
      };

      mediaRecorder.start();
      setIsRecording(true);
      triggerToast("Recording Active");
    } catch (err) {
      triggerToast("Mic Access Denied");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const handlePasteProcess = async () => {
    if (!pastedText.trim()) return;
    setAnalyzingCall(true);
    const result = await analyzeAudioOrText({ text: pastedText });
    processAnalysisResult(result);
    setIsPasting(false);
    setPastedText('');
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setAnalyzingCall(true);
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onloadend = async () => {
      const base64 = (reader.result as string).split(',')[1];
      const result = await analyzeAudioOrText({ audioBase64: base64, mimeType: file.type });
      processAnalysisResult(result);
    };
  };

  const filtered = useMemo(() => {
    const listFilter = {
      all: (c: Contact) => true,
      today: (c: Contact) => c.lastCheckIn === 'Today',
      hot: (c: Contact) => c.status === 'Hot',
      closings: (c: Contact) => c.status === 'Sold'
    }[activeSmartList];

    return contacts.filter(c => {
      const matchesSearch = c.name.toLowerCase().includes(searchTerm.toLowerCase());
      return listFilter(c) && matchesSearch;
    });
  }, [contacts, searchTerm, activeSmartList]);

  return (
    <div className="min-h-screen flex flex-col font-sans selection:bg-black selection:text-white bg-white text-black">
      
      {/* MONOCHROME TOAST */}
      {showToast && (
        <div className="fixed top-20 right-4 z-[100] animate-fadeIn">
          <div className="bg-black text-white px-6 py-2.5 border-2 border-white shadow-[6px_6px_0px_black] flex items-center gap-3">
             <span className="text-[10px] font-black uppercase tracking-widest">{toastMsg}</span>
          </div>
        </div>
      )}

      {/* STARK HEADER */}
      <header className="bg-black text-white px-8 py-5 flex items-center justify-between sticky top-0 z-[60] border-b border-white/10">
        <div className="flex items-center gap-12">
           <button onClick={() => navigate(View.AGENT_PORTAL)} className="p-1 hover:bg-white/10 transition-colors">
              <ArrowLeft className="h-6 w-6 text-white" />
           </button>
           <nav className="flex gap-10">
              {['people', 'tasks', 'deals'].map(id => (
                <button 
                  key={id}
                  onClick={() => { setActiveTab(id as Tab); setSelectedContactId(null); }}
                  className={`text-[11px] font-black uppercase tracking-[0.2em] transition-all ${activeTab === id && !selectedContactId ? 'text-white border-b-2 border-white pb-1' : 'text-white/40 hover:text-white'}`}
                >
                   {id}
                </button>
              ))}
           </nav>
        </div>

        <div className="flex items-center gap-6">
           <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-white/40" />
              <input 
                placeholder="DATABASE SEARCH..." 
                className="bg-white/10 border-none rounded-none py-2.5 pl-12 pr-6 text-[10px] font-black tracking-widest focus:ring-1 focus:ring-white w-64 transition-all"
                value={searchTerm}
                onChange={e => setSearchTerm(e.target.value)}
              />
           </div>
           <button onClick={() => setShowAddLeadModal(true)} className="px-6 py-2.5 bg-white text-black font-black uppercase text-[10px] tracking-widest hover:invert active:scale-95 transition-all shadow-[4px_4px_0px_rgba(255,255,255,0.2)]">
              Register New Lead
           </button>
        </div>
      </header>

      <div className="flex-grow flex overflow-hidden">
        
        {/* MONOCHROME SIDEBAR */}
        <aside className="w-72 border-r-2 border-black shrink-0 flex flex-col p-8 space-y-10 bg-white">
          <section>
            <h3 className="text-[10px] font-black uppercase tracking-widest mb-8 opacity-40">Registry Filters</h3>
            <div className="space-y-2">
              <SideBtn active={activeSmartList === 'all'} onClick={() => { setActiveSmartList('all'); setSelectedContactId(null); }} label="Master Index" count={contacts.length} />
              <SideBtn active={activeSmartList === 'today'} onClick={() => { setActiveSmartList('today'); setSelectedContactId(null); }} label="Active Today" count={contacts.filter(c => c.lastCheckIn === 'Today').length} />
              <SideBtn active={activeSmartList === 'hot'} onClick={() => { setActiveSmartList('hot'); setSelectedContactId(null); }} label="Priority One" count={contacts.filter(c => c.status === 'Hot').length} />
              <SideBtn active={activeSmartList === 'closings'} onClick={() => { setActiveSmartList('closings'); setSelectedContactId(null); }} label="Closed Records" count={contacts.filter(c => c.status === 'Sold').length} />
            </div>
          </section>
        </aside>

        {/* WORKSPACE */}
        <main className="flex-grow overflow-y-auto p-12 scrollbar-hide bg-[#FFFFFF]">
          
          {selectedContact ? (
            <div className="max-w-4xl mx-auto animate-fadeIn space-y-12">
               {/* Contact Hero */}
               <div className="flex items-center justify-between border-b-4 border-black pb-8">
                  <div className="flex items-center gap-8">
                     <div className="w-20 h-20 bg-black text-white flex items-center justify-center text-4xl font-black shadow-[8px_8px_0px_rgba(0,0,0,0.1)]">
                        {selectedContact.name[0]}
                     </div>
                     <div>
                        <h2 className="text-4xl font-black uppercase tracking-tighter">{selectedContact.name}</h2>
                        <div className="flex gap-6 mt-2 text-[12px] font-black uppercase tracking-widest opacity-60">
                           <span className="flex items-center gap-2"><Mail className="h-3.5 w-3.5" /> {selectedContact.email}</span>
                           <span className="flex items-center gap-2"><Phone className="h-3.5 w-3.5" /> {selectedContact.phone}</span>
                        </div>
                     </div>
                  </div>
                  <button onClick={() => setSelectedContactId(null)} className="p-3 border-4 border-black hover:bg-black hover:text-white transition-all shadow-[6px_6px_0px_black] active:translate-x-1 active:translate-y-1 active:shadow-none">
                     <X className="h-6 w-6" />
                  </button>
               </div>

               <nav className="flex gap-12 border-b-2 border-black/10">
                  {['profile', 'desires', 'notes', 'intelligence'].map(tab => (
                    <button 
                      key={tab}
                      onClick={() => setActiveClientTab(tab as ClientTab)}
                      className={`pb-4 text-[11px] font-black uppercase tracking-[0.25em] transition-all border-b-4 ${activeClientTab === tab ? 'border-black text-black' : 'border-transparent opacity-30 hover:opacity-100'}`}
                    >
                      {tab}
                    </button>
                  ))}
               </nav>

               <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
                  <div className="lg:col-span-8 space-y-12">
                     {activeClientTab === 'profile' && (
                        <div className="space-y-12 animate-fadeIn">
                           
                           {/* Interaction Audit Card - Now with Inline Synthesis */}
                           <section className="p-10 border-4 border-black space-y-10 bg-white relative overflow-hidden shadow-[12px_12px_0px_black]">
                              {analyzingCall && (
                                <div className="absolute inset-0 z-50 bg-white/95 flex flex-col items-center justify-center animate-fadeIn border-4 border-black">
                                  <div className="flex items-center gap-4 mb-3">
                                    <Loader2 className="h-8 w-8 animate-spin text-black" />
                                    <span className="text-sm font-black uppercase tracking-[0.2em]">Synthesis Active...</span>
                                  </div>
                                  <div className="w-1/2 h-1.5 bg-black/10 overflow-hidden">
                                     <div className="h-full bg-black animate-[progress_2s_infinite_linear]"></div>
                                  </div>
                                </div>
                              )}

                              <div className="flex items-center gap-8">
                                 <button 
                                    onClick={isRecording ? stopRecording : startRecording}
                                    className={`p-6 border-4 border-black transition-all ${isRecording ? 'bg-black text-white animate-pulse' : 'bg-white text-black hover:bg-black hover:text-white'}`}
                                 >
                                    {isRecording ? <Square className="h-8 w-8" /> : <Mic className="h-8 w-8" />}
                                 </button>
                                 <div>
                                    <h3 className="font-black text-2xl uppercase tracking-tighter">Interaction Audit</h3>
                                    <p className="text-[10px] font-bold uppercase tracking-[0.3em] opacity-40">Knowledge Extraction Module</p>
                                 </div>
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                 <div className="p-8 border-4 border-dashed border-black/20 hover:border-black transition-all group">
                                    {isPasting ? (
                                       <div className="space-y-4">
                                          <textarea 
                                             className="w-full p-4 text-[11px] font-bold bg-transparent border-2 border-black focus:ring-0 resize-none h-40 uppercase"
                                             placeholder="PASTE VERBATIM LOG..."
                                             value={pastedText}
                                             onChange={e => setPastedText(e.target.value)}
                                          />
                                          <div className="flex justify-end gap-4">
                                             <button onClick={() => setIsPasting(false)} className="text-[10px] font-black uppercase opacity-40 hover:opacity-100 transition-opacity">Cancel</button>
                                             <button onClick={handlePasteProcess} className="px-6 py-2 bg-black text-white text-[10px] font-black uppercase">Process</button>
                                          </div>
                                       </div>
                                    ) : (
                                       <button onClick={() => setIsPasting(true)} className="w-full h-full flex flex-col items-center justify-center gap-4 py-6">
                                          <Plus className="h-6 w-6 group-hover:rotate-90 transition-transform" />
                                          <span className="text-[10px] font-black uppercase tracking-widest">Manual Entry</span>
                                       </button>
                                    )}
                                 </div>

                                 <div className="p-8 border-4 border-dashed border-black/20 hover:border-black transition-all flex flex-col items-center justify-center text-center">
                                    <label className="cursor-pointer group flex flex-col items-center gap-4 w-full h-full justify-center">
                                       <Upload className="h-6 w-6 group-hover:-translate-y-2 transition-transform" />
                                       <span className="text-[10px] font-black uppercase tracking-widest">Upload Audio Log</span>
                                       <input type="file" className="hidden" accept="audio/*" onChange={handleFileUpload} />
                                    </label>
                                 </div>
                              </div>
                           </section>

                           <div className="space-y-8">
                              <h3 className="text-[11px] font-black uppercase tracking-[0.4em] opacity-40">Audit Trail</h3>
                              {selectedContact.calls?.map(call => (
                                 <div key={call.id} className="p-10 border-4 border-black bg-white space-y-8 animate-fadeIn shadow-[8px_8px_0px_black]">
                                    <div className="flex items-center justify-between border-b-2 border-black pb-6">
                                       <div className="flex items-center gap-4">
                                          <div className="p-3 bg-black text-white"><PhoneCall className="h-5 w-5" /></div>
                                          <div>
                                             <h4 className="text-sm font-black uppercase tracking-widest">{call.timestamp}</h4>
                                             <p className="text-[9px] font-mono text-slate-400 mt-1 uppercase">UUID_{call.id.slice(-8).toUpperCase()}</p>
                                          </div>
                                       </div>
                                       <button className="p-2 border-2 border-black hover:bg-black hover:text-white transition-all"><MoreVertical className="h-4 w-4" /></button>
                                    </div>
                                    <div className="p-8 bg-black text-white font-mono text-xs leading-relaxed border-l-[12px] border-black shadow-inner italic opacity-90">
                                       {call.transcript}
                                    </div>
                                    <div className="grid grid-cols-2 gap-12">
                                       <div className="space-y-6">
                                          <p className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-black pb-2">Synthesis: Unresolved</p>
                                          <div className="space-y-3">
                                            {call.aiAnalysis.missedPoints.map((p, i) => (
                                              <p key={i} className="text-[11px] font-bold leading-tight flex items-start gap-2">
                                                <span className="shrink-0">•</span> {p}
                                              </p>
                                            ))}
                                          </div>
                                       </div>
                                       <div className="space-y-6">
                                          <p className="text-[10px] font-black uppercase tracking-[0.2em] border-b-2 border-black pb-2">Synthesis: Tasks</p>
                                          <div className="space-y-3">
                                            {call.aiAnalysis.reminders.map((r, i) => (
                                              <p key={i} className="text-[11px] font-bold leading-tight flex items-start gap-2">
                                                <CheckCircle2 className="h-3.5 w-3.5 shrink-0 text-emerald-500" /> {r}
                                              </p>
                                            ))}
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              ))}
                              {!selectedContact.calls?.length && (
                                 <div className="py-32 text-center border-4 border-dashed border-black/10 opacity-20">
                                    <p className="text-[11px] font-black uppercase tracking-[0.3em]">Awaiting Knowledge Acquisition</p>
                                 </div>
                              )}
                           </div>
                        </div>
                     )}

                     {activeClientTab === 'intelligence' && (
                        <div className="p-32 text-center border-4 border-dashed border-black/10 opacity-30 animate-pulse">
                           <BrainCircuit className="h-20 w-20 mx-auto mb-8" />
                           <p className="text-[12px] font-black uppercase tracking-[0.6em]">Neural Graph Processing</p>
                        </div>
                     )}
                  </div>

                  {/* SIDEBAR CONTEXT - Strictly Monochromatic */}
                  <div className="lg:col-span-4 space-y-12">
                     <div className="p-8 border-4 border-black bg-white space-y-8 shadow-[8px_8px_0px_black]">
                        <div className="flex items-center justify-between border-b-2 border-black pb-4">
                           <h4 className="text-[11px] font-black uppercase tracking-[0.3em]">Agenda</h4>
                           <ClipboardList className="h-4 w-4" />
                        </div>
                        <div className="space-y-4">
                           {(selectedContact.tasks || []).map(t => (
                              <div key={t.id} className="flex items-center gap-4 p-4 border-2 border-black bg-white hover:bg-slate-50 transition-colors cursor-pointer group">
                                 <div className={`w-4 h-4 border-2 border-black transition-all ${t.completed ? 'bg-black' : 'bg-white group-hover:bg-black/10'}`} />
                                 <span className="text-[11px] font-black uppercase truncate">{t.title}</span>
                              </div>
                           ))}
                        </div>
                        <button className="w-full py-4 border-2 border-dashed border-black text-[10px] font-black uppercase tracking-widest hover:bg-black hover:text-white transition-all">Append Task</button>
                     </div>

                     <div className="p-8 border-4 border-black bg-white space-y-8 shadow-[8px_8px_0px_black]">
                        <div className="flex items-center justify-between border-b-2 border-black pb-4">
                           <h4 className="text-[11px] font-black uppercase tracking-[0.3em]">Calendar</h4>
                           <Calendar className="h-4 w-4" />
                        </div>
                        <div className="space-y-5">
                           {(selectedContact.appointments || []).map(a => (
                              <div key={a.id} className="p-5 border-4 border-black bg-white hover:bg-black hover:text-white transition-all cursor-default group shadow-[4px_4px_0px_black]">
                                 <p className="text-[11px] font-black uppercase truncate mb-2">{a.title}</p>
                                 <div className="flex justify-between items-center opacity-60 font-mono text-[9px] font-black uppercase">
                                    <span>{a.date}</span>
                                    <span className="group-hover:text-white">ID_{a.id.slice(-4).toUpperCase()}</span>
                                 </div>
                              </div>
                           ))}
                        </div>
                     </div>
                  </div>
               </div>
            </div>
          ) : (
            <div className="animate-fadeIn">
               <div className="bg-white border-[6px] border-black overflow-hidden shadow-[16px_16px_0px_black]">
                  <table className="w-full text-left border-collapse">
                     <thead className="bg-black text-white text-[11px] font-black uppercase tracking-[0.4em]">
                        <tr>
                           <th className="px-10 py-8 border-r border-white/20">Identity Identifier</th>
                           <th className="px-10 py-8 border-r border-white/20">Engagement Level</th>
                           <th className="px-10 py-8 border-r border-white/20">Last Interaction</th>
                           <th className="px-10 py-8 text-right">Audit</th>
                        </tr>
                     </thead>
                     <tbody className="divide-y-[6px] divide-black">
                        {filtered.map(contact => (
                           <tr key={contact.id} onClick={() => setSelectedContactId(contact.id)} className="hover:bg-black hover:text-white transition-colors cursor-pointer group bg-white">
                              <td className="px-10 py-10 border-r border-current">
                                 <div className="font-black text-xl uppercase tracking-tighter">{contact.name}</div>
                                 <div className="text-[11px] font-black opacity-60 mt-2 uppercase tracking-widest">{contact.email}</div>
                              </td>
                              <td className="px-10 py-10 border-r border-current">
                                 <span className="px-6 py-2.5 border-[6px] border-current text-[11px] font-black uppercase tracking-[0.3em]">
                                    {contact.status}
                                 </span>
                              </td>
                              <td className="px-10 py-10 border-r border-current text-[12px] font-black uppercase tracking-widest">{contact.lastCheckIn}</td>
                              <td className="px-10 py-10 text-right">
                                 <button className="p-5 border-[6px] border-current hover:bg-white hover:text-black transition-all active:scale-90 shadow-[6px_6px_0px_currentColor]">
                                    <Mic className="h-7 w-7" />
                                 </button>
                              </td>
                           </tr>
                        ))}
                     </tbody>
                  </table>
                  {filtered.length === 0 && (
                    <div className="py-40 text-center opacity-20">
                       <Zap className="h-20 w-20 mx-auto mb-6" />
                       <p className="text-xl font-black uppercase tracking-[0.5em]">No matching records found</p>
                    </div>
                  )}
               </div>
            </div>
          )}
        </main>
      </div>

      {/* MODAL: REGISTRY ENTRY */}
      {showAddLeadModal && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-8 bg-black/98 backdrop-blur-xl animate-fadeIn">
          <div className="max-w-xl w-full border-[10px] border-white bg-black p-16 relative shadow-[24px_24px_0px_rgba(255,255,255,0.1)]">
            <button onClick={() => setShowAddLeadModal(false)} className="absolute top-8 right-8 text-white hover:rotate-90 transition-transform"><X className="h-10 w-10" /></button>
            <div className="flex flex-col items-center gap-6 mb-12 text-center">
               <UserPlus className="h-16 w-16 text-white" />
               <h3 className="text-4xl font-black uppercase tracking-tighter text-white">Identity Registration</h3>
               <p className="text-[10px] font-bold uppercase tracking-[0.5em] text-white/40">Enter into the Master Index</p>
            </div>
            <div className="space-y-8">
               <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-white/60 ml-2">Formal Identifier</label>
                  <input className="w-full p-6 bg-white text-black font-black uppercase tracking-widest text-sm border-none focus:ring-[6px] focus:ring-white/30" placeholder="FULL NAME" />
               </div>
               <div className="space-y-2">
                  <label className="text-[9px] font-black uppercase tracking-widest text-white/60 ml-2">Network Address</label>
                  <input className="w-full p-6 bg-white text-black font-black uppercase tracking-widest text-sm border-none focus:ring-[6px] focus:ring-white/30" placeholder="EMAIL ADDRESS" />
               </div>
               <button onClick={() => { setShowAddLeadModal(false); triggerToast("Record Indexed"); }} className="w-full py-8 bg-white text-black font-black uppercase tracking-[0.4em] text-xs hover:invert transition-all active:scale-95 shadow-2xl">Confirm Registration</button>
            </div>
          </div>
        </div>
      )}

      <style>{`
        @keyframes progress {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
      `}</style>
    </div>
  );
};

const SideBtn = ({ active, label, count, onClick }: any) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center justify-between p-5 transition-all font-black text-[13px] uppercase tracking-widest border-4 border-black ${active ? 'bg-black text-white shadow-[8px_8px_0px_black] -translate-x-1 -translate-y-1' : 'bg-white text-black hover:bg-slate-50'}`}
  >
    <span>{label}</span>
    <span className={`text-[11px] px-3 py-1 font-black border-2 border-black ${active ? 'bg-white/20 border-white' : 'bg-black/5'}`}>{count}</span>
  </button>
);

export default CRM;
