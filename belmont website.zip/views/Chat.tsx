
import React, { useState, useEffect, useRef } from 'react';
import { View, User } from '../types';
import { 
  X, ArrowLeft, Users, Minus, Square, 
  SendHorizontal, Search, MoreHorizontal,
  Circle, Smile, Link as LinkIcon
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  darkMode?: boolean;
}

interface Message {
  id: string;
  sender: string;
  text: string;
  timestamp: string;
  color?: string;
}

const Chat: React.FC<Props> = ({ navigate, user, darkMode = false }) => {
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', sender: 'Belmont_Bot', text: 'Welcome to the public chat. Start a conversation!', timestamp: '10:00 AM', color: '#008800' }
  ]);
  const [inputText, setInputText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;

    const newMessage: Message = {
      id: Date.now().toString(),
      sender: user?.name || 'Guest_' + Math.floor(Math.random() * 900),
      text: inputText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      color: darkMode ? '#ffffff' : '#000000'
    };

    setMessages([...messages, newMessage]);
    setInputText('');
  };

  const buddies = [
    { name: 'Belmont_Bot', status: 'online' }
  ];

  return (
    <div className={`min-h-[calc(100vh-6rem)] p-2 sm:p-4 flex items-center justify-center font-sans transition-colors duration-300 overflow-hidden ${darkMode ? 'bg-slate-900' : 'bg-[#fff5cc]'}`}>
      {/* REDUCED SIZE AOL-STYLE WINDOW */}
      <div className={`w-full max-w-2xl h-[70vh] sm:h-[500px] flex flex-col shadow-[6px_6px_0px_rgba(0,0,0,0.2)] border-2 transition-all ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-[#ece9d8] border-[#8da4b7]'}`}>
        
        {/* AOL Header Strip */}
        <div className={`flex items-center justify-between p-1.5 transition-colors ${darkMode ? 'bg-slate-700' : 'bg-gradient-to-r from-[#000080] to-[#1084d0] text-white'}`}>
          <div className="flex items-center gap-2 overflow-hidden">
            <div className="w-4 h-4 bg-white/20 rounded-full flex items-center justify-center shrink-0">
              <Circle className="w-2.5 h-2.5 fill-white" />
            </div>
            <span className="text-[9px] sm:text-[10px] font-black uppercase tracking-tight truncate">Belmont Community Chat</span>
          </div>
          <div className="flex gap-1 shrink-0">
            <button className={`w-4 h-4 border flex items-center justify-center text-[10px] font-bold ${darkMode ? 'bg-slate-600 border-slate-500' : 'bg-[#ece9d8] text-black border-white shadow-sm'}`}><Minus className="w-2.5 h-2.5" /></button>
            <button className={`w-4 h-4 border flex items-center justify-center text-[10px] font-bold ${darkMode ? 'bg-slate-600 border-slate-500' : 'bg-[#ece9d8] text-black border-white shadow-sm'}`}><Square className="w-2.5 h-2.5" /></button>
            <button onClick={() => navigate(View.HOME)} className={`w-4 h-4 border flex items-center justify-center text-[10px] font-bold ${darkMode ? 'bg-red-900/40 border-red-800' : 'bg-[#ece9d8] text-black border-white shadow-sm hover:bg-red-500 hover:text-white transition-colors'}`}><X className="w-2.5 h-2.5" /></button>
          </div>
        </div>

        {/* Main Content Area */}
        <div className="flex-grow flex p-1.5 sm:p-2 gap-1.5 sm:gap-2 overflow-hidden">
          
          {/* Chat Stream */}
          <div className={`flex-grow flex flex-col border shadow-inner transition-colors ${darkMode ? 'bg-slate-950 border-slate-700' : 'bg-white border-[#aca899]'}`}>
             <div 
               ref={scrollRef}
               className="flex-grow p-2 sm:p-3 overflow-y-auto font-serif"
             >
                {messages.map((msg) => (
                  <div key={msg.id} className="mb-0.5 text-[11px] sm:text-[12px]">
                    <span className="font-bold mr-1.5" style={{ color: msg.color || 'inherit' }}>{msg.sender}:</span>
                    <span className={darkMode ? 'text-slate-300' : 'text-slate-800'}>{msg.text}</span>
                  </div>
                ))}
             </div>

             {/* Toolbar - Just Emojis */}
             <div className={`p-1 border-t flex gap-2 transition-colors ${darkMode ? 'bg-slate-900 border-slate-700' : 'bg-[#ece9d8] border-[#aca899]'}`}>
                <button className="p-0.5 hover:bg-white/10 rounded transition-colors"><Smile className="w-3.5 h-3.5 text-slate-500" /></button>
                <div className={`w-px h-full ${darkMode ? 'bg-slate-700' : 'bg-[#aca899]'}`} />
                <select className={`text-[9px] px-1 bg-transparent border-none focus:outline-none font-bold ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  <option>Arial</option>
                  <option>Times</option>
                </select>
             </div>

             {/* Message Input */}
             <form onSubmit={handleSendMessage} className="p-1.5 flex gap-1.5">
                <input 
                  type="text"
                  className={`flex-grow p-1.5 text-xs border focus:outline-none transition-colors ${
                    darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-[#aca899]'
                  }`}
                  placeholder="Chat here..."
                  value={inputText}
                  onChange={(e) => setInputText(e.target.value)}
                  autoFocus
                />
                <button 
                  type="submit"
                  className={`px-3 sm:px-4 py-1.5 text-[9px] font-black uppercase border shadow-sm active:scale-95 transition-all ${
                    darkMode ? 'bg-blue-900/40 border-blue-800 text-blue-300' : 'bg-gradient-to-b from-white to-[#d6d3c1] border-[#aca899] text-slate-800'
                  }`}
                >
                  Send
                </button>
             </form>
          </div>

          {/* Compact Buddy List Sidebar */}
          <div className={`hidden sm:flex w-32 flex-col border shadow-inner transition-colors ${darkMode ? 'bg-slate-950 border-slate-700' : 'bg-white border-[#aca899]'}`}>
            <div className={`p-1.5 font-black text-[9px] uppercase border-b text-center tracking-widest ${darkMode ? 'bg-slate-900 border-slate-700 text-slate-500' : 'bg-[#f0f0f0] border-[#aca899] text-slate-600'}`}>
               Buddies
            </div>
            <div className="flex-grow p-1.5 space-y-1 overflow-y-auto">
               {buddies.map((buddy, i) => (
                 <div key={i} className="flex items-center gap-1.5 group cursor-pointer">
                    <div className={`w-1 h-1 rounded-full ${buddy.status === 'online' ? 'bg-green-500' : 'bg-slate-300'}`} />
                    <span className={`text-[10px] font-bold group-hover:underline ${darkMode ? 'text-slate-400' : 'text-slate-700'}`}>{buddy.name}</span>
                 </div>
               ))}
            </div>
          </div>

        </div>

        {/* Compact Status Bar */}
        <div className={`px-3 py-1 border-t text-[9px] font-mono flex justify-between transition-colors ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-[#ece9d8] border-[#aca899] text-slate-500'}`}>
          <span>CONNECTED: 56.6K</span>
          <span className="truncate ml-2">© Belmont</span>
        </div>
      </div>
      
      {/* Back Button Overlay */}
      <button 
        onClick={() => navigate(View.HOME)}
        className="fixed bottom-4 right-4 bg-slate-900 text-white px-4 py-2 rounded-full font-black uppercase text-[9px] tracking-widest flex items-center gap-2 shadow-2xl hover:scale-105 active:scale-95 transition-all z-[100]"
      >
        <ArrowLeft className="w-3 h-3" /> Exit
      </button>
    </div>
  );
};

export default Chat;
