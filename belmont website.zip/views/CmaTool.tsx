
import React, { useState, useMemo } from 'react';
import { View } from '../types';
import { generateCmaReport } from '../services/gemini';
import { Bot, Home, ArrowLeft, Copy, Printer, ShieldCheck, TrendingUp, ExternalLink, MessageSquare, CheckCircle2, RefreshCw } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

const CmaTool: React.FC<Props> = ({ navigate, darkMode = false }) => {
  const { t } = useLanguage();
  const [address, setAddress] = useState('');
  const [details, setDetails] = useState({ beds: '', baths: '', sqft: '' });
  const [loading, setLoading] = useState(false);
  const [report, setReport] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const triggerToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!address) return;
    setLoading(true);
    const detailStr = `${details.beds}BR, ${details.baths}BA, ${details.sqft} sqft`;
    const res = await generateCmaReport(address, detailStr);
    setReport(res);
    setLoading(false);
  };

  const linkify = (text: string) => {
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    return text.split(urlRegex).map((part, i) => {
      if (part.match(urlRegex)) {
        return (
          <a 
            key={i} 
            href={part} 
            target="_blank" 
            rel="noopener noreferrer" 
            className="text-blue-500 hover:text-blue-400 underline inline-flex items-center gap-1 font-bold"
          >
            {part.length > 40 ? part.substring(0, 40) + '...' : part}
            <ExternalLink className="h-3 w-3" />
          </a>
        );
      }
      return part;
    });
  };

  const parsedData = useMemo(() => {
    if (!report) return { imageUrl: null, cleanText: null, agentScript: null };
    
    const imgRegex = /\[IMAGE_URL:\s*(https?:\/\/[^\]]+)\]/i;
    const match = report.match(imgRegex);
    const imageUrl = match ? match[1] : null;
    let fullText = report.replace(imgRegex, '').trim();
    
    const scriptMarker = /CLIENT SCRIPT:/i;
    const parts = fullText.split(scriptMarker);
    
    let cleanText = parts[0].replace(/[#*_]/g, '').trim();
    let agentScript = parts[1] ? parts[1].replace(/[#*_]/g, '').trim() : null;
    
    return { imageUrl, cleanText, agentScript };
  }, [report]);

  const handleCopyReport = () => {
    if (parsedData.cleanText) {
      navigator.clipboard.writeText(parsedData.cleanText);
      triggerToast("Report Copied to Clipboard");
    }
  };

  const handleCopyScript = () => {
    if (parsedData.agentScript) {
      navigator.clipboard.writeText(parsedData.agentScript);
      triggerToast("Client Script Copied");
    }
  };

  return (
    <div className={`min-h-[calc(100vh-6rem)] py-8 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      
      {toast && (
        <div className="fixed top-24 right-8 z-[100] animate-fadeIn">
          <div className="bg-[#436ca1] text-white px-6 py-3 border-2 border-white shadow-2xl flex items-center gap-3 rounded-lg">
             <CheckCircle2 className="h-4 w-4" />
             <span className="text-[10px] font-black uppercase tracking-widest">{toast}</span>
          </div>
        </div>
      )}

      <div className="max-w-6xl mx-auto">
        <button 
          onClick={() => navigate(View.AGENT_PORTAL)} 
          className={`flex items-center font-bold mb-8 group transition-all text-[10px] uppercase tracking-widest ${darkMode ? 'text-slate-400 hover:text-slate-100' : 'text-slate-50 hover:text-slate-800'}`}
        >
          <div className={`p-2 rounded-full mr-3 shadow-sm group-hover:shadow transition border ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white'}`}>
            <ArrowLeft className="h-3 w-3" />
          </div>
          {t('exit')} to {t('dashboard')}
        </button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-1">
            <div className={`p-8 rounded-3xl shadow-xl border sticky top-28 transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <div className="flex items-center space-x-3 mb-8">
                <div className="p-3 bg-blue-600 rounded-2xl shadow-lg shadow-blue-500/30">
                  <Bot className="h-6 w-6 text-white" />
                </div>
                <div>
                  <h2 className={`text-xl font-black tracking-tight ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>{t('cmaTitle')}</h2>
                  <p className={`text-[10px] font-bold uppercase tracking-widest ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>90-Day / 0.5mi Scan Active</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label className={`block text-[10px] font-black uppercase tracking-widest mb-2 text-slate-500`}>{t('address')}</label>
                  <input 
                    className={`w-full p-4 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-black text-sm transition-colors ${
                      darkMode ? 'bg-slate-950 border-slate-800 text-white placeholder:text-slate-700' : 'bg-slate-50 border-slate-200 text-slate-900'
                    }`} 
                    placeholder="Enter full address..."
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className={`block text-[10px] font-black uppercase tracking-widest mb-2 text-slate-500`}>{t('beds')}</label>
                    <input 
                      type="number"
                      className={`w-full p-4 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-black text-sm transition-colors ${
                        darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                      }`} 
                      value={details.beds}
                      onChange={(e) => setDetails({ ...details, beds: e.target.value })}
                    />
                  </div>
                  <div>
                    <label className={`block text-[10px] font-black uppercase tracking-widest mb-2 text-slate-500`}>{t('baths')}</label>
                    <input 
                      type="number"
                      className={`w-full p-4 border rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 font-black text-sm transition-colors ${
                        darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-200 text-slate-900'
                      }`} 
                      value={details.baths}
                      onChange={(e) => setDetails({ ...details, baths: e.target.value })}
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={loading || !address}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest transition-all shadow-xl shadow-blue-500/20 disabled:opacity-50 flex items-center justify-center gap-3"
                >
                  {loading ? (
                    <><RefreshCw className="h-4 w-4 animate-spin" /> Fetching...</>
                  ) : (
                    "Fetch Recent Comps"
                  )}
                </button>
              </form>
            </div>
          </div>

          <div className="lg:col-span-2">
            {report ? (
              <div className={`p-10 rounded-3xl shadow-2xl border animate-fadeIn min-h-[600px] flex flex-col transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
                <div className={`flex justify-between items-start mb-8 border-b pb-6 ${darkMode ? 'border-slate-800' : 'border-slate-100'}`}>
                  <div>
                    <h3 className={`text-2xl font-black tracking-tighter uppercase ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>Valuation Summary</h3>
                    <div className="flex items-center gap-2 mt-1">
                       <p className={`font-bold text-xs ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>{address}</p>
                       <span className="flex items-center gap-1 text-[8px] font-black uppercase text-emerald-500 border border-emerald-500/30 px-1.5 py-0.5 rounded">
                         <ShieldCheck className="h-2 w-2" /> Verified Closed Comps
                       </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={handleCopyReport} className={`p-3 rounded-xl transition border shadow-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`} title="Copy Report">
                      <Copy className="h-5 w-5" />
                    </button>
                    <button className={`p-3 rounded-xl transition border shadow-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white' : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'}`} title="Print">
                      <Printer className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                <div className="flex-grow">
                  <div className={`whitespace-pre-wrap font-bold leading-relaxed text-sm tracking-tight ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                    {linkify(parsedData.cleanText || '')}
                  </div>
                </div>

                {parsedData.agentScript && (
                   <div className={`mt-8 p-6 rounded-3xl border-2 border-dashed transition-colors ${darkMode ? 'bg-slate-950 border-blue-900/40' : 'bg-blue-50 border-blue-100'}`}>
                      <div className="flex justify-between items-center mb-4">
                         <div className="flex items-center gap-2 text-blue-600 font-black text-[10px] uppercase tracking-widest">
                            <MessageSquare className="h-4 w-4" /> Client Script (Buyer/Seller)
                         </div>
                         <button 
                          onClick={handleCopyScript}
                          className="bg-blue-600 text-white px-4 py-2 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-blue-700 shadow-lg transition-all active:scale-95"
                         >
                            <Copy className="h-3 w-3" /> Copy Script
                         </button>
                      </div>
                      <p className={`text-xs italic leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-blue-800'}`}>
                        "{parsedData.agentScript}"
                      </p>
                   </div>
                )}

                <div className={`mt-8 p-6 rounded-3xl border flex items-center justify-between transition-colors ${darkMode ? 'bg-slate-800/50 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>
                  <div className="flex items-center space-x-4">
                    <div className={`p-3 rounded-xl bg-blue-600 shadow-lg`}>
                      <TrendingUp className={`h-4 w-4 text-white`} />
                    </div>
                    <div>
                       <span className={`text-[9px] font-black tracking-[0.2em] uppercase ${darkMode ? 'text-blue-400' : 'text-blue-600'}`}>Syndicate Intelligence Analysis</span>
                       <p className={`text-[10px] font-bold text-slate-500`}>Processed within .5mi radius limit.</p>
                    </div>
                  </div>
                  <button onClick={() => setReport(null)} className="px-6 py-3 rounded-xl bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest hover:bg-black transition-all">Reset Search</button>
                </div>
              </div>
            ) : (
              <div className={`rounded-3xl border-4 border-dashed h-full min-h-[600px] flex flex-col items-center justify-center p-12 text-center transition-colors ${darkMode ? 'bg-slate-900 border-slate-800 opacity-80' : 'bg-slate-100 border-slate-200 opacity-60'}`}>
                <div className={`p-8 rounded-full shadow-2xl mb-8 ${darkMode ? 'bg-slate-800' : 'bg-white'}`}>
                  <Home className={`h-16 w-16 ${darkMode ? 'text-slate-600' : 'text-slate-300'}`} />
                </div>
                <h3 className={`text-2xl font-black tracking-tight mb-4 ${darkMode ? 'text-slate-500' : 'text-slate-400 uppercase'}`}>{t('cmaTitle')}</h3>
                <p className={`max-w-sm font-bold text-sm leading-relaxed ${darkMode ? 'text-slate-600' : 'text-slate-400'}`}>
                  Enter a subject address to pull 3 comparable sold properties within a .5 mile radius from the last 90 days.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CmaTool;
