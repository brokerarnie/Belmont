
import React, { useState, useMemo } from 'react';
import { View } from '../types';
import { ArrowLeft, Calculator, DollarSign, ShieldCheck, TrendingUp, Zap, ChevronRight, X } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

const CommissionCalculator: React.FC<Props> = ({ navigate, darkMode = false }) => {
  const { t } = useLanguage();
  const [salePrice, setSalePrice] = useState<string>('850000');
  const [commissionRate, setCommissionRate] = useState<string>('2.5');

  const results = useMemo(() => {
    const price = parseFloat(salePrice) || 0;
    const rate = parseFloat(commissionRate) || 0;
    const totalCommission = price * (rate / 100);
    const belmontFee = totalCommission * 0.12;
    const agentNet = totalCommission * 0.88;

    return {
      total: totalCommission,
      fee: belmontFee,
      net: agentNet
    };
  }, [salePrice, commissionRate]);

  return (
    <div className={`min-h-screen py-10 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      <div className="max-w-4xl mx-auto">
        <button 
          onClick={() => navigate(View.AGENT_PORTAL)} 
          className={`flex items-center font-bold mb-8 text-[10px] uppercase tracking-widest transition-all border px-3 py-1 rounded-sm ${
            darkMode ? 'text-slate-400 border-slate-700 bg-slate-900 hover:bg-slate-800' : 'text-slate-50 border-slate-300 bg-white hover:text-slate-700 shadow-sm'
          }`}
        >
          <ArrowLeft className="h-3 w-3 mr-2" /> {t('dashboard')}
        </button>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-black tracking-tighter uppercase flex items-center gap-3">
              <Calculator className="h-10 w-10 text-blue-600" />
              {t('commissionHub')}
            </h1>
            <p className={`text-[10px] font-black uppercase tracking-[0.3em] mt-2 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
              Belmont 88/12 Split Verification Tool
            </p>
          </div>
          <div className="bg-blue-600/10 border border-blue-600/30 px-4 py-2 rounded-2xl flex items-center gap-3">
             <ShieldCheck className="h-5 w-5 text-blue-500" />
             <span className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Official Split Policy</span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5 space-y-6">
            <div className={`p-8 rounded-[32px] border shadow-xl transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
               <div className="space-y-6">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block">Property Sale Price ($)</label>
                    <div className="relative">
                      <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                      <input 
                        type="number"
                        className={`w-full pl-12 pr-4 py-4 border-2 rounded-2xl focus:outline-none transition-all font-black text-xl ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-100 text-slate-900'}`}
                        value={salePrice}
                        onChange={(e) => setSalePrice(e.target.value)}
                      />
                    </div>
                  </div>

                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block">Agent Commission (%)</label>
                    <div className="relative">
                      <TrendingUp className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                      <input 
                        type="number"
                        step="0.1"
                        className={`w-full pl-12 pr-4 py-4 border-2 rounded-2xl focus:outline-none transition-all font-black text-xl ${darkMode ? 'bg-slate-950 border-slate-800 text-blue-500' : 'bg-slate-50 border-slate-100 text-blue-600'}`}
                        value={commissionRate}
                        onChange={(e) => setCommissionRate(e.target.value)}
                      />
                    </div>
                  </div>
               </div>

               <div className="mt-8 p-4 bg-blue-600/5 rounded-2xl border border-blue-600/10">
                  <p className="text-[9px] font-bold text-blue-600 uppercase tracking-widest leading-relaxed">
                    Calculations reflect the Belmont standard 88/12 split. Professional payout is distributed via Direct Deposit upon escrow funding verification.
                  </p>
               </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className={`p-10 rounded-[40px] border shadow-2xl animate-fadeIn transition-colors h-full flex flex-col justify-between ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
               <div>
                  <h3 className="text-xl font-black uppercase tracking-tighter mb-8 pb-4 border-b border-black/5 dark:border-white/5">{t('payoutBreakdown')}</h3>
                  
                  <div className="space-y-8">
                     <div className="flex justify-between items-center group">
                        <div>
                           <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Gross Commission</p>
                           <p className={`text-2xl font-black transition-colors ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>${results.total.toLocaleString(undefined, {minimumFractionDigits: 2})}</p>
                        </div>
                        <ChevronRight className="h-5 w-5 text-slate-200 group-hover:text-blue-500 transition-colors" />
                     </div>

                     <div className="flex justify-between items-center group">
                        <div>
                           <p className="text-[10px] font-black text-red-500 uppercase tracking-widest">Belmont 12% Fee</p>
                           <p className="text-2xl font-black text-red-600">-${results.fee.toLocaleString(undefined, {minimumFractionDigits: 2})}</p>
                        </div>
                        <X className="h-5 w-5 text-red-100" />
                     </div>

                     <div className={`p-8 rounded-3xl border-4 border-double transition-colors text-center ${darkMode ? 'bg-slate-950 border-emerald-900/40' : 'bg-emerald-50 border-emerald-100'}`}>
                        <p className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-2">Net Agent Payout (88%)</p>
                        <div className="text-5xl font-black text-emerald-600 tracking-tighter">
                          ${results.net.toLocaleString(undefined, {minimumFractionDigits: 2})}
                        </div>
                        <div className="mt-4 flex items-center justify-center gap-2">
                           <Zap className="h-4 w-4 text-emerald-500" />
                           <span className="text-[9px] font-black uppercase text-emerald-600 tracking-widest">Ready for Disbursement</span>
                        </div>
                     </div>
                  </div>
               </div>

               <div className="mt-10 pt-6 border-t border-black/5 dark:border-white/5 text-center">
                  <p className="text-[9px] font-black uppercase text-slate-400 tracking-[0.2em]">
                     BELMONT_PAYROLL_v4.0 // ACCURACY_VERIFIED: 100%
                  </p>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommissionCalculator;
