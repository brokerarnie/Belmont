
import React, { useState, useRef } from 'react';
import { View } from '../types';
import { analyzeCompliance } from '../services/gemini';
import { 
  ArrowLeft, Gavel, ShieldCheck, ShieldAlert, Shield, 
  Search, RefreshCw, Scale, AlertTriangle, CheckCircle2, 
  Upload, Link as LinkIcon, FileText, X, ImageIcon, Trash2
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

type InputType = 'text' | 'file' | 'url';

const ComplianceAuditView: React.FC<Props> = ({ navigate, darkMode = false }) => {
  const [activeInput, setActiveInput] = useState<InputType>('text');
  const [textToAudit, setTextToAudit] = useState('');
  const [urlToAudit, setUrlToAudit] = useState('');
  const [files, setFiles] = useState<{ name: string, data: string, mimeType: string }[]>([]);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{status: string, findings: string[], recommendations: string[]} | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = e.target.files;
    if (!selectedFiles) return;

    // Explicitly cast to File[] to fix 'unknown' type errors for property access and arguments
    (Array.from(selectedFiles) as File[]).forEach(file => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = (reader.result as string).split(',')[1];
        // Fix for Error: Property 'name'/'type' does not exist on type 'unknown'
        setFiles(prev => [...prev, { name: file.name, data: base64, mimeType: file.type }]);
      };
      // Fix for Error: Argument of type 'unknown' is not assignable to parameter of type 'Blob'
      reader.readAsDataURL(file);
    });
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleAudit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    const params: any = {};
    if (activeInput === 'text') params.text = textToAudit;
    if (activeInput === 'url') params.url = urlToAudit;
    if (activeInput === 'file') params.files = files;

    const auditResult = await analyzeCompliance(params);
    setResult(auditResult);
    setLoading(false);
  };

  return (
    <div className={`min-h-screen py-10 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f4f7f9] text-slate-900'}`}>
      <div className="max-w-6xl mx-auto">
        <button 
          onClick={() => navigate(View.AGENT_PORTAL)} 
          className={`flex items-center font-bold mb-8 text-[10px] uppercase tracking-widest transition-all border px-3 py-1 rounded-sm ${
            darkMode ? 'text-slate-400 border-slate-700 bg-slate-900 hover:bg-slate-800' : 'text-slate-500 border-slate-300 bg-white hover:text-slate-700 shadow-sm'
          }`}
        >
          <ArrowLeft className="h-3 w-3 mr-2" /> DASHBOARD
        </button>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
           <div>
              <h1 className="text-4xl font-black tracking-tighter uppercase flex items-center gap-3">
                 <Scale className="h-10 w-10 text-blue-600" />
                 Compliance AI Audit
              </h1>
              <p className={`text-[10px] font-black uppercase tracking-[0.3em] mt-2 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                 Multimodal Fair Housing & Anti-Trust Guard v2.0
              </p>
           </div>
           <div className={`p-4 rounded-2xl border-2 border-dashed flex items-center gap-3 transition-colors ${darkMode ? 'bg-blue-900/10 border-blue-900/30' : 'bg-blue-50 border-blue-100'}`}>
              <ShieldCheck className="h-6 w-6 text-blue-500" />
              <div className="text-[10px] font-black uppercase tracking-widest text-blue-500 leading-tight">
                 Broker Authorized<br/>Scanning Service
              </div>
           </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-7">
            <div className={`rounded-[40px] border shadow-xl transition-colors overflow-hidden ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              {/* Tabs for Input Selection */}
              <div className={`flex border-b transition-colors ${darkMode ? 'border-slate-800 bg-slate-800/30' : 'border-slate-100 bg-slate-50'}`}>
                <button 
                  onClick={() => setActiveInput('text')}
                  className={`flex-1 py-4 text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${activeInput === 'text' ? 'text-blue-500 border-b-2 border-blue-500' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  <FileText className="h-4 w-4" /> Text
                </button>
                <button 
                  onClick={() => setActiveInput('file')}
                  className={`flex-1 py-4 text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${activeInput === 'file' ? 'text-blue-500 border-b-2 border-blue-500' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  <Upload className="h-4 w-4" /> File / Signatures
                </button>
                <button 
                  onClick={() => setActiveInput('url')}
                  className={`flex-1 py-4 text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${activeInput === 'url' ? 'text-blue-500 border-b-2 border-blue-500' : 'text-slate-400 hover:text-slate-600'}`}
                >
                  <LinkIcon className="h-4 w-4" /> Link / URL
                </button>
              </div>

              <div className="p-8">
                <form onSubmit={handleAudit} className="space-y-6">
                  {activeInput === 'text' && (
                    <div className="space-y-2 animate-fadeIn">
                      <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Paste Listing Content</label>
                      <textarea 
                        required
                        rows={10}
                        className={`w-full p-6 border-2 rounded-3xl focus:outline-none transition-all text-sm font-medium leading-relaxed ${
                          darkMode ? 'bg-slate-950 border-slate-800 text-white focus:border-blue-600' : 'bg-slate-50 border-slate-100 text-slate-800 focus:border-blue-500'
                        }`}
                        placeholder="Paste script or listing here..."
                        value={textToAudit}
                        onChange={e => setTextToAudit(e.target.value)}
                      />
                    </div>
                  )}

                  {activeInput === 'file' && (
                    <div className="space-y-4 animate-fadeIn">
                      <div 
                        onClick={() => fileInputRef.current?.click()}
                        className={`border-4 border-dashed rounded-[40px] p-12 text-center cursor-pointer transition-all hover:bg-blue-500/5 ${darkMode ? 'border-slate-800' : 'border-slate-100'}`}
                      >
                         <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" multiple accept="image/*,application/pdf" />
                         <Upload className={`h-12 w-12 mx-auto mb-4 ${darkMode ? 'text-slate-700' : 'text-slate-200'}`} />
                         <h3 className="font-black text-sm uppercase tracking-widest mb-1">Click to Upload</h3>
                         <p className="text-[10px] font-bold text-slate-400 uppercase">Documents, Signature Pages, or Listing Photos</p>
                      </div>

                      {files.length > 0 && (
                        <div className="grid grid-cols-2 gap-3 mt-4">
                          {files.map((f, i) => (
                            <div key={i} className={`p-3 rounded-xl border flex items-center justify-between gap-3 ${darkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-50 border-slate-100'}`}>
                               <div className="flex items-center gap-2 overflow-hidden">
                                  <ImageIcon className="h-4 w-4 text-blue-500 shrink-0" />
                                  <span className="text-[10px] font-bold truncate">{f.name}</span>
                               </div>
                               <button type="button" onClick={() => removeFile(i)} className="text-red-500 hover:text-red-600"><Trash2 className="h-3 w-3" /></button>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {activeInput === 'url' && (
                    <div className="space-y-2 animate-fadeIn">
                      <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Paste Live Listing URL</label>
                      <input 
                        required
                        type="url"
                        className={`w-full p-6 border-2 rounded-3xl focus:outline-none transition-all text-sm font-medium ${
                          darkMode ? 'bg-slate-950 border-slate-800 text-white focus:border-blue-600' : 'bg-slate-50 border-slate-100 text-slate-800 focus:border-blue-500'
                        }`}
                        placeholder="https://www.zillow.com/homedetails/..."
                        value={urlToAudit}
                        onChange={e => setUrlToAudit(e.target.value)}
                      />
                      <p className="text-[9px] font-bold text-slate-500 uppercase mt-2 ml-1">AI will fetch and analyze live website content for compliance.</p>
                    </div>
                  )}
                  
                  <button 
                    type="submit"
                    disabled={loading || (activeInput === 'text' && !textToAudit.trim()) || (activeInput === 'file' && files.length === 0) || (activeInput === 'url' && !urlToAudit.trim())}
                    className="w-full py-5 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black uppercase tracking-[0.2em] text-xs shadow-xl shadow-blue-500/20 active:scale-95 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                  >
                    {loading ? <RefreshCw className="h-5 w-5 animate-spin" /> : <><Search className="h-5 w-5" /> Run Legal Audit</>}
                  </button>
                </form>
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            {result ? (
              <div className={`p-8 rounded-[40px] border shadow-2xl animate-fadeIn transition-colors h-full flex flex-col ${
                result.status === 'PASS' ? (darkMode ? 'bg-emerald-950/20 border-emerald-900/40' : 'bg-emerald-50 border-emerald-100') :
                result.status === 'FAIL' ? (darkMode ? 'bg-red-950/20 border-red-900/40' : 'bg-red-50 border-red-100') :
                (darkMode ? 'bg-amber-950/20 border-amber-900/40' : 'bg-amber-50 border-amber-100')
              }`}>
                <div className="flex items-center justify-between mb-8 pb-4 border-b border-black/5 dark:border-white/5">
                   <h3 className="text-xl font-black uppercase tracking-tighter">Audit Result</h3>
                   <div className={`px-4 py-1.5 rounded-full text-[10px] font-black border-2 ${
                     result.status === 'PASS' ? 'bg-emerald-500 text-white border-emerald-600' :
                     result.status === 'FAIL' ? 'bg-red-600 text-white border-red-700' :
                     'bg-amber-500 text-white border-amber-600'
                   }`}>
                     {result.status}
                   </div>
                </div>

                <div className="space-y-8 flex-grow">
                   <section>
                      <h4 className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-4 flex items-center gap-2">
                        {result.status === 'FAIL' ? <ShieldAlert className="h-4 w-4 text-red-500" /> : <Shield className="h-4 w-4 text-blue-500" />}
                        Identified Issues
                      </h4>
                      <ul className="space-y-3">
                         {result.findings.map((f, i) => (
                           <li key={i} className="text-xs font-bold leading-relaxed flex items-start gap-2">
                              <AlertTriangle className="h-3 w-3 mt-0.5 text-amber-500 shrink-0" />
                              {f}
                           </li>
                         ))}
                         {result.findings.length === 0 && (
                           <li className="text-xs font-bold text-emerald-600 flex items-center gap-2">
                              <CheckCircle2 className="h-4 w-4" /> No violations detected.
                           </li>
                         )}
                      </ul>
                   </section>

                   <section>
                      <h4 className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-4">Recommendations</h4>
                      <ul className="space-y-3">
                         {result.recommendations.map((r, i) => (
                           <li key={i} className="text-xs font-medium leading-relaxed opacity-80">
                              - {r}
                           </li>
                         ))}
                      </ul>
                   </section>
                </div>

                <div className="mt-10 pt-6 border-t border-black/5 dark:border-white/5">
                   <p className="text-[9px] font-black uppercase text-slate-400 text-center tracking-[0.2em]">
                      SCAN_ID: {Math.random().toString(36).substr(2, 9).toUpperCase()} // COMPLIANCE_STAMP_VERIFIED
                   </p>
                </div>
              </div>
            ) : (
              <div className={`p-10 rounded-[40px] border-4 border-dashed h-full flex flex-col items-center justify-center text-center opacity-60 transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-100 border-slate-200'}`}>
                <ShieldCheck className="h-16 w-16 mb-6 text-slate-400" />
                <h3 className="text-xl font-black uppercase tracking-tight text-slate-500">Awaiting Input</h3>
                <p className="text-[10px] font-bold uppercase tracking-widest mt-2 max-w-[200px]">Select a source to verify your content against California laws.</p>
              </div>
            )}
          </div>
        </div>

        {/* Laws Reference */}
        <div className="mt-24 grid grid-cols-1 md:grid-cols-2 gap-10">
           <div className={`p-8 rounded-3xl border transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
              <h4 className="text-sm font-black uppercase text-blue-600 mb-4 tracking-wider">Fair Housing Act Compliance</h4>
              <p className={`text-xs leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                 Belmont agents must strictly adhere to the Fair Housing Act. Avoid any language that implies a preference or limitation based on protected classes. "Steering" clients toward or away from specific neighborhoods based on demographics is a severe violation and grounds for immediate termination.
              </p>
           </div>
           <div className={`p-8 rounded-3xl border transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
              <h4 className="text-sm font-black uppercase text-amber-600 mb-4 tracking-wider">Anti-Trust & Price Fixing</h4>
              <p className={`text-xs leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                 Under the Sherman Act, commission rates are always negotiable. Agents are prohibited from discussing commission splits or "standard" brokerage fees with competitors. Any mention of fixing rates or boycotting specific business models (e.g., flat-fee brokerages) will be flagged.
              </p>
           </div>
        </div>
      </div>
    </div>
  );
};

export default ComplianceAuditView;
