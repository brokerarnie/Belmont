
import React, { useState, useEffect } from 'react';
import { View, Agent, FontSize } from '../types';
import { 
  Briefcase, Home, Sparkles, UserCircle, Newspaper, 
  ArrowUpRight, X, Info, ShieldCheck, Gift, ChevronDown, 
  ChevronUp, ExternalLink, Zap, Type, Glasses
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface Props {
  navigate: (view: View) => void;
  onProNavigate: (type: Agent['type']) => void;
  darkMode?: boolean;
}

const Directory: React.FC<Props> = ({ navigate, onProNavigate, darkMode = false }) => {
  const [activeNewsItem, setActiveNewsItem] = useState<string | null>(null);
  const [payoutPool, setPayoutPool] = useState('0.00');
  const { t } = useLanguage();

  useEffect(() => {
    const saved = localStorage.getItem('belmont_profit_sharing');
    if (saved) setPayoutPool(saved);
  }, []);

  const communityNews = [
    { text: `NETWORK BULLETIN: Belmont Collective Profit Sharing pool has reached $${payoutPool}!`, detail: "The Profit Sharing pool is distributed to all capped Belmont agents monthly. As the brokerage grows, the collective wealth of our partners grows proportionally." },
    { text: "TENANT RIGHTS: California's AB 1482 limits annual rent increases to 5% plus local CPI for most multi-family housing.", detail: "The Tenant Protection Act of 2019 provides statewide rent control and 'just cause' eviction protections for millions of Californians. Ensure your property is compliant with local San Fernando Valley ordinances which may be stricter." },
    { text: "DID YOU KNOW: The first recorded real estate transaction in Los Angeles occurred in 1781 with the distribution of house lots to the original 44 settlers.", detail: "The original 'pobladores' were granted land by the Spanish crown to establish the farming community that would eventually become the global metropolis of Los Angeles." },
    { text: "LANDLORD LAW: Security deposits in California are now capped at one month's rent for residential properties as of July 2024.", detail: "Assembly Bill 12 signed into law significantly changes how security deposits are handled, regardless of whether a unit is furnished or un-furnished. Exceptions exist for 'small landlords' owning no more than two properties." },
    { text: "REAL ESTATE FACT: 90% of all millionaires become so through owning real estate. It remains the most consistent wealth-building tool in US history.", detail: "Real estate offers a unique combination of cash flow, tax benefits (like 1031 exchanges), and long-term appreciation that few other asset classes can match." },
    { text: "ZONING UPDATE: New LA City 'Accessory Dwelling Unit' (ADU) laws make it easier to convert garages into legal rental units.", detail: "The state has streamlined the approval process for ADUs to help combat the housing shortage. Homeowners in the Valley can often add significant property value by converting existing structures into independent living spaces." },
    { text: "FAIR HOUSING: It is illegal to discriminate against renters based on 'Source of Income,' which includes Section 8 vouchers.", detail: "Under the Fair Employment and Housing Act, landlords must treat government assistance as valid income and cannot advertise 'No Section 8' or similar exclusionary language." }
  ];

  return (
    <div className={`transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-white text-slate-900'}`}>
      
      {/* Public Live Feed Ticker */}
      <div className={`w-full overflow-hidden whitespace-nowrap py-1.5 border-b shadow-sm flex items-center relative z-40 transition-colors ${darkMode ? 'bg-blue-900/40 border-blue-800 text-blue-100' : 'bg-[#2563eb] border-blue-700 text-white'}`}>
        <div className="flex animate-scroll-text hover:[animation-play-state:paused] cursor-default">
          {[...communityNews, ...communityNews].map((item, i) => (
            <span key={i} className="inline-flex items-center px-8 text-[11px] font-bold tracking-tight group">
              <span className="opacity-40 mr-4 font-mono">NEW</span>
              {item.text}
              <button 
                onClick={() => setActiveNewsItem(item.text)}
                className="ml-4 w-6 h-6 bg-white/20 hover:bg-white/40 border border-white/30 rounded flex items-center justify-center transition-all shadow-sm active:scale-90 group-hover:border-white"
                title="Read Detail"
              >
                <ArrowUpRight className="h-3 w-3 text-white" />
              </button>
              <span className="ml-8 text-white/30">•</span>
            </span>
          ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className={`flex flex-col md:flex-row justify-between items-end mb-12 border-b-2 pb-6 ${darkMode ? 'border-slate-800' : 'border-slate-100'}`}>
          <div className="flex items-center gap-4">
            <h1 className="text-4xl font-extrabold tracking-tighter flex items-center">
              BELMONT <span className={`${darkMode ? 'text-blue-400' : 'text-blue-500'} font-light text-2xl ml-2`}>{t('marketplace')}</span>
            </h1>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Section 1 */}
          <div className="space-y-10">
            <div>
              <div className={`${darkMode ? 'bg-slate-900 text-slate-300' : 'bg-slate-100 text-slate-700'} px-4 py-2 font-black flex items-center justify-between`}>
                <span>{t('classifieds').toUpperCase()}</span>
                <Briefcase className={`h-4 w-4 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`}/>
              </div>
              <ul className="mt-4 space-y-2 px-4 text-sm font-medium">
                <li><button onClick={() => navigate(View.CLASSIFIEDS)} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('searchClassifieds')}</button></li>
                <li><button onClick={() => navigate(View.POST_PROPERTY)} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('postProperty')}</button></li>
              </ul>
            </div>

            <div>
              <div className={`${darkMode ? 'bg-slate-900 text-slate-300' : 'bg-slate-100 text-slate-700'} px-4 py-2 font-black flex items-center justify-between`}>
                <span>{t('listings').toUpperCase()}</span>
                <Home className={`h-4 w-4 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`}/>
              </div>
              <ul className="mt-4 space-y-2 px-4 text-sm font-medium">
                <li><button onClick={() => navigate(View.SEARCH)} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('searchAgentListings')}</button></li>
              </ul>
            </div>
          </div>

          {/* Section 2 */}
          <div className="space-y-10">
            <div>
              <div className={`${darkMode ? 'bg-slate-900 text-slate-300' : 'bg-slate-100 text-slate-700'} px-4 py-2 font-black flex items-center justify-between`}>
                <span>{t('professionals').toUpperCase()}</span>
                <UserCircle className={`h-4 w-4 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`}/>
              </div>
              <ul className="mt-4 space-y-2 px-4 text-sm font-medium">
                <li><button onClick={() => onProNavigate('agent')} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('agents')}</button></li>
                <li><button onClick={() => onProNavigate('loan_officer')} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('loanOfficers')}</button></li>
                <li><button onClick={() => onProNavigate('insurance_agent')} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('insuranceAgents')}</button></li>
                <li><button onClick={() => onProNavigate('architect_engineer')} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('architects')}</button></li>
                <li><button onClick={() => onProNavigate('maid_service')} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('cleaning')}</button></li>
                <li><button onClick={() => onProNavigate('cpa')} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('cpas')}</button></li>
                <li><button onClick={() => onProNavigate('attorney')} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('attorneys')}</button></li>
                <li><button onClick={() => onProNavigate('contractor')} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('contractors')}</button></li>
              </ul>
            </div>
          </div>

          {/* Section 3 */}
          <div className="space-y-10">
            <div>
              <div className={`${darkMode ? 'bg-slate-900 text-slate-300' : 'bg-slate-100 text-slate-700'} px-4 py-2 font-black flex items-center justify-between`}>
                <span>{t('community').toUpperCase()}</span>
                <Sparkles className={`h-4 w-4 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`}/>
              </div>
              <ul className="mt-4 space-y-2 px-4 text-sm font-medium">
                <li><button onClick={() => navigate(View.CHAT)} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('chat')}</button></li>
                <li><button onClick={() => navigate(View.INCENTIVES)} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('incentives')}</button></li>
                <li><button onClick={() => navigate(View.FORUMS)} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('forums')}</button></li>
                <li><button onClick={() => navigate(View.HISTORIC_CENTER)} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('historicCenter')}</button></li>
                <li><button onClick={() => navigate(View.KNOW_YOUR_RIGHTS)} className={`${darkMode ? 'text-blue-400 hover:bg-slate-800' : 'text-blue-700 hover:bg-blue-50'} hover:underline block w-full text-left p-1 rounded transition`}>{t('rights')}</button></li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      {/* Community Detail Overlay */}
      {activeNewsItem && (
        <div className="fixed inset-0 z-[110] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
           <div className={`max-w-lg w-full rounded-3xl shadow-2xl border p-10 relative transition-colors ${darkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}>
              <button 
                onClick={() => setActiveNewsItem(null)}
                className="absolute top-5 right-5 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="h-5 w-5 text-slate-500" />
              </button>

              <div className="flex items-center gap-4 mb-8">
                <div className="p-3 bg-blue-600 rounded-2xl shadow-xl shadow-blue-500/20">
                   <Info className="h-7 w-7 text-white" />
                </div>
                <div>
                  <h3 className={`text-xl font-black uppercase tracking-tight ${darkMode ? 'text-white' : 'text-slate-900'}`}>Community Insight</h3>
                  <p className="text-blue-500 font-bold text-[10px] uppercase tracking-widest">Belmont Public Archive</p>
                </div>
              </div>
              
              <div className={`p-6 rounded-2xl border-2 border-dashed mb-8 transition-colors ${darkMode ? 'bg-slate-950 border-slate-800' : 'bg-blue-50 border-blue-100'}`}>
                <p className={`text-sm leading-relaxed font-bold ${darkMode ? 'text-slate-200' : 'text-blue-900'}`}>
                  {activeNewsItem}
                </p>
              </div>

              <div className="space-y-4 mb-10">
                 <p className={`text-sm leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                   {communityNews.find(n => n.text === activeNewsItem)?.detail}
                 </p>
                 <div className="flex items-center gap-2 text-emerald-500 font-black text-[9px] uppercase tracking-widest">
                    <ShieldCheck className="h-3 w-3" /> Verified Belmont Community Resource
                 </div>
              </div>

              <button 
                onClick={() => setActiveNewsItem(null)}
                className="w-full py-4 bg-slate-900 hover:bg-black text-white font-black uppercase text-xs tracking-widest rounded-2xl transition-all shadow-xl"
              >
                Dismiss
              </button>
           </div>
        </div>
      )}

      <style>{`
        @keyframes scrollText {
          from { transform: translateX(0); }
          to { transform: translateX(-50%); }
        }
        .animate-scroll-text {
          animation: scrollText 160s linear infinite;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.98); }
          to { opacity: 1; transform: scale(1); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.2s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default Directory;
