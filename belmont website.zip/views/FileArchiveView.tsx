
import React, { useState } from 'react';
import { View } from '../types';
import { 
  ArrowLeft, Search, Database, Folder, FileText, 
  Download, Share2, MoreVertical, Plus, 
  ChevronRight, HardDrive, ShieldCheck, Clock,
  FileSpreadsheet, Image as ImageIcon, FileCode, Archive
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

interface FileItem {
  id: string;
  name: string;
  type: 'pdf' | 'docx' | 'xlsx' | 'png' | 'folder';
  size?: string;
  date: string;
  owner: string;
}

const FileArchiveView: React.FC<Props> = ({ navigate, darkMode = false }) => {
  const [currentFolder, setCurrentFolder] = useState<string[]>(['Archive']);
  const [searchTerm, setSearchTerm] = useState('');

  const folders = [
    { name: 'Transaction Folders', count: 142, icon: <Folder className="text-blue-500" /> },
    { name: 'Brokerage Compliance', count: 28, icon: <ShieldCheck className="text-emerald-500" /> },
    { name: 'Marketing Assets', count: 512, icon: <ImageIcon className="text-purple-500" /> },
    { name: 'Training Modules', count: 12, icon: <FileText className="text-amber-500" /> },
  ];

  const files: FileItem[] = [
    { id: '1', name: 'Standard Listing Agreement v2025.pdf', type: 'pdf', size: '1.2 MB', date: 'Feb 4, 2025', owner: 'Brokerage' },
    { id: '2', name: 'Valley Q1 Market Projection.xlsx', type: 'xlsx', size: '4.5 MB', date: 'Jan 28, 2025', owner: 'Analyst' },
    { id: '3', name: 'Woodland_Hills_Map_HighRes.png', type: 'png', size: '18 MB', date: 'Feb 1, 2025', owner: 'Marketing' },
    { id: '4', name: 'Agent Onboarding Handbook.pdf', type: 'pdf', size: '840 KB', date: 'Jan 02, 2025', owner: 'Admin' },
    { id: '5', name: 'Buyer_Consultation_Script.docx', type: 'docx', size: '45 KB', date: 'Today', owner: 'Me' },
  ];

  const filteredFiles = files.filter(f => f.name.toLowerCase().includes(searchTerm.toLowerCase()));

  const getFileIcon = (type: string) => {
    switch(type) {
      case 'pdf': return <FileText className="text-red-500" />;
      case 'xlsx': return <FileSpreadsheet className="text-emerald-600" />;
      case 'docx': return <FileText className="text-blue-600" />;
      case 'png': return <ImageIcon className="text-purple-500" />;
      default: return <FileCode className="text-slate-400" />;
    }
  };

  return (
    <div className={`min-h-screen py-10 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f4f7f9] text-slate-900'}`}>
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <button 
              onClick={() => navigate(View.AGENT_PORTAL)} 
              className={`flex items-center font-bold mb-4 text-[10px] uppercase tracking-widest transition-all border px-3 py-1 rounded-sm ${
                darkMode ? 'text-slate-400 border-slate-700 bg-slate-900 hover:bg-slate-800' : 'text-slate-500 border-slate-300 bg-white hover:text-slate-700 shadow-sm'
              }`}
            >
              <ArrowLeft className="h-3 w-3 mr-2" /> DASHBOARD
            </button>
            <h1 className="text-4xl font-black tracking-tighter uppercase flex items-center gap-3">
              <Database className="h-10 w-10 text-blue-600" />
              File Archive
            </h1>
            <p className={`text-[10px] font-black uppercase tracking-[0.3em] mt-2 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
              Secure Distributed Vault // End-to-End Encrypted
            </p>
          </div>

          <div className="flex items-center gap-4">
             <div className={`px-4 py-2 rounded-2xl border transition-colors flex items-center gap-3 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
                <HardDrive className="h-5 w-5 text-blue-500" />
                <div className="text-left">
                  <p className="text-[10px] font-black uppercase">Vault Capacity</p>
                  <div className="w-32 h-1 bg-slate-200 dark:bg-slate-800 rounded-full mt-1 overflow-hidden">
                     <div className="w-[42%] h-full bg-blue-600"></div>
                  </div>
                  <p className="text-[8px] font-mono mt-1 opacity-60">4.2 GB / 10 GB Used</p>
                </div>
             </div>
             <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-500/20 active:scale-95 transition-all flex items-center gap-2">
                <Plus className="h-4 w-4" /> Upload
             </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Sidebar Navigation */}
          <div className="lg:col-span-3 space-y-6">
            <div className={`p-6 rounded-[32px] border transition-colors ${darkMode ? 'bg-slate-900 border-slate-800 shadow-slate-950/20' : 'bg-white border-slate-100 shadow-xl shadow-slate-200/50'}`}>
               <h3 className="text-[10px] font-black uppercase tracking-widest text-slate-500 mb-6">Directory</h3>
               <nav className="space-y-2">
                  {folders.map(f => (
                    <button key={f.name} className={`w-full flex items-center justify-between p-3 rounded-xl transition-all group ${darkMode ? 'hover:bg-slate-800' : 'hover:bg-slate-50'}`}>
                       <div className="flex items-center gap-3">
                          <div className="group-hover:scale-110 transition-transform">{f.icon}</div>
                          <span className="text-xs font-bold uppercase tracking-tight">{f.name}</span>
                       </div>
                       <span className="text-[9px] font-mono text-slate-400">({f.count})</span>
                    </button>
                  ))}
               </nav>
               <div className="mt-10 pt-6 border-t border-slate-100 dark:border-slate-800">
                  <button className="w-full flex items-center gap-3 p-3 text-red-500 text-xs font-black uppercase tracking-widest hover:underline">
                     <Archive className="h-4 w-4" /> Trash Can
                  </button>
               </div>
            </div>
          </div>

          {/* Main Content Area */}
          <div className="lg:col-span-9 space-y-6">
            {/* Action/Search Bar */}
            <div className={`p-3 rounded-2xl border flex flex-col md:flex-row items-center gap-4 transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
               <div className="relative flex-grow w-full">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Search files by name..."
                    className="w-full pl-11 pr-4 py-2 bg-transparent focus:outline-none text-sm font-bold uppercase tracking-tight"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                  />
               </div>
               <div className="flex items-center gap-2 w-full md:w-auto px-2">
                  <div className={`flex items-center gap-2 text-[10px] font-black uppercase tracking-widest ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                     <ChevronRight className="h-3 w-3" /> Path:
                  </div>
                  <div className="flex items-center gap-1 overflow-x-auto whitespace-nowrap scrollbar-hide">
                     {currentFolder.map((f, i) => (
                       <React.Fragment key={f}>
                         <span className="text-[10px] font-black text-blue-500 hover:underline cursor-pointer">{f}</span>
                         {i < currentFolder.length - 1 && <ChevronRight className="h-2 w-2 opacity-30" />}
                       </React.Fragment>
                     ))}
                  </div>
               </div>
            </div>

            {/* File Table/Grid */}
            <div className={`rounded-[40px] border shadow-2xl transition-colors overflow-hidden ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
               <div className={`grid grid-cols-12 gap-4 p-4 border-b text-[10px] font-black uppercase tracking-widest ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
                  <div className="col-span-6 px-4">File Name</div>
                  <div className="col-span-2 text-center">Size</div>
                  <div className="col-span-2 text-center">Last Modified</div>
                  <div className="col-span-2 text-center">Actions</div>
               </div>
               
               <div className="divide-y transition-colors dark:divide-slate-800 divide-slate-100">
                  {filteredFiles.map(file => (
                    <div key={file.id} className={`grid grid-cols-12 gap-4 p-5 items-center transition-all group ${darkMode ? 'hover:bg-slate-800/50' : 'hover:bg-blue-50/30'}`}>
                       <div className="col-span-6 flex items-center gap-4 px-4 overflow-hidden">
                          <div className={`p-2 rounded-xl border-2 transition-all group-hover:scale-110 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 shadow-sm'}`}>
                             {getFileIcon(file.type)}
                          </div>
                          <div className="min-w-0">
                             <h4 className="text-xs font-black truncate group-hover:text-blue-500 transition-colors uppercase tracking-tight">{file.name}</h4>
                             <p className="text-[9px] font-bold text-slate-400 uppercase">Owner: {file.owner}</p>
                          </div>
                       </div>
                       <div className="col-span-2 text-center font-mono text-[10px] text-slate-500">{file.size}</div>
                       <div className="col-span-2 text-center text-[10px] font-bold text-slate-500 flex flex-col gap-0.5">
                          <span className="flex items-center justify-center gap-1"><Clock className="h-2.5 w-2.5" /> {file.date}</span>
                       </div>
                       <div className="col-span-2 flex items-center justify-center gap-2">
                          <button className="p-2 rounded-lg hover:bg-blue-500 hover:text-white text-slate-400 transition-all shadow-sm"><Download className="h-4 w-4" /></button>
                          <button className="p-2 rounded-lg hover:bg-emerald-500 hover:text-white text-slate-400 transition-all shadow-sm"><Share2 className="h-4 w-4" /></button>
                          <button className="p-2 rounded-lg hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-400 transition-all"><MoreVertical className="h-4 w-4" /></button>
                       </div>
                    </div>
                  ))}
               </div>

               {filteredFiles.length === 0 && (
                 <div className="p-24 text-center">
                    <Database className="h-16 w-16 mx-auto mb-4 opacity-10" />
                    <p className="text-sm font-black uppercase text-slate-400">No files found matching your criteria</p>
                 </div>
               )}
            </div>

            {/* Quick Tips */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
               <div className={`p-6 rounded-3xl border-2 border-dashed transition-colors flex items-center gap-4 ${darkMode ? 'bg-blue-900/10 border-blue-900/30' : 'bg-blue-50 border-blue-100'}`}>
                  <ShieldCheck className="h-6 w-6 text-blue-500" />
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-blue-600 mb-1">Audit Trail Active</h4>
                    <p className={`text-[10px] font-medium leading-relaxed ${darkMode ? 'text-slate-400' : 'text-blue-700'}`}>Every document download is timestamped and logged for compliance reporting.</p>
                  </div>
               </div>
               <div className={`p-6 rounded-3xl border-2 border-dashed transition-colors flex items-center gap-4 ${darkMode ? 'bg-amber-900/10 border-amber-900/30' : 'bg-amber-50 border-amber-100'}`}>
                  <Folder className="h-6 w-6 text-amber-500" />
                  <div>
                    <h4 className="text-[10px] font-black uppercase tracking-widest text-amber-600 mb-1">Smart Sorting</h4>
                    <p className={`text-[10px] font-medium leading-relaxed ${darkMode ? 'text-slate-400' : 'text-amber-700'}`}>AI automatically categorizes transaction documents based on their content.</p>
                  </div>
               </div>
            </div>
          </div>
        </div>

        <div className={`mt-24 text-center border-t pt-12 transition-colors ${darkMode ? 'border-slate-900' : 'border-slate-200'}`}>
           <div className={`mt-8 text-[9px] font-mono uppercase tracking-widest transition-colors ${darkMode ? 'text-slate-800' : 'text-slate-400'}`}>
             BELMONT_FILE_SYSTEM_v5.1 // LAST_BACKUP: {new Date().toLocaleDateString()}
           </div>
        </div>
      </div>
    </div>
  );
};

export default FileArchiveView;
