
import React, { useState, useMemo } from 'react';
import { View, User } from '../types';
import { ArrowLeft, User as UserIcon, ChevronRight, FileText, Plus, Users, Search as SearchIcon, X, Info, ShieldAlert } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  darkMode?: boolean;
}

interface Thread {
  id: string;
  title: string;
  author: string;
  replies: number;
  lastPost: string;
  lastAuthor: string;
  category: string;
  content?: string;
}

const INITIAL_THREADS: Thread[] = [];

const ForumsView: React.FC<Props> = ({ navigate, user, darkMode = false }) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');
  const [viewState, setViewState] = useState<'list' | 'thread' | 'rules' | 'new-thread'>('list');
  const [activeThread, setActiveThread] = useState<Thread | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [threads, setThreads] = useState<Thread[]>(INITIAL_THREADS);
  
  const [newThreadTitle, setNewThreadTitle] = useState('');
  const [newThreadContent, setNewThreadContent] = useState('');
  const [newThreadCat, setNewThreadCat] = useState('General');

  const categories = ['All', 'General', 'Development', 'Vendors', 'Legal', 'Classifieds'];

  const filteredThreads = useMemo(() => {
    let result = threads;
    if (activeCategory !== 'All') {
      result = result.filter(t => t.category === activeCategory);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(t => 
        t.title.toLowerCase().includes(q) || 
        t.author.toLowerCase().includes(q) ||
        (t.content?.toLowerCase().includes(q))
      );
    }
    return result;
  }, [threads, activeCategory, searchQuery]);

  const handleThreadClick = (thread: Thread) => {
    setActiveThread(thread);
    setViewState('thread');
  };

  const handlePostThread = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newThreadTitle || !newThreadContent) return;

    const newThread: Thread = {
      id: Date.now().toString(),
      title: newThreadTitle,
      author: user?.name || 'Anonymous',
      replies: 0,
      lastPost: 'Just now',
      lastAuthor: user?.name || 'Anonymous',
      category: newThreadCat,
      content: newThreadContent
    };

    setThreads([newThread, ...threads]);
    setNewThreadTitle('');
    setNewThreadContent('');
    setViewState('list');
  };

  const ForumTable = () => (
    <div className={`w-full border text-[13px] shadow-sm transition-colors ${darkMode ? 'border-slate-800' : 'border-[#8da4b7]'}`}>
      <div className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-[#4d6b8a] border-[#8da4b7]'} text-white flex font-bold p-2 border-b uppercase tracking-wider text-[11px]`}>
        <div className="flex-grow">Topic / Thread Starter</div>
        <div className="w-24 text-center">Replies</div>
        <div className="w-48 text-right px-2">Last Post Info</div>
      </div>
      
      <div className={darkMode ? 'bg-slate-900' : 'bg-[#e1ebf2]'}>
        {filteredThreads.length > 0 ? filteredThreads.map((thread, i) => (
          <div 
            key={thread.id} 
            onClick={() => handleThreadClick(thread)}
            className={`flex p-2 border-b cursor-pointer items-center transition-colors ${
              darkMode 
                ? (i % 2 === 0 ? 'bg-slate-900 hover:bg-slate-800 border-slate-800' : 'bg-slate-950 hover:bg-slate-800 border-slate-800')
                : (i % 2 === 0 ? 'bg-[#e1ebf2] hover:bg-[#cfd9e1] border-[#8da4b7]' : 'bg-[#f0f4f7] hover:bg-[#cfd9e1] border-[#8da4b7]')
            }`}
          >
            <div className="flex-grow flex items-center gap-3">
              <div className={`p-1.5 border ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-[#d1d1d1] border-gray-400 text-gray-600'}`}>
                <FileText className="h-3 w-3" />
              </div>
              <div className="min-w-0">
                <div className={`font-bold hover:underline text-sm truncate ${darkMode ? 'text-blue-400' : 'text-[#113355]'}`}>{thread.title}</div>
                <div className={`text-[11px] ${darkMode ? 'text-slate-500' : 'text-[#556677]'}`}>by <span className={`font-bold ${darkMode ? 'text-slate-300' : ''}`}>{thread.author}</span> in {thread.category}</div>
              </div>
            </div>
            <div className={`w-24 text-center font-bold ${darkMode ? 'text-slate-400' : 'text-[#445566]'}`}>{thread.replies}</div>
            <div className="w-48 text-right px-2 leading-tight">
              <div className={`font-bold text-xs ${darkMode ? 'text-slate-300' : 'text-[#113355]'}`}>{thread.lastPost}</div>
              <div className={`text-[10px] ${darkMode ? 'text-slate-500' : 'text-[#556677]'}`}>by {thread.lastAuthor}</div>
            </div>
          </div>
        )) : (
          <div className="p-10 text-center text-gray-500 font-bold italic">
            No threads yet. Start the first conversation!
          </div>
        )}
      </div>
    </div>
  );

  const RulesView = () => (
    <div className="animate-fadeIn">
      <div className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-[#4d6b8a] border-[#8da4b7]'} text-white p-3 font-bold flex items-center gap-3 border-b uppercase tracking-widest text-sm`}>
        <ShieldAlert className="h-5 w-5" />
        Belmont Forum Rules & Guidelines
      </div>
      <div className={`border-x border-b p-8 space-y-6 text-sm leading-relaxed transition-colors ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-300' : 'bg-white border-[#8da4b7] text-slate-800'}`}>
        <section>
          <h3 className={`font-black uppercase border-b pb-2 mb-3 ${darkMode ? 'text-blue-400 border-slate-800' : 'text-[#113355] border-gray-100'}`}>1. Keep it Local</h3>
          <p>The Belmont Forums are for residents, agents, and local professionals. Please keep discussions relevant to the Valley and our community.</p>
        </section>
        <section>
          <h3 className={`font-black uppercase border-b pb-2 mb-3 ${darkMode ? 'text-blue-400 border-slate-800' : 'text-[#113355] border-gray-100'}`}>2. Professional Conduct</h3>
          <p>Maintain professional decorum. Harassment, hate speech, or defamatory remarks toward other members or agencies will result in an immediate ban.</p>
        </section>
        <section>
          <h3 className={`font-black uppercase border-b pb-2 mb-3 ${darkMode ? 'text-blue-400 border-slate-800' : 'text-[#113355] border-gray-100'}`}>3. Verified Listings Only</h3>
          <p>Any property posted in the Classifieds section must include valid DRE or owner-verification. No scams allowed.</p>
        </section>
        <div className="pt-4 flex justify-center">
          <button 
            onClick={() => setViewState('list')} 
            className={`px-8 py-2 font-bold uppercase text-xs border transition-all ${
              darkMode ? 'bg-blue-900/40 text-blue-300 border-blue-800 hover:bg-blue-900/60' : 'bg-[#4d6b8a] text-white hover:bg-[#3b556f] border-[#3b556f]'
            }`}
          >
            I Accept the Rules
          </button>
        </div>
      </div>
    </div>
  );

  const NewThreadForm = () => (
    <div className="animate-fadeIn">
       <div className={`${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-[#4d6b8a] border-[#8da4b7]'} text-white p-3 font-bold flex items-center justify-between border-b`}>
         <span className="uppercase text-sm tracking-widest">Start New Conversation</span>
         <button onClick={() => setViewState('list')}><X className="h-4 w-4" /></button>
       </div>
       <form onSubmit={handlePostThread} className={`border-x border-b p-8 space-y-6 transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-[#8da4b7]'}`}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
             <div className="space-y-2">
                <label className={`text-[11px] font-black uppercase tracking-wider ${darkMode ? 'text-slate-500' : 'text-slate-500'}`}>Category</label>
                <select 
                  className={`w-full border p-2 text-xs font-bold transition-colors ${
                    darkMode ? 'bg-slate-800 border-slate-700 text-slate-100' : 'bg-[#f0f4f7] border-[#8da4b7]'
                  }`}
                  value={newThreadCat}
                  onChange={(e) => setNewThreadCat(e.target.value)}
                >
                   {categories.filter(c => c !== 'All').map(c => <option key={c} value={c}>{c}</option>)}
                </select>
             </div>
             <div className="space-y-2">
                <label className={`text-[11px] font-black uppercase tracking-wider ${darkMode ? 'text-slate-500' : 'text-slate-500'}`}>Thread Title</label>
                <input 
                  required
                  className={`w-full border p-2 text-xs font-bold transition-colors ${
                    darkMode ? 'bg-slate-800 border-slate-700 text-slate-100 placeholder-slate-600' : 'bg-[#f0f4f7] border-[#8da4b7]'
                  }`}
                  placeholder="Summarize your topic..."
                  value={newThreadTitle}
                  onChange={(e) => setNewThreadTitle(e.target.value)}
                />
             </div>
          </div>
          <div className="space-y-2">
             <label className={`text-[11px] font-black uppercase tracking-wider ${darkMode ? 'text-slate-500' : 'text-slate-500'}`}>Message Content</label>
             <textarea 
               required
               rows={8}
               className={`w-full border p-4 text-xs font-medium transition-colors ${
                 darkMode ? 'bg-slate-800 border-slate-700 text-slate-100 focus:bg-slate-950' : 'bg-[#f0f4f7] border-[#8da4b7] focus:bg-white'
               }`}
               placeholder="Write your message here..."
               value={newThreadContent}
               onChange={(e) => setNewThreadContent(e.target.value)}
             />
          </div>
          <div className="flex justify-end gap-3">
             <button type="button" onClick={() => setViewState('list')} className="text-xs font-bold text-gray-500 hover:underline">Cancel</button>
             <button type="submit" className={`px-10 py-2 text-xs font-black uppercase tracking-widest border transition-all ${
               darkMode ? 'bg-blue-800 border-blue-900 text-white hover:bg-blue-700' : 'bg-[#4d6b8a] text-white border-[#3b556f] hover:bg-[#3b556f]'
             }`}>Post Thread</button>
          </div>
       </form>
    </div>
  );

  const ThreadView = () => (
    <div className="space-y-4 animate-fadeIn">
      <div className={`${darkMode ? 'bg-slate-800' : 'bg-[#4d6b8a]'} text-white p-3 font-bold text-lg flex justify-between items-center shadow-sm`}>
        <span>{activeThread?.title}</span>
        <span className="text-[10px] uppercase tracking-widest opacity-80 font-mono">ID: {activeThread?.id}</span>
      </div>
      
      <div className={`text-[11px] font-bold flex items-center gap-1 uppercase tracking-wider mb-2 ${darkMode ? 'text-blue-400' : 'text-[#4d6b8a]'}`}>
        <button onClick={() => setViewState('list')} className="hover:underline">Belmont Forums</button>
        <ChevronRight className="h-3 w-3" />
        <button onClick={() => { setViewState('list'); setActiveCategory(activeThread?.category || 'All'); }} className="hover:underline">{activeThread?.category}</button>
        <ChevronRight className="h-3 w-3" />
        <span className={darkMode ? 'text-slate-600' : 'text-gray-500'}>{activeThread?.title}</span>
      </div>

      <div className="space-y-3">
        <div className={`flex border transition-colors ${darkMode ? 'border-slate-800' : 'border-[#8da4b7]'}`}>
          <div className={`w-40 border-r p-3 flex flex-col items-center transition-colors ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-[#e1ebf2] border-[#8da4b7]'}`}>
            <div className={`w-16 h-16 border flex items-center justify-center mb-2 ${darkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-gray-300'}`}>
              <UserIcon className={`h-8 w-8 ${darkMode ? 'text-slate-700' : 'text-gray-300'}`} />
            </div>
            <div className={`font-bold text-xs text-center break-all ${darkMode ? 'text-slate-100' : 'text-[#113355]'}`}>{activeThread?.author}</div>
            <div className={`text-[10px] font-black mt-1 uppercase transition-colors ${darkMode ? 'text-slate-500' : 'text-gray-500'}`}>Member</div>
          </div>
          <div className={`flex-grow p-6 transition-colors ${darkMode ? 'bg-slate-950' : 'bg-white'}`}>
            <div className={`text-[11px] border-b pb-2 mb-4 flex justify-between font-mono transition-colors ${darkMode ? 'text-slate-700 border-slate-900' : 'text-gray-400 border-gray-100'}`}>
              <span>Posted {activeThread?.lastPost}</span>
              <span className={`font-bold ${darkMode ? 'text-blue-900' : 'text-[#113355]'}`}>#1</span>
            </div>
            <p className={`text-[13px] leading-relaxed font-medium transition-colors ${darkMode ? 'text-slate-400' : 'text-slate-800'}`}>
              {activeThread?.content}
            </p>
          </div>
        </div>
      </div>

      <div className="flex justify-end gap-2 pt-4">
        <button onClick={() => setViewState('list')} className={`px-4 py-1.5 text-xs font-bold border transition-all ${
          darkMode ? 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700' : 'bg-[#e1ebf2] border-[#8da4b7] text-[#113355] hover:bg-[#cfd9e1]'
        }`}>Back to Topic List</button>
        <button className={`px-8 py-1.5 text-xs font-black uppercase tracking-widest border transition-all ${
          darkMode ? 'bg-blue-800 border-blue-900 text-white hover:bg-blue-700' : 'bg-[#4d6b8a] border-[#3b556f] text-white hover:bg-[#3b556f]'
        }`}>Quick Reply</button>
      </div>
    </div>
  );

  if (!user) {
    return (
      <div className={`min-h-screen p-6 flex items-center justify-center font-sans transition-colors duration-300 ${darkMode ? 'bg-slate-950' : 'bg-[#dce1e5]'}`}>
        <div className={`max-w-md w-full border-2 p-10 text-center shadow-xl animate-fadeIn transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-[#e1ebf2] border-[#8da4b7]'}`}>
          <div className={`p-4 -mt-10 -mx-10 mb-8 flex justify-center border-b-2 transition-colors ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-[#4d6b8a] border-[#8da4b7]'}`}>
            <ShieldAlert className="h-12 w-12 text-white" />
          </div>
          <h2 className={`text-2xl font-black uppercase tracking-tighter mb-4 ${darkMode ? 'text-slate-100' : 'text-[#113355]'}`}>Membership Required</h2>
          <p className={`text-sm font-medium leading-relaxed mb-8 ${darkMode ? 'text-slate-500' : 'text-slate-600'}`}>
            Access to the Belmont Community Forums is restricted to verified members and agents. Please log in to your account to view discussions, post topics, and connect with local professionals.
          </p>
          <div className="space-y-3">
             <button 
              onClick={() => navigate(View.USER_LOGIN)} 
              className={`w-full py-3 font-black uppercase tracking-[0.2em] text-xs border-2 transition-all ${
                darkMode ? 'bg-blue-900/40 text-blue-300 border-blue-800 hover:bg-blue-900/60' : 'bg-[#4d6b8a] text-white border-t-white border-l-white border-b-[#3b556f] border-r-[#3b556f] active:bg-[#3b556f]'
              }`}
             >
               Sign In to Belmont
             </button>
             <button 
              onClick={() => navigate(View.HOME)} 
              className={`w-full py-3 font-black uppercase tracking-[0.2em] text-xs border transition-all ${
                darkMode ? 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700' : 'bg-white text-[#4d6b8a] border-[#8da4b7] hover:bg-gray-50'
              }`}
             >
               Return to Directory
             </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen p-6 font-sans transition-colors duration-300 ${darkMode ? 'bg-slate-950' : 'bg-[#dce1e5]'}`}>
      <div className="max-w-7xl mx-auto">
        <div className={`flex flex-col md:flex-row justify-between items-start md:items-end mb-8 gap-4 border-b-2 pb-6 transition-colors ${darkMode ? 'border-slate-800' : 'border-[#8da4b7]'}`}>
          <div>
            <button 
              onClick={() => navigate(View.HOME)} 
              className={`flex items-center font-bold mb-4 text-[10px] uppercase tracking-[0.2em] transition-all ${darkMode ? 'text-slate-600 hover:text-slate-300' : 'text-[#4d6b8a] hover:text-[#113355]'}`}
            >
              <ArrowLeft className="h-4 w-4 mr-1" /> Return to Marketplace
            </button>
            <h1 className={`text-3xl font-black tracking-tight uppercase leading-none transition-colors ${darkMode ? 'text-slate-100' : 'text-[#113355]'}`}>
              BELMONT <span className={darkMode ? 'text-blue-900' : 'text-[#4d6b8a] font-light'}>Community Forums</span>
            </h1>
          </div>
          
          <div className={`flex items-center gap-4 text-[11px] font-bold uppercase tracking-tighter transition-colors ${darkMode ? 'text-slate-500' : 'text-[#4d6b8a]'}`}>
             <div className={`flex items-center gap-2 pr-4 border-r h-4 transition-colors ${darkMode ? 'border-slate-800' : 'border-[#8da4b7]'}`}>
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className={darkMode ? 'text-slate-300' : ''}>Welcome back, {user.name}</span>
             </div>
             <button onClick={() => setViewState('rules')} className={`hover:text-[#113355] ${darkMode ? 'hover:text-white' : ''}`}>Rules</button>
             <span className={darkMode ? 'text-slate-800' : 'text-gray-400'}>|</span>
             <button onClick={() => setViewState('list')} className={`hover:text-[#113355] ${darkMode ? 'hover:text-white' : ''}`}>All Threads</button>
          </div>
        </div>

        {viewState === 'list' && (
          <div className="animate-fadeIn">
            <div className="flex flex-wrap items-center justify-between mb-4 gap-4">
               <div className="flex gap-1 overflow-x-auto scrollbar-hide">
                 {categories.map(cat => (
                   <button 
                    key={cat}
                    onClick={() => setActiveCategory(cat)}
                    className={`px-3 py-1.5 text-[10px] font-black uppercase tracking-tight border transition-all whitespace-nowrap ${
                      activeCategory === cat 
                        ? (darkMode ? 'bg-blue-800 border-blue-900 text-white' : 'bg-[#4d6b8a] border-[#3b556f] text-white shadow-inner')
                        : (darkMode ? 'bg-slate-900 border-slate-800 text-slate-500 hover:bg-slate-800' : 'bg-[#e1ebf2] border-[#8da4b7] text-[#113355] hover:bg-[#cfd9e1]')
                    }`}
                   >
                     {cat}
                   </button>
                 ))}
               </div>
               
               <button 
                onClick={() => setViewState('new-thread')}
                className={`px-6 py-2.5 text-[10px] font-black uppercase tracking-[0.2em] flex items-center gap-2 border shadow-sm transition-all ${
                  darkMode ? 'bg-blue-800 border-blue-900 text-white hover:bg-blue-700' : 'bg-[#4d6b8a] text-white border-[#3b556f] hover:bg-[#3b556f]'
                }`}
               >
                 <Plus className="h-3 w-3" /> Post New Thread
               </button>
            </div>

            <ForumTable />
          </div>
        )}

        {viewState === 'thread' && <ThreadView />}
        {viewState === 'rules' && <RulesView />}
        {viewState === 'new-thread' && <NewThreadForm />}
      </div>
    </div>
  );
};

export default ForumsView;
