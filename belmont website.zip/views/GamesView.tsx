
import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { View } from '../types';
import { 
  ArrowLeft, Gamepad2, Trophy, RotateCcw, Zap, 
  ChevronUp, ChevronDown, ChevronLeft, ChevronRight,
  Target, Info, MousePointer2, Smartphone, Monitor, Star, PlayCircle, X,
  History, Globe, Cpu, Clock, History as HistoryIcon,
  Search, ShieldAlert, Cpu as CpuIcon, Activity, Keyboard, 
  ArrowLeftCircle, Power, RefreshCw, Smartphone as MobileIcon, Heart,
  Skull
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
  fromAgent?: boolean;
}

type EngineType = 'SNAKE' | 'MERGE' | 'PONG' | 'CATCH' | 'TAPPER' | 'SHOOTER';

interface GameMetadata {
  id: string;
  name: string;
  year: number;
  country: string;
  developer: string;
  icon: string;
  color: string;
  history: string;
  playable: boolean;
  engine: EngineType;
}

const ARCADE_112: GameMetadata[] = [
  { id: '1', name: 'Computer Space', year: 1971, country: 'USA', developer: 'Nutting Assoc.', icon: '🚀', color: 'bg-slate-800', playable: true, engine: 'SHOOTER', history: 'The first coin-op video game. It used hardware logic instead of a CPU.' },
  { id: '2', name: 'Pong', year: 1972, country: 'USA', developer: 'Atari', icon: '🏓', color: 'bg-blue-900', playable: true, engine: 'PONG', history: 'The game that launched the industry. A simple but addictive table tennis sim.' },
  { id: '3', name: 'Space Race', year: 1973, country: 'USA', developer: 'Atari', icon: '✨', color: 'bg-indigo-900', playable: true, engine: 'SHOOTER', history: 'Players dodge asteroids in a vertical race to the top of the screen.' },
  { id: '4', name: 'Gran Trak 10', year: 1974, country: 'USA', developer: 'Atari', icon: '🏎️', color: 'bg-emerald-900', playable: true, engine: 'TAPPER', history: 'The first racing game with a steering wheel and pedals.' },
  { id: '5', name: 'Gun Fight', year: 1975, country: 'Japan/USA', developer: 'Taito/Midway', icon: '🤠', color: 'bg-amber-900', playable: true, engine: 'SHOOTER', history: 'The first game to use a microprocessor, changing gaming forever.' },
  { id: '6', name: 'Breakout', year: 1976, country: 'USA', developer: 'Atari', icon: '🧱', color: 'bg-red-900', playable: true, engine: 'PONG', history: 'Developed by Jobs and Wozniak. A vertical wall-breaking classic.' },
  { id: '7', name: 'Sea Wolf', year: 1976, country: 'USA', developer: 'Midway', icon: '🚢', color: 'bg-cyan-900', playable: true, engine: 'SHOOTER', history: 'Submarine combat using a physical periscope controller.' },
  { id: '8', name: 'Night Driver', year: 1976, country: 'USA', developer: 'Atari', icon: '🌃', color: 'bg-black', playable: true, engine: 'TAPPER', history: 'One of the earliest first-person perspective driving games.' },
  { id: '9', name: 'Blockade', year: 1976, country: 'USA', developer: 'Gremlin', icon: '🐍', color: 'bg-emerald-800', playable: true, engine: 'SNAKE', history: 'The original "snake" game concept.' },
  { id: '10', name: 'Combat', year: 1977, country: 'USA', developer: 'Atari', icon: '🛡️', color: 'bg-green-900', playable: true, engine: 'SHOOTER', history: 'Classic tank combat that defined early multiplayer rivalry.' },
  { id: '11', name: 'Space Invaders', year: 1978, country: 'Japan', developer: 'Taito', icon: '👾', color: 'bg-purple-900', playable: true, engine: 'SHOOTER', history: 'Caused a national coin shortage in Japan due to its massive popularity.' },
  { id: '15', name: 'Pac-Man', year: 1980, country: 'Japan', developer: 'Namco', icon: '🟡', color: 'bg-yellow-600', playable: true, engine: 'SNAKE', history: 'The ultimate arcade icon. Designed to appeal to everyone.' },
  { id: '16', name: 'Missile Command', year: 1980, country: 'USA', developer: 'Atari', icon: '🚀', color: 'bg-red-800', playable: true, engine: 'CATCH', history: 'Cold War-era defense game using a trackball.' },
  { id: '64', name: 'Tetris', year: 1988, country: 'USSR/Japan', developer: 'Atari/Sega', icon: '🧊', color: 'bg-cyan-900', playable: true, engine: 'MERGE', history: 'The definitive falling block puzzle.' },
  { id: '111', name: 'Klax', year: 1989, country: 'USA', developer: 'Atari', icon: '🧱', color: 'bg-cyan-700', playable: true, engine: 'MERGE', history: 'Catch colored tiles and stack them into rows.' },
];

// --- ENGINES ---

const SnakeEngine: React.FC<{ onExit: () => void, title: string, id: string }> = ({ onExit, title, id }) => {
  const [snake, setSnake] = useState([{ x: 10, y: 10 }]);
  const [food, setFood] = useState({ x: 5, y: 5 });
  const [gameOver, setGameOver] = useState(false);
  const [score, setScore] = useState(0);
  const dirRef = useRef({ x: 0, y: -1 });
  const queuedDirRef = useRef({ x: 0, y: -1 });

  const reset = useCallback(() => {
    setSnake([{ x: 10, y: 10 }]);
    setFood({ x: 5, y: 5 });
    setScore(0);
    setGameOver(false);
    dirRef.current = { x: 0, y: -1 };
    queuedDirRef.current = { x: 0, y: -1 };
  }, []);

  useEffect(() => {
    if (gameOver) return;
    const i = setInterval(() => {
      setSnake(prev => {
        dirRef.current = queuedDirRef.current;
        const head = { x: prev[0].x + dirRef.current.x, y: prev[0].y + dirRef.current.y };
        if (head.x < 0 || head.x >= 20 || head.y < 0 || head.y >= 20 || prev.some(s => s.x === head.x && s.y === head.y)) {
          setGameOver(true);
          return prev;
        }
        const newSnake = [head, ...prev];
        if (head.x === food.x && head.y === food.y) {
          setScore(s => s + 100);
          setFood({ x: Math.floor(Math.random() * 20), y: Math.floor(Math.random() * 20) });
        } else {
          newSnake.pop();
        }
        return newSnake;
      });
    }, 150);
    return () => clearInterval(i);
  }, [food, gameOver]);

  const handleInput = (d: string) => {
    if (d === 'UP' && dirRef.current.y === 0) queuedDirRef.current = { x: 0, y: -1 };
    if (d === 'DOWN' && dirRef.current.y === 0) queuedDirRef.current = { x: 0, y: 1 };
    if (d === 'LEFT' && dirRef.current.x === 0) queuedDirRef.current = { x: -1, y: 0 };
    if (d === 'RIGHT' && dirRef.current.x === 0) queuedDirRef.current = { x: 1, y: 0 };
  };

  return (
    <HandheldFrame title={title} score={score} onDir={handleInput} onExit={onExit} onReset={reset} romId={id}>
      <div className="w-full h-full grid grid-cols-20 grid-rows-20 bg-slate-900 relative overflow-hidden">
        {Array.from({ length: 400 }).map((_, i) => {
          const x = i % 20; const y = Math.floor(i / 20);
          const isS = snake.some(s => s.x === x && s.y === y);
          const isF = food.x === x && food.y === y;
          const isHead = snake[0].x === x && snake[0].y === y;
          return <div key={i} className={`w-full h-full ${isHead ? 'bg-white' : isS ? 'bg-blue-500' : isF ? 'bg-emerald-500 animate-pulse' : ''}`} />;
        })}
        {gameOver && <div className="absolute inset-0 bg-black/80 flex items-center justify-center text-red-500 font-black text-xl">GAME OVER</div>}
      </div>
    </HandheldFrame>
  );
};

const ShooterEngine: React.FC<{ onExit: () => void, title: string, id: string }> = ({ onExit, title, id }) => {
  const [px, setPx] = useState(45);
  const [bs, setBs] = useState<{id: number, x: number, y: number}[]>([]);
  const [es, setEs] = useState<{id: number, x: number, y: number}[]>([]);
  const [health, setHealth] = useState(3);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);

  // Use refs for the game loop to avoid stale state and high-frequency React overhead
  const stateRef = useRef({ px: 45, health: 3, score: 0, gameOver: false });
  
  const reset = () => {
    stateRef.current = { px: 45, health: 3, score: 0, gameOver: false };
    setPx(45); setHealth(3); setScore(0); setGameOver(false); setBs([]); setEs([]);
  };

  useEffect(() => {
    if (gameOver) return;
    const i = setInterval(() => {
      // 1. Update positions
      setBs(prev => prev.map(b => ({ ...b, y: b.y - 4 })).filter(b => b.y > -5));
      setEs(prev => {
        let next = prev.map(e => ({ ...e, y: e.y + 1.2 }));
        
        // 2. Collision Detection & Bypassing
        let healthDeduction = 0;
        const remainingEs = next.filter(e => {
          // If enemy reaches bottom
          if (e.y >= 95) {
            healthDeduction++;
            return false;
          }
          // If enemy hits player (generous hitbox)
          if (Math.abs(e.x - stateRef.current.px) < 10 && e.y > 80 && e.y < 92) {
            healthDeduction++;
            return false;
          }
          return true;
        });

        if (healthDeduction > 0) {
          setHealth(h => {
            const nh = Math.max(0, h - healthDeduction);
            stateRef.current.health = nh;
            if (nh <= 0) {
              setGameOver(true);
              stateRef.current.gameOver = true;
            }
            return nh;
          });
        }

        // 3. Spawning
        if (Math.random() > 0.94) {
          remainingEs.push({ id: Math.random(), x: Math.random() * 90, y: -5 });
        }
        return remainingEs;
      });
    }, 40);
    return () => clearInterval(i);
  }, [gameOver]);

  // Bullet hit detection
  useEffect(() => {
    if (gameOver) return;
    if (bs.length === 0 || es.length === 0) return;

    setEs(prevEs => {
      let hit = false;
      const filteredEs = prevEs.filter(e => {
        const bulletHit = bs.find(b => Math.abs(b.x - e.x) < 8 && Math.abs(b.y - e.y) < 8);
        if (bulletHit) {
          setScore(s => s + 100);
          hit = true;
          setBs(currBs => currBs.filter(b => b.id !== bulletHit.id));
          return false;
        }
        return true;
      });
      return hit ? filteredEs : prevEs;
    });
  }, [bs]);

  const shoot = () => {
    if (gameOver) return;
    setBs(p => [...p, { id: Math.random(), x: stateRef.current.px + 2, y: 85 }]);
  };

  const move = (d: string) => {
    if (gameOver) return;
    setPx(p => {
      const np = d === 'LEFT' ? Math.max(0, p - 10) : Math.min(90, p + 10);
      stateRef.current.px = np;
      return np;
    });
  };

  return (
    <HandheldFrame title={title} score={score} onDir={move} onAction={shoot} onExit={onExit} onReset={reset} romId={id}>
      <div className="w-full h-full bg-slate-950 relative overflow-hidden touch-none select-none">
        <div className="absolute top-2 left-2 flex gap-1 z-20">
           {Array.from({ length: 3 }).map((_, i) => (
             <Heart key={i} className={`h-4 w-4 ${i < health ? 'text-red-500 fill-red-500' : 'text-slate-800'}`} />
           ))}
        </div>
        
        <div className={`absolute bottom-4 text-3xl transition-all ${health <= 0 ? 'opacity-0' : 'opacity-100'}`} style={{ left: `${px}%` }}>🚀</div>
        {bs.map(b => <div key={b.id} className="absolute w-1 h-4 bg-red-500 shadow-[0_0_8px_red]" style={{ left: `${b.x}%`, top: `${b.y}%` }} />)}
        {es.map(e => <div key={e.id} className="absolute text-2xl animate-pulse" style={{ left: `${e.x}%`, top: `${e.y}%` }}>👾</div>)}
        
        {gameOver && (
          <div className="absolute inset-0 bg-black/90 flex flex-col items-center justify-center text-red-500 animate-fadeIn z-30">
            <Skull className="h-12 w-12 mb-4" />
            <div className="font-black text-xl uppercase tracking-widest">HULL COMPROMISED</div>
            <div className="text-[10px] font-bold uppercase mt-2 text-slate-500">Press Reset to Repair</div>
          </div>
        )}
      </div>
    </HandheldFrame>
  );
};

const MergeEngine: React.FC<{ onExit: () => void, title: string, id: string }> = ({ onExit, title, id }) => {
  const [grid, setGrid] = useState<(number | null)[]>(Array(16).fill(null));
  const [score, setScore] = useState(0);

  const spawn = useCallback((current: (number|null)[]) => {
    const empty = current.map((v, i) => v === null ? i : null).filter(v => v !== null) as number[];
    if (empty.length === 0) return current;
    const next = [...current];
    next[empty[Math.floor(Math.random() * empty.length)]] = Math.random() > 0.9 ? 4 : 2;
    return next;
  }, []);

  const reset = useCallback(() => {
    setScore(0);
    setGrid(spawn(spawn(Array(16).fill(null))));
  }, [spawn]);

  useEffect(() => { reset(); }, [id, reset]);

  const slide = (direction: string) => {
    let changed = false;
    let newGrid = [...grid];
    let newScore = score;
    const getIdx = (r: number, c: number) => r * 4 + c;

    const moveLine = (line: (number | null)[]) => {
      let nonNull = line.filter(v => v !== null) as number[];
      let mergedLine: (number | null)[] = [];
      for (let i = 0; i < nonNull.length; i++) {
        if (i < nonNull.length - 1 && nonNull[i] === nonNull[i+1]) {
          const val = nonNull[i] * 2;
          mergedLine.push(val);
          newScore += val;
          i++;
          changed = true;
        } else {
          mergedLine.push(nonNull[i]);
        }
      }
      while (mergedLine.length < 4) mergedLine.push(null);
      return mergedLine;
    };

    if (direction === 'LEFT' || direction === 'RIGHT') {
      for (let r = 0; r < 4; r++) {
        let line = [newGrid[getIdx(r, 0)], newGrid[getIdx(r, 1)], newGrid[getIdx(r, 2)], newGrid[getIdx(r, 3)]];
        if (direction === 'RIGHT') line.reverse();
        let processed = moveLine(line);
        if (direction === 'RIGHT') processed.reverse();
        for (let c = 0; c < 4; c++) {
          if (newGrid[getIdx(r, c)] !== processed[c]) changed = true;
          newGrid[getIdx(r, c)] = processed[c];
        }
      }
    } else {
      for (let c = 0; c < 4; c++) {
        let line = [newGrid[getIdx(0, c)], newGrid[getIdx(1, c)], newGrid[getIdx(2, c)], newGrid[getIdx(3, c)]];
        if (direction === 'DOWN') line.reverse();
        let processed = moveLine(line);
        if (direction === 'DOWN') processed.reverse();
        for (let r = 0; r < 4; r++) {
          if (newGrid[getIdx(r, c)] !== processed[r]) changed = true;
          newGrid[getIdx(r, c)] = processed[r];
        }
      }
    }

    if (changed) {
      setScore(newScore);
      setGrid(spawn(newGrid));
    }
  };

  return (
    <HandheldFrame title={title} score={score} onDir={slide} onExit={onExit} onReset={reset} romId={id}>
      <div className="w-full h-full p-3 grid grid-cols-4 gap-2 bg-slate-900 border-2 border-slate-950">
        {grid.map((v, i) => (
          <div key={i} className={`aspect-square flex items-center justify-center rounded-lg font-black text-lg transition-all ${v ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-800/40 opacity-20'}`}>
            {v || ''}
          </div>
        ))}
      </div>
    </HandheldFrame>
  );
};

const PongEngine: React.FC<{ onExit: () => void, title: string, id: string }> = ({ onExit, title, id }) => {
  const [b, setB] = useState({ x: 50, y: 50, dx: 2.2, dy: 1.2 });
  const [p1, setP1] = useState(40);
  const [p2, setP2] = useState(40);
  const [s, setS] = useState(0);

  useEffect(() => {
    const i = setInterval(() => {
      setB(prev => {
        let nx = prev.x + prev.dx; let ny = prev.y + prev.dy;
        if (ny <= 2 || ny >= 98) prev.dy *= -1;
        if (nx <= 7 && ny >= p1 && ny <= p1 + 25) { prev.dx *= -1.05; setS(cur => cur + 10); nx = 7.1; }
        if (nx >= 93 && ny >= p2 && ny <= p2 + 25) { prev.dx *= -1.05; nx = 92.9; }
        if (nx < 0 || nx > 100) { nx = 50; ny = 50; prev.dx = prev.dx > 0 ? -2.2 : 2.2; }
        setP2(p => p + (ny - 12 - p) * 0.1);
        return { ...prev, x: nx, y: ny };
      });
    }, 40);
    return () => clearInterval(i);
  }, [p1, p2]);

  return (
    <HandheldFrame title={title} score={s} onDir={d => d === 'UP' ? setP1(p => Math.max(0, p-12)) : setP1(p => Math.min(75, p+12))} onExit={onExit} onReset={() => setS(0)} romId={id}>
      <div className="w-full h-full bg-slate-900 relative">
        <div className="absolute left-0 right-0 top-1/2 h-px bg-white/5" />
        <div className="absolute w-3 h-3 bg-white rounded-full shadow-[0_0_15px_white]" style={{ left: `${b.x}%`, top: `${b.y}%` }} />
        <div className="absolute w-2 h-16 bg-blue-500 rounded-full left-2" style={{ top: `${p1}%` }} />
        <div className="absolute w-2 h-16 bg-red-500 rounded-full right-2" style={{ top: `${p2}%` }} />
      </div>
    </HandheldFrame>
  );
};

const TapperEngine: React.FC<{ onExit: () => void, title: string, id: string }> = ({ onExit, title, id }) => {
  const [pos, setPos] = useState(50);
  const [vel, setVel] = useState(0);
  const [pipes, setPipes] = useState<{x: number, h: number}[]>([]);
  const [score, setScore] = useState(0);
  const [dead, setDead] = useState(false);

  useEffect(() => {
    if (dead) return;
    const i = setInterval(() => {
      setPos(p => { const n = p + vel; if (n < 0 || n > 100) setDead(true); return n; });
      setVel(v => v + 0.35);
      setPipes(prev => {
        let next = prev.map(p => ({ ...p, x: p.x - 1.5 })).filter(p => p.x > -20);
        if (next.length === 0 || next[next.length-1].x < 60) next.push({ x: 100, h: Math.random() * 40 + 20 });
        next.forEach(p => { if (p.x > 18 && p.x < 28) { if (pos < p.h || pos > p.h + 25) setDead(true); if (Math.abs(p.x - 20) < 1) setScore(s => s + 10); } });
        return next;
      });
    }, 40);
    return () => clearInterval(i);
  }, [vel, pos, dead]);

  return (
    <HandheldFrame title={title} score={score} onDir={() => setVel(-4.5)} onAction={() => setVel(-4.5)} onExit={onExit} onReset={() => { setDead(false); setPos(50); setVel(0); setPipes([]); setScore(0); }} romId={id}>
      <div className="w-full h-full bg-sky-400 relative overflow-hidden">
        <div className="absolute text-2xl" style={{ top: `${pos}%`, left: '20%' }}>🦅</div>
        {pipes.map((p, i) => (
          <React.Fragment key={i}>
            <div className="absolute bg-emerald-600 w-12 border-x-2 border-emerald-800" style={{ left: `${p.x}%`, top: 0, height: `${p.h}%` }} />
            <div className="absolute bg-emerald-600 w-12 border-x-2 border-emerald-800" style={{ left: `${p.x}%`, top: `${p.h + 25}%`, bottom: 0 }} />
          </React.Fragment>
        ))}
        {dead && <div className="absolute inset-0 bg-red-600/40 flex items-center justify-center text-white font-black text-2xl italic">CRASHED</div>}
      </div>
    </HandheldFrame>
  );
};

const CatchEngine: React.FC<{ onExit: () => void, title: string, id: string }> = ({ onExit, title, id }) => {
  const [basket, setBasket] = useState(40);
  const [items, setItems] = useState<{id: number, x: number, y: number}[]>([]);
  const [score, setScore] = useState(0);

  useEffect(() => {
    const i = setInterval(() => {
      setItems(prev => {
        const next = prev.map(it => ({ ...it, y: it.y + 2.5 })).filter(it => it.y < 100);
        if (Math.random() > 0.95) next.push({ id: Math.random(), x: Math.random() * 90, y: 0 });
        let filtered = [...next];
        next.forEach((it, idx) => { if (it.y > 80 && it.y < 90 && it.x > basket - 8 && it.x < basket + 25) { setScore(s => s + 1000); filtered = filtered.filter(f => f.id !== it.id); } });
        return filtered;
      });
    }, 40);
    return () => clearInterval(i);
  }, [basket]);

  return (
    <HandheldFrame title={title} score={score} onDir={d => d === 'LEFT' ? setBasket(p => Math.max(0, p-12)) : setBasket(p => Math.min(80, p+12))} onExit={onExit} onReset={() => setScore(0)} romId={id}>
      <div className="w-full h-full bg-blue-950 relative overflow-hidden touch-none select-none">
        {items.map(it => <div key={it.id} className="absolute text-2xl" style={{ left: `${it.x}%`, top: `${it.y}%` }}>💎</div>)}
        <div className="absolute bottom-4 h-6 w-24 bg-amber-600 border-t-4 border-amber-900 rounded-b-xl flex items-center justify-center text-[8px] font-black text-white uppercase transition-all" style={{ left: `${basket}%` }}>BELMONT</div>
      </div>
    </HandheldFrame>
  );
};

// --- HANDHELD FRAME ---
const HandheldFrame: React.FC<{ 
  children: React.ReactNode, 
  onDir: (d: string) => void, 
  onAction?: () => void,
  score: number,
  title: string,
  onExit: () => void,
  onReset: () => void,
  romId: string
}> = ({ children, onDir, onAction, score, title, onExit, onReset, romId }) => {
  const [loading, setLoading] = useState(true);
  const [bootLog, setBootLog] = useState<string[]>([]);

  useEffect(() => {
    setLoading(true);
    setBootLog(['HW_INIT...', 'LOAD_ROM...', 'SYNCCK_OK']);
    const t = setTimeout(() => setLoading(false), 800);
    return () => clearTimeout(t);
  }, [romId]);

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (loading) return;
      const k = e.key.toLowerCase();
      if (['arrowup', 'arrowdown', 'arrowleft', 'arrowright', ' ', 'w', 'a', 's', 'd'].includes(k)) e.preventDefault();
      switch(k) {
        case 'arrowup': case 'w': onDir('UP'); break;
        case 'arrowdown': case 's': onDir('DOWN'); break;
        case 'arrowleft': case 'a': onDir('LEFT'); break;
        case 'arrowright': case 'd': onDir('RIGHT'); break;
        case ' ': case 'enter': case 'z': onAction?.(); break;
        case 'escape': case 'x': onExit(); break;
        case 'r': onReset(); break;
      }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, [onDir, onAction, onExit, onReset, loading]);

  return (
    <div className="flex flex-col items-center animate-fadeIn w-full max-w-sm mx-auto select-none touch-none pb-8 h-full min-h-[600px]">
      <div className="w-full flex justify-between items-end mb-4 px-2">
        <div className="flex-1 min-w-0">
          <h3 className="text-xl font-black text-blue-500 uppercase truncate tracking-tighter">{title}</h3>
          <div className="flex items-center gap-2">
             <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_5px_emerald]"></div>
             <span className="text-[9px] font-mono text-emerald-500 uppercase tracking-widest">LIVE_V5.0</span>
          </div>
        </div>
        <div className="text-right shrink-0">
          <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest leading-none mb-1">Score</p>
          <div className="text-2xl font-black text-emerald-500 tabular-nums font-mono leading-none">{score.toLocaleString()}</div>
        </div>
      </div>

      <div className="relative border-[10px] border-slate-800 bg-black rounded-xl shadow-2xl overflow-hidden aspect-square w-full touch-none min-h-[300px]">
         {loading ? (
            <div className="w-full h-full bg-slate-950 p-6 font-mono text-emerald-500 text-[11px] space-y-1.5 flex flex-col justify-center items-center">
               {bootLog.map((log, i) => <div key={i}>{`> ${log}`}</div>)}
               <Activity className="h-5 w-5 animate-spin mt-4" />
            </div>
         ) : children}
         <div className="absolute inset-0 pointer-events-none opacity-20 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.15)_50%),linear-gradient(90deg,rgba(255,0,0,0.05),rgba(0,255,0,0.02),rgba(0,0,255,0.05))] bg-[length:100%_2px,3px_100%]"></div>
      </div>

      <div className="w-full bg-slate-900 rounded-b-[40px] p-8 shadow-2xl border-x-4 border-b-8 border-slate-950 flex flex-col gap-8 mt-1 touch-none">
         <div className="flex justify-between items-center">
            {/* D-PAD */}
            <div className="grid grid-cols-3 gap-1 bg-slate-950 p-1.5 rounded-2xl shadow-inner border border-slate-800/50">
               <div />
               <button onPointerDown={(e) => { e.preventDefault(); onDir('UP'); }} className="w-12 h-12 bg-slate-800 rounded-t-xl flex items-center justify-center text-slate-400 active:bg-blue-600 active:text-white transition-colors"><ChevronUp className="h-6 w-6" /></button>
               <div />
               <button onPointerDown={(e) => { e.preventDefault(); onDir('LEFT'); }} className="w-12 h-12 bg-slate-800 rounded-l-xl flex items-center justify-center text-slate-400 active:bg-blue-600 active:text-white transition-colors"><ChevronLeft className="h-6 w-6" /></button>
               <div className="w-12 h-12 bg-slate-900" />
               <button onPointerDown={(e) => { e.preventDefault(); onDir('RIGHT'); }} className="w-12 h-12 bg-slate-800 rounded-r-xl flex items-center justify-center text-slate-400 active:bg-blue-600 active:text-white transition-colors"><ChevronRight className="h-6 w-6" /></button>
               <div />
               <button onPointerDown={(e) => { e.preventDefault(); onDir('DOWN'); }} className="w-12 h-12 bg-slate-800 rounded-b-xl flex items-center justify-center text-slate-400 active:bg-blue-600 active:text-white transition-colors"><ChevronDown className="h-6 w-6" /></button>
               <div />
            </div>
            
            {/* ACTION BUTTONS */}
            <div className="flex flex-col gap-6 rotate-6">
               <div className="flex gap-6">
                  <button onPointerDown={(e) => { e.preventDefault(); onAction?.(); }} className="w-16 h-16 bg-red-600 rounded-full border-b-[6px] border-red-900 shadow-xl flex items-center justify-center text-white font-black text-2xl active:translate-y-1 active:bg-red-500 active:border-b-2 transition-all">A</button>
                  <button onPointerDown={(e) => { e.preventDefault(); onExit(); }} className="w-12 h-12 bg-slate-700 rounded-full border-b-4 border-slate-900 shadow-lg flex items-center justify-center text-white font-black text-lg active:translate-y-1 active:bg-slate-600 mt-4 transition-all">B</button>
               </div>
            </div>
         </div>

         <div className="flex justify-center gap-10">
            <button onPointerDown={(e) => { e.preventDefault(); onReset(); }} className="flex flex-col items-center group">
              <div className="w-12 h-3 bg-slate-800 rounded-full border-b-2 border-slate-950 group-active:bg-blue-600 shadow-inner"></div>
              <span className="text-[10px] font-black text-slate-500 uppercase mt-2 tracking-widest">Reset (R)</span>
            </button>
            <button onPointerDown={(e) => { e.preventDefault(); onExit(); }} className="flex flex-col items-center group">
              <div className="w-12 h-3 bg-slate-800 rounded-full border-b-2 border-slate-950 group-active:bg-red-600 shadow-inner"></div>
              <span className="text-[10px] font-black text-slate-500 uppercase mt-2 tracking-widest">Quit (Esc)</span>
            </button>
         </div>
      </div>
    </div>
  );
};

// --- MAIN VIEW ---
const GamesView: React.FC<Props> = ({ navigate, darkMode = false, fromAgent = false }) => {
  const [activeGameId, setActiveGameId] = useState<string | null>(null);
  const [viewingHistory, setViewingHistory] = useState<GameMetadata | null>(null);
  const [search, setSearch] = useState('');

  const filteredGames = useMemo(() => 
    ARCADE_112.filter(g => 
      g.name.toLowerCase().includes(search.toLowerCase()) || 
      g.developer.toLowerCase().includes(search.toLowerCase())
    ), [search]);

  const activeGame = useMemo(() => 
    ARCADE_112.find(g => g.id === activeGameId), [activeGameId]);

  const handleGlobalExit = () => {
    if (fromAgent) navigate(View.AGENT_PORTAL);
    else navigate(View.HOME);
  };

  return (
    <div className={`min-h-screen py-8 px-4 transition-colors duration-300 relative overflow-hidden ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f1f5f9] text-slate-900'}`}>
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="flex justify-between items-center mb-8">
          {activeGameId ? (
            <button onClick={() => setActiveGameId(null)} className={`flex items-center font-black text-[11px] uppercase tracking-widest border-2 px-5 py-2 rounded-xl transition-all shadow-md active:scale-95 ${darkMode ? 'text-blue-400 border-blue-800 bg-slate-900' : 'text-blue-600 border-blue-200 bg-white'}`}>
              <ArrowLeftCircle className="h-4 w-4 mr-2" /> Back to Library
            </button>
          ) : (
            <button onClick={handleGlobalExit} className={`flex items-center font-black text-[11px] uppercase tracking-widest border-2 px-5 py-2 rounded-xl transition-all shadow-md active:scale-95 ${darkMode ? 'text-slate-400 border-slate-800 bg-slate-900' : 'text-slate-500 border-slate-200 bg-white'}`}>
              <Power className="h-3 w-3 mr-2" /> Exit Arcade
            </button>
          )}
          
          <div className="bg-blue-500/10 border border-blue-500/30 px-4 py-2 rounded-full flex items-center gap-3">
             <div className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse shadow-[0_0_8px_blue]"></div>
             <span className="text-[10px] font-black uppercase text-blue-500 tracking-[0.2em]">
               {activeGameId ? `SIMULATING: ${activeGame?.name}` : 'LIBRARY MODE'}
             </span>
          </div>
        </div>

        {!activeGameId ? (
          <div className="animate-fadeIn">
            <div className="mb-12 text-center px-4">
              <h1 className="text-6xl font-black tracking-tighter uppercase mb-2 bg-clip-text text-transparent bg-gradient-to-b from-blue-400 to-blue-700 leading-none">BELMONT 112</h1>
              <p className="text-[11px] font-black uppercase tracking-[0.5em] text-slate-500">Hardware Simulation Active</p>
            </div>

            <div className="max-w-md mx-auto mb-12 relative group px-2">
               <input type="text" placeholder="Filter Library..." className={`w-full pl-14 pr-6 py-4 rounded-[25px] border-2 font-black uppercase text-sm tracking-widest transition-all ${darkMode ? 'bg-slate-900 border-slate-800 focus:border-blue-600' : 'bg-white border-slate-200 focus:border-blue-500 shadow-xl'}`} value={search} onChange={e => setSearch(e.target.value)} />
               <Search className="absolute left-6 top-1/2 -translate-y-1/2 h-6 w-6 text-slate-400" />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-5 px-2 pb-12">
              {filteredGames.map((g) => (
                <div key={g.id} onClick={() => setViewingHistory(g)} className={`relative p-5 border-2 rounded-[32px] transition-all group cursor-pointer overflow-hidden active:scale-95 ${darkMode ? 'bg-slate-900 border-slate-800 hover:border-blue-600' : 'bg-white border-slate-100 hover:border-blue-400 hover:shadow-2xl shadow-sm'}`}>
                  <div className={`w-full aspect-square ${g.color} rounded-2xl flex items-center justify-center text-5xl shadow-inner group-hover:scale-105 transition-transform duration-500`}>{g.icon}</div>
                  <div className="mt-4 text-center">
                     <h3 className="font-black text-[11px] uppercase tracking-tighter line-clamp-1 mb-1">{g.name}</h3>
                     <div className="flex justify-center items-center gap-2">
                        <span className="text-[8px] font-mono text-slate-400">{g.year}</span>
                        <div className="w-1 h-1 rounded-full bg-slate-300" />
                        <span className="text-[8px] font-black text-blue-500 uppercase">{g.engine}</span>
                     </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center py-4 px-4 animate-fadeIn h-full">
             {activeGame?.engine === 'SNAKE' && <SnakeEngine onExit={() => setActiveGameId(null)} title={activeGame.name} id={activeGame.id} />}
             {activeGame?.engine === 'SHOOTER' && <ShooterEngine onExit={() => setActiveGameId(null)} title={activeGame.name} id={activeGame.id} />}
             {activeGame?.engine === 'CATCH' && <CatchEngine onExit={() => setActiveGameId(null)} title={activeGame.name} id={activeGame.id} />}
             {activeGame?.engine === 'PONG' && <PongEngine onExit={() => setActiveGameId(null)} title={activeGame.name} id={activeGame.id} />}
             {activeGame?.engine === 'TAPPER' && <TapperEngine onExit={() => setActiveGameId(null)} title={activeGame.name} id={activeGame.id} />}
             {activeGame?.engine === 'MERGE' && <MergeEngine onExit={() => setActiveGameId(null)} title={activeGame.name} id={activeGame.id} />}
          </div>
        )}

        {viewingHistory && (
           <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/90 backdrop-blur-xl animate-fadeIn">
              <div className={`max-w-2xl w-full rounded-[40px] shadow-2xl border-4 p-8 relative transition-colors overflow-y-auto max-h-[90vh] ${darkMode ? 'bg-slate-900 border-blue-600' : 'bg-white border-blue-500'}`}>
                 <button onClick={() => setViewingHistory(null)} className="absolute top-8 right-8 p-3 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"><X className="h-6 w-6 text-slate-400" /></button>
                 <div className="flex flex-col items-center text-center mb-8">
                    <div className={`w-32 h-32 ${viewingHistory.color} rounded-[40px] flex items-center justify-center text-7xl shadow-2xl mb-6 border-4 border-white/20 transform rotate-2`}>{viewingHistory.icon}</div>
                    <h2 className="text-4xl font-black tracking-tighter uppercase mb-4 leading-none">{viewingHistory.name}</h2>
                    <div className="flex flex-wrap justify-center gap-2">
                       <div className="flex items-center gap-1.5 px-3 py-1.5 bg-blue-600 rounded-full text-white text-[10px] font-black uppercase tracking-widest"><Clock className="h-3 w-3" /> {viewingHistory.year}</div>
                       <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 rounded-full text-white text-[10px] font-black uppercase tracking-widest"><Globe className="h-3 w-3" /> {viewingHistory.country}</div>
                       <div className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-600 rounded-full text-white text-[10px] font-black uppercase tracking-widest"><Cpu className="h-3 w-3" /> {viewingHistory.engine}</div>
                    </div>
                 </div>
                 <div className={`p-6 rounded-[32px] mb-8 border-2 border-dashed ${darkMode ? 'bg-slate-950 border-slate-800 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-700'}`}>
                    <div className="flex items-center gap-2 mb-4 text-blue-500 font-black text-[10px] uppercase tracking-[0.2em]"><HistoryIcon className="h-5 w-5" /> Archive Records</div>
                    <p className="text-sm leading-relaxed font-medium">"{viewingHistory.history}"</p>
                 </div>
                 <div className="flex flex-col sm:flex-row gap-4">
                    <button onClick={() => { setActiveGameId(viewingHistory.id); setViewingHistory(null); }} className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-5 rounded-2xl font-black uppercase tracking-[0.3em] text-sm shadow-xl shadow-blue-500/30 flex items-center justify-center gap-4 active:scale-95 transition-all"><PlayCircle className="h-6 w-6" /> Start Session</button>
                    <button onClick={() => setViewingHistory(null)} className={`px-10 py-5 rounded-2xl font-black uppercase tracking-widest text-xs transition-all active:scale-95 ${darkMode ? 'bg-slate-800 text-slate-400 hover:bg-slate-700' : 'bg-slate-100 text-slate-500 hover:bg-slate-200'}`}>Back</button>
                 </div>
              </div>
           </div>
        )}
      </div>
    </div>
  );
};

export default GamesView;
