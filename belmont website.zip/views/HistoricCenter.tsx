
import React, { useState, useRef } from 'react';
import { View } from '../types';
import { ArrowLeft, Landmark, Search, Sparkles, BookOpen, History, MapPin } from 'lucide-react';
import { GoogleGenAI } from "@google/genai";

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

const TOP_LA_CITIES = [
  {
    name: 'Los Angeles',
    founded: '1781',
    description: 'Founded by 44 "pobladores" in 1781 as El Pueblo de la Reina de los Ángeles. Originally part of Mexico, it became an American city in 1848 after the Mexican-American War. The discovery of oil in the 1890s and the arrival of the film industry in the 1910s transformed it into a global metropolis.',
    icon: '🏢'
  },
  {
    name: 'Santa Monica',
    founded: '1875',
    description: 'Named after Saint Monica of Hippo, the area was part of various ranchos before being developed as a resort town. The Santa Monica Pier opened in 1909, and the city became a hub for aviation in the 1920s with the founding of Douglas Aircraft.',
    icon: '🌊'
  },
  {
    name: 'Pasadena',
    founded: '1874',
    description: 'Settled by midwesterners fleeing cold winters, Pasadena was incorporated in 1886. It became a prestigious winter resort for wealthy Easterners and is home to the Rose Parade (since 1890) and Caltech (since 1891).',
    icon: '🌹'
  },
  {
    name: 'Long Beach',
    founded: '1882',
    description: 'Originally "Willmore City," it was renamed Long Beach in 1888. The city grew rapidly after oil was discovered on Signal Hill in 1921 and became a major military and commercial port during and after WWII.',
    icon: '⚓'
  },
  {
    name: 'Beverly Hills',
    founded: '1914',
    description: 'Once a lima bean ranch, the area was developed as a residential community after failed oil drilling attempts. It became world-famous when movie stars like Mary Pickford and Douglas Fairbanks moved to the area in the 1920s.',
    icon: '💎'
  },
  {
    name: 'Glendale',
    founded: '1887',
    description: 'Developed from the lands of Rancho San San Rafael, Glendale was incorporated in 1906. It became a hub for aviation (Grand Central Airport) and is known as the "Jewel City" for its clean environment and beautiful hills.',
    icon: '🏔️'
  }
];

const HistoricCenter: React.FC<Props> = ({ navigate, darkMode = false }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResult, setSearchResult] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const resultRef = useRef<HTMLDivElement>(null);

  const performHistorySearch = async (cityName: string) => {
    if (!cityName.trim()) return;

    setLoading(true);
    setSearchResult(null);
    setSearchQuery(cityName);

    resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    try {
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Provide a detailed history of the city of ${cityName}, including its founding, key development milestones, and historical significance. Focus on facts and interesting details. Format the response with clear headers and paragraphs.`,
        config: {
          systemInstruction: "You are a professional historian specializing in California and American urban history. Your tone is academic yet engaging."
        }
      });
      setSearchResult(response.text);
      
      setTimeout(() => {
        resultRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 100);
      
    } catch (error) {
      console.error("AI Error:", error);
      setSearchResult("Apologies, I couldn't retrieve the history for this city. Please check the spelling or try another location.");
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    performHistorySearch(searchQuery);
  };

  return (
    <div className={`min-h-screen py-10 px-4 sm:px-6 lg:px-8 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#fcfdfd] text-slate-900'}`}>
      <div className="max-w-6xl mx-auto">
        <button 
          onClick={() => navigate(View.HOME)} 
          className={`flex items-center font-bold mb-8 text-[10px] uppercase tracking-widest transition-all border px-3 py-1 rounded-sm ${
            darkMode ? 'text-slate-400 border-slate-800 bg-slate-900 hover:bg-slate-800' : 'text-slate-500 border-slate-300 bg-white hover:text-slate-700 shadow-sm'
          }`}
        >
          <ArrowLeft className="h-3 w-3 mr-2" /> BACK
        </button>

        <div className="text-center mb-16">
          <h1 className={`text-5xl font-black tracking-tighter uppercase flex flex-col md:flex-row items-center justify-center gap-2 md:gap-4 transition-colors ${darkMode ? 'text-slate-100' : 'text-[#111827]'}`}>
            <div className="flex items-center gap-3">
              <Landmark className="h-12 w-12 text-amber-600" />
              <span>BELMONT</span>
            </div>
            <span className="text-amber-600 font-light text-3xl md:text-4xl lowercase md:mt-1">Historic Center</span>
          </h1>
          <p className={`font-bold text-[11px] uppercase tracking-[0.3em] mt-4 border-b pb-4 inline-block px-12 transition-colors ${darkMode ? 'text-slate-700 border-slate-900' : 'text-slate-400 border-slate-200'}`}>
            Archives of the Golden State
          </p>
        </div>

        <section className="mb-20">
          <div className="flex items-center gap-3 mb-8">
            <History className="h-6 w-6 text-amber-600" />
            <h2 className={`text-xl font-black uppercase tracking-tight transition-colors ${darkMode ? 'text-slate-200' : 'text-slate-900'}`}>Prominent Settlements</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {TOP_LA_CITIES.map((city) => (
              <div key={city.name} className={`border p-6 rounded-lg shadow-sm transition-all group ${darkMode ? 'bg-slate-900 border-slate-800 hover:border-amber-900/40' : 'bg-white border-slate-200 hover:shadow-md'}`}>
                <div className="flex justify-between items-start mb-4">
                  <div className="text-3xl">{city.icon}</div>
                  <span className={`text-[10px] font-black px-2 py-1 rounded border uppercase tracking-widest transition-colors ${
                    darkMode ? 'bg-amber-900/20 text-amber-500 border-amber-900/30' : 'bg-amber-50 text-amber-700 border-amber-100'
                  }`}>
                    Est. {city.founded}
                  </span>
                </div>
                <h3 className={`text-lg font-black mb-2 transition-colors group-hover:text-amber-600 ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>{city.name}</h3>
                <p className={`text-sm leading-relaxed font-medium line-clamp-4 transition-colors ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  {city.description}
                </p>
                <button 
                  onClick={() => performHistorySearch(city.name)}
                  className="mt-4 text-[9px] font-black uppercase text-amber-600 tracking-widest hover:underline flex items-center gap-2"
                >
                  Read Full History <BookOpen className="h-3 w-3" />
                </button>
              </div>
            ))}
          </div>
        </section>

        <section ref={resultRef} className={`rounded-3xl p-8 md:p-12 text-white shadow-2xl overflow-hidden relative scroll-mt-24 transition-colors ${darkMode ? 'bg-slate-900 border-2 border-slate-800' : 'bg-slate-900'}`}>
          <div className={`absolute top-0 right-0 w-64 h-64 rounded-full -mr-32 -mt-32 blur-3xl transition-colors ${darkMode ? 'bg-amber-900/10' : 'bg-amber-600/10'}`}></div>
          <div className="relative z-10">
            <div className="flex flex-col md:flex-row justify-between items-center gap-6 mb-10">
              <div>
                <h2 className="text-3xl font-black tracking-tight uppercase">Discover Your City</h2>
                <p className="text-slate-400 text-sm font-medium mt-1">Access history for any municipality in California.</p>
              </div>
              <div className="p-4 bg-amber-600 rounded-2xl shadow-lg">
                <Sparkles className="h-8 w-8 text-white" />
              </div>
            </div>

            <form onSubmit={handleSearchSubmit} className="max-w-2xl mx-auto mb-10">
              <div className="relative">
                <Search className="absolute left-6 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Enter city name (e.g., Santa Clarita, Van Nuys, Whittier)..." 
                  className={`w-full pl-16 pr-6 py-5 border rounded-2xl text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all text-white placeholder:text-slate-500 ${
                    darkMode ? 'bg-slate-950 border-white/5 focus:bg-black' : 'bg-white/5 border-white/10'
                  }`}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
                <button 
                  type="submit"
                  disabled={loading}
                  className="absolute right-3 top-1/2 -translate-y-1/2 bg-amber-600 hover:bg-amber-500 text-white px-8 py-3 rounded-xl font-black uppercase tracking-widest text-xs transition-all shadow-xl shadow-amber-900/40 disabled:opacity-50"
                >
                  {loading ? 'Searching...' : 'Explore'}
                </button>
              </div>
            </form>

            {loading && (
              <div className="flex flex-col items-center justify-center py-20 text-center animate-pulse">
                <div className="p-4 bg-amber-600/20 rounded-full mb-4">
                  <Landmark className="h-10 w-10 text-amber-500 animate-bounce" />
                </div>
                <h3 className="text-xl font-black text-amber-500 uppercase tracking-widest">Compiling Records...</h3>
                <p className="text-slate-500 text-xs font-bold mt-2">Connecting to the Belmont AI Archive Engine</p>
              </div>
            )}

            {searchResult && !loading && (
              <div className={`border p-8 rounded-2xl animate-fadeIn backdrop-blur-sm transition-colors ${darkMode ? 'bg-slate-950 border-slate-800' : 'bg-white/5 border-white/10'}`}>
                <div className={`flex items-center gap-3 mb-6 pb-6 border-b transition-colors ${darkMode ? 'border-slate-800' : 'border-white/10'}`}>
                  <MapPin className="h-5 w-5 text-amber-500" />
                  <h3 className="text-xl font-black uppercase text-amber-500">History of {searchQuery}</h3>
                </div>
                <div className={`prose prose-invert max-w-none leading-loose whitespace-pre-wrap font-medium transition-colors ${darkMode ? 'text-slate-400' : 'text-slate-300'}`}>
                  {searchResult}
                </div>
              </div>
            )}

            {!searchResult && !loading && (
              <div className="text-center py-10">
                <p className="text-slate-500 text-xs font-bold uppercase tracking-widest italic">
                  * Dynamic histories generated by Belmont AI Archive Engine
                </p>
              </div>
            )}
          </div>
        </section>

        <div className={`mt-20 text-center border-t pt-10 transition-colors ${darkMode ? 'border-slate-900' : 'border-slate-200'}`}>
          <div className={`inline-block p-4 border rounded-xl max-w-lg transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-100 border-slate-200'}`}>
             <p className={`text-[10px] font-bold uppercase tracking-widest leading-relaxed transition-colors ${darkMode ? 'text-slate-600' : 'text-slate-700'}`}>
               History is the foundation of community. Understanding our past helps us build a better future for Belmont residents.
             </p>
          </div>
          <div className={`mt-8 text-[9px] font-mono uppercase tracking-widest transition-colors ${darkMode ? 'text-slate-800' : 'text-slate-400'}`}>
            BELMONT_HISTORY_MODULE_v1.0 // TOTAL_ENTRIES: DYNAMIC
          </div>
        </div>
      </div>
    </div>
  );
};

export default HistoricCenter;
