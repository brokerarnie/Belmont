
import React from 'react';
import { View } from '../types';
import { ArrowLeft, Zap, ExternalLink, ShieldCheck, MapPin, Building2, Gift, Info, Search } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

const INCENTIVE_GROUPS = [
  {
    title: "City of Los Angeles (LADWP)",
    description: "Water and Power incentives for residential and commercial customers.",
    icon: <Building2 className="h-6 w-6 text-blue-600" />,
    links: [
      { name: 'LADWP: Search All Active Rebates', url: 'https://www.ladwp.com/search?keywords=rebate', detail: 'Comprehensive search of all currently funded LADWP rebate programs.' },
      { name: 'Consumer Rebate Program (Appliances)', url: 'https://www.ladwp.com/consumer-rebate-program', detail: 'Rebates for AC units, refrigerators, and high-efficiency appliances.' },
      { name: 'Residential EV Charging Station Rebate', url: 'https://www.ladwp.com/ev-charging-rebate-program', detail: 'Up to $1,000 for Level 2 chargers and specialized meter installations.' },
      { name: 'Landscape Incentive (Turf Replacement)', url: 'https://www.ladwp.com/landscape-incentive-program', detail: 'Get paid per square foot to replace your lawn with drought-tolerant landscaping.' },
      { name: 'AC Optimization Program', url: 'https://www.ladwp.com/ac-optimization', detail: 'Free professional tune-ups and smart thermostat incentives.' }
    ]
  },
  {
    title: "Burbank (BWP)",
    description: "Specific deals for Burbank residents and businesses.",
    icon: <Zap className="h-6 w-6 text-amber-500" />,
    links: [
      { name: 'Burbank Water & Power Rebates', url: 'https://www.burbankwaterandpower.com/rebates-and-incentives', detail: 'Energy efficiency and appliance rebates.' },
      { name: 'EV Charging Station Deals', url: 'https://www.burbankwaterandpower.com/electric-vehicles/charging-rebates', detail: 'Residential and commercial EV charger rebates.' }
    ]
  },
  {
    title: "Glendale (GWP)",
    description: "Environmental and sustainability incentives in the Jewel City.",
    icon: <MapPin className="h-6 w-6 text-emerald-500" />,
    links: [
      { name: 'Glendale Water & Power Programs', url: 'https://www.glendaleca.gov/government/city-departments/glendale-water-and-power/residential-customers/rebates-and-programs', detail: 'Conservation incentives and smart home deals.' }
    ]
  },
  {
    title: "Home Safety & Resilience",
    description: "Programs to protect your property from natural disasters.",
    icon: <ShieldCheck className="h-6 w-6 text-red-600" />,
    links: [
      { name: 'Earthquake Brace + Bolt (EBB)', url: 'https://www.earthquakebracebolt.com/', detail: 'Up to $3,000 for seismic retrofitting.' }
    ]
  },
  {
    title: "State & Federal Tax Credits",
    description: "Broad-reaching financial incentives for green energy.",
    icon: <Gift className="h-6 w-6 text-indigo-600" />,
    links: [
      { name: 'Energy Upgrade California', url: 'https://www.energyupgradeca.org/', detail: 'Statewide energy management resources.' },
      { name: 'Federal Inflation Reduction Act (IRA)', url: 'https://www.cleanenergy.gov/', detail: 'Massive tax credits for solar, heat pumps, and insulation.' }
    ]
  }
];

const IncentivesView: React.FC<Props> = ({ navigate, darkMode = false }) => {
  return (
    <div className={`min-h-screen py-10 px-4 sm:px-6 lg:px-8 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f8fafc] text-slate-900'}`}>
      <div className="max-w-6xl mx-auto">
        <button 
          onClick={() => navigate(View.HOME)} 
          className={`flex items-center font-bold mb-8 text-[10px] uppercase tracking-widest transition-all border px-3 py-1 rounded-sm ${
            darkMode ? 'text-slate-400 border-slate-700 bg-slate-900 hover:bg-slate-800' : 'text-slate-50 border-slate-300 bg-white hover:text-slate-700 shadow-sm'
          }`}
        >
          <ArrowLeft className="h-3 w-3 mr-2" /> BACK TO DIRECTORY
        </button>

        <div className="text-center mb-16">
          <h1 className={`text-5xl font-black tracking-tighter uppercase flex flex-col md:flex-row items-center justify-center gap-2 md:gap-4 transition-colors ${darkMode ? 'text-slate-100' : 'text-[#111827]'}`}>
            <div className="flex items-center gap-3">
              <Zap className="h-12 w-12 text-blue-600" />
              <span>BELMONT</span>
            </div>
            <span className="text-blue-600 font-light text-3xl md:text-4xl lowercase md:mt-1">Incentives Hub</span>
          </h1>
          <p className={`font-bold text-[11px] uppercase tracking-[0.3em] mt-4 border-b pb-4 inline-block px-12 transition-colors ${darkMode ? 'text-slate-700 border-slate-900' : 'text-slate-400 border-slate-200'}`}>
            Rebates, Credits & Safety Grants
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {INCENTIVE_GROUPS.map((group, idx) => (
            <section key={idx} className={`p-8 rounded-[40px] border shadow-sm transition-all ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 hover:shadow-xl'}`}>
              <div className="flex items-center gap-4 mb-6">
                <div className={`p-3 rounded-2xl ${darkMode ? 'bg-slate-800' : 'bg-slate-50'}`}>
                  {group.icon}
                </div>
                <div>
                  <h2 className="text-2xl font-black uppercase tracking-tighter">{group.title}</h2>
                  <p className={`text-xs font-medium ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>{group.description}</p>
                </div>
              </div>

              <div className="space-y-4">
                {group.links.map((link, lIdx) => (
                  <a 
                    key={lIdx} 
                    href={link.url} 
                    target="_blank" 
                    rel="noreferrer"
                    className={`group flex items-center justify-between p-4 rounded-2xl border-2 transition-all ${
                      darkMode ? 'border-slate-800 bg-slate-950/50 hover:border-blue-900 hover:bg-slate-800' : 'border-slate-50 bg-slate-50/50 hover:border-blue-100 hover:bg-white'
                    }`}
                  >
                    <div>
                      <h4 className="text-sm font-black uppercase tracking-tight group-hover:text-blue-600 transition-colors flex items-center gap-2">
                        {link.name}
                        {link.name.includes('Search') && <Search className="h-3 w-3 opacity-50" />}
                      </h4>
                      <p className={`text-[10px] font-bold ${darkMode ? 'text-slate-600' : 'text-slate-400'}`}>{link.detail}</p>
                    </div>
                    <ExternalLink className="h-4 w-4 opacity-30 group-hover:opacity-100 group-hover:text-blue-600 transition-all" />
                  </a>
                ))}
              </div>
            </section>
          ))}
        </div>

        <div className={`mt-20 p-12 rounded-[50px] border-4 border-double transition-colors text-center ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-900 text-white border-white/10 shadow-2xl'}`}>
           <Info className="h-12 w-12 text-blue-500 mx-auto mb-6" />
           <h3 className="text-3xl font-black uppercase tracking-tighter mb-4">Add Value to Your Property</h3>
           <p className={`text-sm font-medium max-w-2xl mx-auto mb-10 leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-300'}`}>
             Thousands of dollars in incentives are available to Belmont residents. These programs often expire or shift based on fiscal quarters. Our team monitors these changes to ensure you maximize your property's efficiency and resilience.
           </p>
           <button 
             onClick={() => navigate(View.PROFESSIONALS)}
             className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl transition-all active:scale-95"
           >
             Contact a Modernization Specialist
           </button>
        </div>

        <div className={`mt-20 text-center border-t pt-10 transition-colors ${darkMode ? 'border-slate-900' : 'border-slate-200'}`}>
          <div className={`mt-8 text-[9px] font-mono uppercase tracking-widest transition-colors ${darkMode ? 'text-slate-800' : 'text-slate-400'}`}>
            BELMONT_INCENTIVE_DATABASE_v2.5 // LAST_SYNC: 02.2025
          </div>
        </div>
      </div>
    </div>
  );
};

export default IncentivesView;
