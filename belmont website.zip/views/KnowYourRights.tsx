
import React from 'react';
import { View } from '../types';
import { ArrowLeft, ShieldAlert, Scale, Home, Users, Info, Gavel, FileText, CheckCircle2 } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

const KnowYourRights: React.FC<Props> = ({ navigate, darkMode = false }) => {
  return (
    <div className={`min-h-screen py-10 px-4 sm:px-6 lg:px-8 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#fcfdfd] text-slate-900'}`}>
      <div className="max-w-6xl mx-auto">
        <button 
          onClick={() => navigate(View.HOME)} 
          className={`flex items-center font-bold mb-8 text-[10px] uppercase tracking-widest transition-all border px-3 py-1 rounded-sm ${
            darkMode ? 'text-slate-400 border-slate-700 bg-slate-900 hover:bg-slate-800' : 'text-slate-500 border-slate-300 bg-white hover:text-slate-700 shadow-sm'
          }`}
        >
          <ArrowLeft className="h-3 w-3 mr-2" /> BACK
        </button>

        <div className="text-center mb-16">
          <h1 className={`text-5xl font-black tracking-tighter uppercase flex flex-col md:flex-row items-center justify-center gap-2 md:gap-4 transition-colors ${darkMode ? 'text-slate-100' : 'text-[#111827]'}`}>
            <div className="flex items-center gap-3">
              <Scale className="h-12 w-12 text-blue-600" />
              <span>BELMONT</span>
            </div>
            <span className="text-blue-600 font-light text-3xl md:text-4xl lowercase md:mt-1">Know Your Rights</span>
          </h1>
          <p className={`font-bold text-[11px] uppercase tracking-[0.3em] mt-4 border-b pb-4 inline-block px-12 transition-colors ${darkMode ? 'text-slate-700 border-slate-900' : 'text-slate-400 border-slate-200'}`}>
            California Real Estate Guidelines
          </p>
        </div>

        {/* Legal Disclaimer Box */}
        <div className={`mb-16 p-6 rounded-2xl border-2 border-dashed flex flex-col md:flex-row items-center gap-6 transition-colors ${darkMode ? 'bg-red-950/20 border-red-900/40' : 'bg-red-50 border-red-200'}`}>
          <div className="p-3 bg-red-600 rounded-xl text-white shadow-lg">
             <ShieldAlert className="h-8 w-8" />
          </div>
          <div>
            <h3 className={`text-lg font-black uppercase tracking-tight ${darkMode ? 'text-red-400' : 'text-red-800'}`}>IMPORTANT LEGAL DISCLAIMER</h3>
            <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-red-700'}`}>
              The information provided on this page is for general educational purposes only and does not constitute legal advice. Laws change frequently and vary by municipality (e.g., Los Angeles City vs. County). <span className="font-bold underline">Always consult with a professional real estate attorney</span> before taking legal action. Visit our <button onClick={() => navigate(View.PROFESSIONALS)} className="underline hover:opacity-70">Professionals Directory</button> to find verified legal counsel.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
          {/* Tenant Section */}
          <section className={`p-8 rounded-[40px] border shadow-sm transition-all ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 hover:shadow-xl'}`}>
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 bg-blue-600 rounded-2xl text-white">
                <Users className="h-6 w-6" />
              </div>
              <h2 className="text-2xl font-black uppercase tracking-tighter">Tenant Rights</h2>
            </div>
            
            <div className="space-y-6">
              <div>
                <h4 className="text-[11px] font-black uppercase text-blue-600 tracking-widest mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3" /> Habitability (Warranty)
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Every residential lease has an implied warranty of habitability. Landlords must provide a unit with functional heat, water, electricity, and a weather-protected structure.
                </p>
              </div>

              <div>
                <h4 className="text-[11px] font-black uppercase text-blue-600 tracking-widest mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3" /> Security Deposits (AB 12)
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  As of July 1, 2024, California law caps security deposits at <span className="text-blue-500 font-bold">one month's rent</span> for most residential properties, regardless of furniture status.
                </p>
              </div>

              <div>
                <h4 className="text-[11px] font-black uppercase text-blue-600 tracking-widest mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3" /> Right to Privacy
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Landlords must generally provide at least <span className="text-blue-500 font-bold">24-hour written notice</span> before entering your unit, except in cases of emergency.
                </p>
              </div>
            </div>
          </section>

          {/* Landlord Section */}
          <section className={`p-8 rounded-[40px] border shadow-sm transition-all ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 hover:shadow-xl'}`}>
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 bg-amber-600 rounded-2xl text-white">
                <Home className="h-6 w-6" />
              </div>
              <h2 className="text-2xl font-black uppercase tracking-tighter">Landlord Rights</h2>
            </div>

            <div className="space-y-6">
              <div>
                <h4 className="text-[11px] font-black uppercase text-amber-600 tracking-widest mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3" /> Right to Rent
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Landlords have the right to receive timely rent payments as agreed in the lease. Late fees must be "reasonable" and specified in the contract.
                </p>
              </div>

              <div>
                <h4 className="text-[11px] font-black uppercase text-amber-600 tracking-widest mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3" /> Eviction "Just Cause"
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Under AB 1482, landlords can evict tenants for "At-Fault" just cause (e.g., non-payment) or "No-Fault" just cause (e.g., owner move-in), often requiring relocation assistance for the latter.
                </p>
              </div>

              <div>
                <h4 className="text-[11px] font-black uppercase text-amber-600 tracking-widest mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3" /> Property Maintenance
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Landlords have the right to inspect (with notice) and maintain the asset's value. Tenants are responsible for damages beyond "normal wear and tear."
                </p>
              </div>
            </div>
          </section>

          {/* Resident/Public Section */}
          <section className={`p-8 rounded-[40px] border shadow-sm transition-all ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 hover:shadow-xl'}`}>
            <div className="flex items-center gap-4 mb-8">
              <div className="p-3 bg-emerald-600 rounded-2xl text-white">
                <Gavel className="h-6 w-6" />
              </div>
              <h2 className="text-2xl font-black uppercase tracking-tighter">Public Rights</h2>
            </div>

            <div className="space-y-6">
              <div>
                <h4 className="text-[11px] font-black uppercase text-emerald-600 tracking-widest mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3" /> Fair Housing Act
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Every resident is protected against discrimination based on race, color, religion, sex, familial status, disability, or national origin.
                </p>
              </div>

              <div>
                <h4 className="text-[11px] font-black uppercase text-emerald-600 tracking-widest mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3" /> Zoning & ADUs
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  California residents have streamlined rights to build Accessory Dwelling Units (ADUs). Local "Not In My Backyard" (NIMBY) laws are often overridden by state housing mandates.
                </p>
              </div>

              <div>
                <h4 className="text-[11px] font-black uppercase text-emerald-600 tracking-widest mb-2 flex items-center gap-2">
                  <CheckCircle2 className="h-3 w-3" /> Public Records
                </h4>
                <p className={`text-sm leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Residents have the right to access property ownership records, permit histories, and environmental hazard disclosures for any parcel in California.
                </p>
              </div>
            </div>
          </section>
        </div>

        {/* Call to Action Card */}
        <div className={`p-12 rounded-[50px] text-center border-4 border-double transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-900 text-white border-white/10'}`}>
           <FileText className="h-12 w-12 text-blue-500 mx-auto mb-6" />
           <h3 className="text-3xl font-black uppercase tracking-tighter mb-4">Need Professional Legal Assistance?</h3>
           <p className={`text-sm font-medium max-w-2xl mx-auto mb-10 leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-300'}`}>
             Complex real estate disputes require specialized knowledge. Our Network Attorneys specialize in California Landlord-Tenant law, partition actions, and commercial lease litigation.
           </p>
           <button 
             onClick={() => navigate(View.PROFESSIONALS)}
             className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl transition-all active:scale-95"
           >
             Contact a Belmont Attorney
           </button>
        </div>

        <div className={`mt-20 text-center border-t pt-10 transition-colors ${darkMode ? 'border-slate-900' : 'border-slate-200'}`}>
          <div className={`inline-block p-4 border rounded-xl max-w-lg transition-colors ${darkMode ? 'bg-blue-950/20 border-blue-900/30' : 'bg-blue-50 border-blue-100'}`}>
             <p className={`text-[10px] font-bold uppercase tracking-widest leading-relaxed transition-colors ${darkMode ? 'text-blue-900' : 'text-blue-700'}`}>
               Empowering our community through knowledge. A better-informed Valley is a stronger Belmont.
             </p>
          </div>
          <div className={`mt-8 text-[9px] font-mono uppercase tracking-widest transition-colors ${darkMode ? 'text-slate-800' : 'text-slate-400'}`}>
            BELMONT_RIGHTS_MODULE_v1.0 // FAIR_HOUSING_COMPLIANT: TRUE
          </div>
        </div>
      </div>
    </div>
  );
};

export default KnowYourRights;
