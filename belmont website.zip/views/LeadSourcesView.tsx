
import React, { useState } from 'react';
import { View, User } from '../types';
import { 
  ArrowLeft, Globe, Zap, ExternalLink, ThumbsUp, ThumbsDown, 
  Plus, ShieldCheck, TrendingUp, Info, Building2, Truck, Briefcase, UserPlus, Search, Users, X
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  darkMode?: boolean;
}

interface LeadSource {
  id: string;
  name: string;
  brand: string;
  url: string;
  totalLeads: number;
  recentLeads: number;
  description: string;
  category: 'Financial' | 'Moving' | 'Relocation';
}

interface CommunitySource {
  id: string;
  name: string;
  url: string;
  author: string;
  ups: number;
  downs: number;
  myVote?: 'up' | 'down';
}

const LeadSourcesView: React.FC<Props> = ({ navigate, user, darkMode = false }) => {
  const [activeTab, setActiveTab] = useState<'official' | 'community'>('official');
  const [showAddSource, setShowAddSource] = useState(false);
  const [newSourceName, setNewSourceName] = useState('');
  const [newSourceUrl, setNewSourceUrl] = useState('');
  
  const officialSources: LeadSource[] = [
    // Financial Institution Backbones
    { id: 'f1', name: 'HomeStory Agent Network', brand: 'Chase/Citi/Citizens', url: 'https://www.homestory.co/agent-network/', totalLeads: 12, recentLeads: 1, description: 'Direct referral pipeline from major financial institutions.', category: 'Financial' },
    { id: 'f2', name: 'Rocket Homes Partner Application', brand: 'Rocket Homes', url: 'https://www.rockethomes.com/partner-agents/application', totalLeads: 25, recentLeads: 4, description: 'Exclusive partner network for verified high-performing agents.', category: 'Financial' },
    { id: 'f3', name: 'melloHome Real Estate Network', brand: 'loanDepot', url: 'https://www.mellohome.com/real-estate-agents', totalLeads: 8, recentLeads: 2, description: 'Streamlined real estate and mortgage integration leads.', category: 'Financial' },
    { id: 'f4', name: 'Anywhere Leads Partner Program', brand: 'Navy Fed/Realogy', url: 'https://www.anywhere.re/leads', totalLeads: 30, recentLeads: 0, description: 'Corporate relocation and affinity program lead source.', category: 'Financial' },
    
    // Moving Company Networks
    { id: 'm1', name: 'CityPointe Agent Registration', brand: 'United/Mayflower', url: 'https://www.citypointe.com/real-estate-agents', totalLeads: 5, recentLeads: 0, description: 'Referrals tied to major national moving and storage logistics.', category: 'Moving' },
    { id: 'm2', name: 'SIRVA Supplier Hub Registration', brand: 'Allied/North American', url: 'https://www.sirva.com/suppliers', totalLeads: 7, recentLeads: 1, description: 'Global relocation supplier network for real estate services.', category: 'Moving' },
    
    // Workforce & Relocation Management
    { id: 'w1', name: 'Graebel Partner Alliance', brand: 'Graebel / CitySwitcher', url: 'https://www.graebel.com/partners/', totalLeads: 15, recentLeads: 2, description: 'High-end corporate relocation management partnerships.', category: 'Relocation' },
    { id: 'w2', name: 'Aires Partner Information', brand: 'Aires', url: 'https://www.aires.com/partners/', totalLeads: 4, recentLeads: 0, description: 'Global workforce mobility solutions and agent referral portal.', category: 'Relocation' },
    { id: 'w3', name: 'Weichert Global Network', brand: 'Weichert Workforce', url: 'https://www.weichertworkforcemobility.com/partners/', totalLeads: 10, recentLeads: 1, description: 'Integration with one of the worlds largest relocation firms.', category: 'Relocation' },
    { id: 'w4', name: 'Keller Williams Relocation', brand: 'KW Relocation', url: 'https://www.kwrelocation.com/', totalLeads: 22, recentLeads: 5, description: 'Massive internal network for referral and relocation leads.', category: 'Relocation' },
  ];

  const [communitySources, setCommunitySources] = useState<CommunitySource[]>([
    { id: 'c1', name: 'Redfin Partner Agent Program', url: 'https://www.redfin.com/partner-agents', author: 'ArnoldD', ups: 12, downs: 2 },
    { id: 'c2', name: 'Zillow Premier Agent', url: 'https://www.zillow.com/premier-agent/', author: 'SarahC', ups: 8, downs: 15 },
    { id: 'c3', name: 'Opendoor Brokerage Program', url: 'https://www.opendoor.com/w/agents', author: 'MikeV', ups: 21, downs: 1 },
  ]);

  const handleVote = (id: string, type: 'up' | 'down') => {
    setCommunitySources(prev => prev.map(s => {
      if (s.id !== id) return s;
      
      const newS = { ...s };
      if (s.myVote === type) {
        // Untoggle
        newS.myVote = undefined;
        if (type === 'up') newS.ups -= 1;
        else newS.downs -= 1;
      } else {
        // Toggle new or change
        if (s.myVote === 'up') newS.ups -= 1;
        if (s.myVote === 'down') newS.downs -= 1;
        
        newS.myVote = type;
        if (type === 'up') newS.ups += 1;
        else newS.downs += 1;
      }
      return newS;
    }));
  };

  const handleAddSource = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSourceName || !newSourceUrl) return;
    
    const newS: CommunitySource = {
      id: Date.now().toString(),
      name: newSourceName,
      url: newSourceUrl,
      author: user?.name || 'Belmont Agent',
      ups: 0,
      downs: 0
    };
    
    setCommunitySources([newS, ...communitySources]);
    setNewSourceName('');
    setNewSourceUrl('');
    setShowAddSource(false);
  };

  const categories = [
    { name: 'Financial', icon: <Building2 className="h-4 w-4" />, color: 'text-blue-500' },
    { name: 'Moving', icon: <Truck className="h-4 w-4" />, color: 'text-amber-500' },
    { name: 'Relocation', icon: <Briefcase className="h-4 w-4" />, color: 'text-emerald-500' }
  ];

  return (
    <div className={`min-h-screen py-10 px-4 sm:px-6 lg:px-8 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f8fafc] text-slate-900'}`}>
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
           <div>
              <button 
                onClick={() => navigate(View.AGENT_PORTAL)} 
                className={`flex items-center font-bold mb-4 text-[10px] uppercase tracking-widest transition-all border px-3 py-1 rounded-sm ${
                  darkMode ? 'text-slate-400 border-slate-700 bg-slate-900 hover:bg-slate-800' : 'text-slate-500 border-slate-300 bg-white hover:text-slate-700 shadow-sm'
                }`}
              >
                <ArrowLeft className="h-3 w-3 mr-2" /> DASHBOARD
              </button>
              <h1 className="text-4xl font-black tracking-tighter uppercase flex items-center gap-3">
                 <Zap className="h-10 w-10 text-blue-600" />
                 Lead Generations Hub
              </h1>
              <p className={`text-[10px] font-black uppercase tracking-[0.3em] mt-2 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                 Syndicated Network Referral Management
              </p>
           </div>

           <div className={`flex p-1 rounded-xl border transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <button 
                onClick={() => setActiveTab('official')}
                className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'official' ? (darkMode ? 'bg-blue-600 text-white shadow-xl' : 'bg-slate-900 text-white shadow-xl') : 'text-slate-500 hover:text-slate-800'}`}
              >
                Official Networks
              </button>
              <button 
                onClick={() => setActiveTab('community')}
                className={`px-6 py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'community' ? (darkMode ? 'bg-blue-600 text-white shadow-xl' : 'bg-slate-900 text-white shadow-xl') : 'text-slate-500 hover:text-slate-800'}`}
              >
                Community Shared
              </button>
           </div>
        </div>

        {activeTab === 'official' ? (
          <div className="space-y-16 animate-fadeIn">
            {categories.map((cat) => (
              <section key={cat.name}>
                <div className="flex items-center gap-4 mb-8 border-b-2 pb-4 border-slate-200 dark:border-slate-800">
                  <div className={`p-3 rounded-2xl ${darkMode ? 'bg-slate-900' : 'bg-white'} shadow-sm ${cat.color}`}>
                    {cat.icon}
                  </div>
                  <h2 className="text-xl font-black uppercase tracking-tight">{cat.name} Institution Backbones</h2>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                   {officialSources.filter(s => s.category === cat.name).map((source) => (
                     <div key={source.id} className={`group border-2 p-6 rounded-3xl flex flex-col justify-between transition-all hover:scale-[1.02] ${darkMode ? 'bg-slate-900 border-slate-800 hover:border-blue-900' : 'bg-white border-slate-100 hover:border-blue-200 shadow-sm'}`}>
                        <div>
                           <div className="flex justify-between items-start mb-4">
                              <span className={`text-[8px] font-black uppercase tracking-widest px-2 py-0.5 rounded border ${darkMode ? 'bg-blue-950/20 text-blue-400 border-blue-900/40' : 'bg-blue-50 text-blue-600 border-blue-100'}`}>
                                 {source.brand}
                              </span>
                              <div className="flex gap-1.5 items-center">
                                 <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                                 <span className="text-[8px] font-mono text-emerald-500 font-bold">LIVE</span>
                              </div>
                           </div>
                           <h3 className="text-sm font-black mb-2 tracking-tight line-clamp-1">{source.name}</h3>
                           <p className={`text-[11px] font-medium leading-relaxed mb-6 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                             {source.description}
                           </p>
                        </div>
                        
                        <div className="space-y-6">
                           <div className="flex gap-4 border-t pt-4 border-slate-100 dark:border-slate-800">
                              <div className="flex-1">
                                 <div className={`text-xl font-black ${darkMode ? 'text-white' : 'text-slate-900'}`}>{source.totalLeads}</div>
                                 <div className="text-[8px] font-black uppercase text-slate-500 tracking-widest">Total Leads</div>
                              </div>
                              <div className="flex-1">
                                 <div className="text-xl font-black text-emerald-500">{source.recentLeads}</div>
                                 <div className="text-[8px] font-black uppercase text-slate-500 tracking-widest">Recent (7d)</div>
                              </div>
                           </div>
                           <a 
                             href={source.url} 
                             target="_blank" 
                             rel="noreferrer" 
                             className={`w-full py-3 rounded-xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all shadow-md active:scale-95 ${darkMode ? 'bg-blue-800 hover:bg-blue-700 text-white' : 'bg-slate-900 hover:bg-black text-white'}`}
                           >
                             Network Application <ExternalLink className="h-3 w-3" />
                           </a>
                        </div>
                     </div>
                   ))}
                </div>
              </section>
            ))}
          </div>
        ) : (
          <div className="animate-fadeIn">
             <div className="flex flex-col lg:flex-row gap-10">
                {/* Community Feed */}
                <div className="flex-grow space-y-4">
                   <div className="flex justify-between items-center mb-6">
                      <h2 className="text-xl font-black uppercase tracking-tight flex items-center gap-2">
                        <Users className="h-6 w-6 text-blue-600" />
                        Network Shared Sources
                      </h2>
                      <div className="flex gap-2">
                         <div className={`px-3 py-1.5 rounded-lg border flex items-center gap-2 text-[10px] font-black uppercase tracking-widest ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-500' : 'bg-white border-slate-200 text-slate-400'}`}>
                            <TrendingUp className="h-3 w-3 text-emerald-500" /> Trending Now
                         </div>
                      </div>
                   </div>

                   {communitySources.map((source) => (
                     <div key={source.id} className={`p-6 border-2 rounded-3xl transition-all flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100 hover:border-blue-100 hover:shadow-lg'}`}>
                        <div className="flex-grow min-w-0">
                           <div className="flex items-center gap-3 mb-1">
                             <h4 className="font-black text-sm tracking-tight truncate">{source.name}</h4>
                             <span className="text-[10px] font-mono text-slate-500">[{source.author}]</span>
                           </div>
                           <a href={source.url} target="_blank" rel="noreferrer" className="text-[10px] font-bold text-blue-500 hover:underline flex items-center gap-1">
                              {source.url} <ExternalLink className="h-2 w-2" />
                           </a>
                        </div>
                        
                        <div className="flex items-center gap-2 shrink-0">
                           <button 
                            onClick={() => handleVote(source.id, 'up')}
                            className={`p-2.5 rounded-xl border-2 flex items-center gap-2 text-xs font-black transition-all active:scale-90 ${source.myVote === 'up' ? 'bg-emerald-500 border-emerald-500 text-white' : (darkMode ? 'border-slate-800 text-slate-500 hover:border-emerald-500/50' : 'border-slate-100 text-slate-400 hover:border-emerald-200')}`}
                           >
                              <ThumbsUp className={`h-4 w-4 ${source.myVote === 'up' ? 'fill-white' : ''}`} /> {source.ups}
                           </button>
                           <button 
                            onClick={() => handleVote(source.id, 'down')}
                            className={`p-2.5 rounded-xl border-2 flex items-center gap-2 text-xs font-black transition-all active:scale-90 ${source.myVote === 'down' ? 'bg-red-500 border-red-500 text-white' : (darkMode ? 'border-slate-800 text-slate-500 hover:border-red-500/50' : 'border-slate-100 text-slate-400 hover:border-red-200')}`}
                           >
                              <ThumbsDown className={`h-4 w-4 ${source.myVote === 'down' ? 'fill-white' : ''}`} /> {source.downs}
                           </button>
                        </div>
                     </div>
                   ))}
                </div>

                {/* Contribution Panel */}
                <div className="w-full lg:w-96 shrink-0">
                   <div className={`p-8 border-2 rounded-[40px] sticky top-32 transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-xl'}`}>
                      <div className="flex items-center gap-4 mb-8">
                         <div className="p-3 bg-blue-600 rounded-2xl shadow-lg">
                            <Plus className="h-6 w-6 text-white" />
                         </div>
                         <h3 className="text-lg font-black uppercase tracking-tight">Share a Source</h3>
                      </div>

                      <form onSubmit={handleAddSource} className="space-y-6">
                         <div>
                            <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block">Referral Program Name</label>
                            <input 
                              required
                              className={`w-full px-4 py-3 rounded-xl border-2 focus:outline-none transition-colors text-xs font-bold ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' : 'bg-slate-50 border-slate-100 text-slate-900 focus:border-blue-500'}`}
                              placeholder="e.g. Veterans United Network..."
                              value={newSourceName}
                              onChange={e => setNewSourceName(e.target.value)}
                            />
                         </div>
                         <div>
                            <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block">Landing URL / Portal</label>
                            <input 
                              required
                              type="url"
                              className={`w-full px-4 py-3 rounded-xl border-2 focus:outline-none transition-colors text-xs font-bold ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' : 'bg-slate-50 border-slate-100 text-slate-900 focus:border-blue-500'}`}
                              placeholder="https://referral.portal/apply"
                              value={newSourceUrl}
                              onChange={e => setNewSourceUrl(e.target.value)}
                            />
                         </div>
                         
                         <div className={`p-4 rounded-xl flex items-start gap-3 border transition-colors ${darkMode ? 'bg-blue-900/10 border-blue-900/30' : 'bg-blue-50 border-blue-100'}`}>
                            <Info className="h-4 w-4 text-blue-500 shrink-0 mt-0.5" />
                            <p className="text-[10px] leading-relaxed font-bold text-blue-500 uppercase tracking-widest">
                               Contributions are shared instantly with the entire Belmont network. Help your colleagues, grow together.
                            </p>
                         </div>

                         <button 
                           type="submit"
                           className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-500/20 active:scale-95 transition-all"
                         >
                            Broadcast Source
                         </button>
                      </form>
                   </div>
                </div>
             </div>
          </div>
        )}

        {/* Support Section */}
        <div className={`mt-24 p-12 rounded-[50px] border-4 border-double transition-colors text-center ${darkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-900 text-white border-white/10 shadow-2xl'}`}>
           <ShieldCheck className="h-12 w-12 text-blue-500 mx-auto mb-6" />
           <h3 className="text-3xl font-black uppercase tracking-tighter mb-4">Elite Referral Support</h3>
           <p className={`text-sm font-medium max-w-2xl mx-auto mb-10 leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-300'}`}>
              The Belmont Syndicate provides guidance for all partner network applications. If you need a broker recommendation letter or performance audit to secure your spot in these high-value lead pipelines, contact our administrative concierge.
           </p>
           <button className="bg-blue-600 hover:bg-blue-700 text-white px-10 py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-2xl transition-all active:scale-95">
              Request Broker Endorsement
           </button>
        </div>

        <div className={`mt-20 text-center border-t pt-10 transition-colors ${darkMode ? 'border-slate-900' : 'border-slate-200'}`}>
           <div className={`mt-8 text-[9px] font-mono uppercase tracking-widest transition-colors ${darkMode ? 'text-slate-800' : 'text-slate-400'}`}>
             BELMONT_LEAD_MODULE_v3.2 // SYNC_STATUS: OPTIMIZED
           </div>
        </div>
      </div>
    </div>
  );
};

export default LeadSourcesView;
