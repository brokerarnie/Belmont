import React from 'react';
import { View } from '../types';
import { ArrowLeft, ShieldCheck, Scale, FileText, Gavel, Home as HomeIcon } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

const LegalView: React.FC<Props> = ({ navigate, darkMode = false }) => {
  return (
    <div className={`min-h-screen py-12 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
      <div className="max-w-4xl mx-auto">
        <button 
          onClick={() => navigate(View.HOME)} 
          className={`flex items-center font-bold mb-12 transition-all ${darkMode ? 'text-slate-400 hover:text-slate-100' : 'text-slate-500 hover:text-slate-800'}`}
        >
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Directory
        </button>

        <div className={`rounded-[40px] shadow-xl border overflow-hidden transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className="bg-slate-900 text-white p-10 flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-black tracking-tighter uppercase mb-2">Legal & Compliance Hub</h1>
              <p className="text-slate-400 text-xs font-bold uppercase tracking-widest">Belmont Brokerage Inc.</p>
            </div>
            <ShieldCheck className="h-12 w-12 text-blue-500" />
          </div>

          <div className="p-10 space-y-12">
            <section>
              <div className="flex items-center gap-3 mb-6">
                <HomeIcon className="h-6 w-6 text-blue-600" />
                <h2 className={`text-xl font-black uppercase tracking-tight ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>Fair Housing Act Compliance</h2>
              </div>
              <div className={`prose prose-sm space-y-4 ${darkMode ? 'prose-invert text-slate-400' : 'prose-slate text-slate-600'}`}>
                <p className="font-bold">Zero Tolerance for Discrimination.</p>
                <p>Belmont Brokerage complies with the federal Fair Housing Act of 1968 and the California Fair Employment and Housing Act (FEHA). We prohibit discrimination against any person because of race, color, religion, sex (including gender identity and sexual orientation), disability, familial status, or national origin.</p>
                <p>All advertisements and listings must be neutral and inclusive. Our AI Compliance Guard automatically flags language that violates these standards.</p>
              </div>
            </section>

            <section>
              <div className="flex items-center gap-3 mb-6">
                <Gavel className="h-6 w-6 text-amber-600" />
                <h2 className={`text-xl font-black uppercase tracking-tight ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>Anti-Trust & Competition Policy</h2>
              </div>
              <div className={`prose prose-sm space-y-4 ${darkMode ? 'prose-invert text-slate-400' : 'prose-slate text-slate-600'}`}>
                <p className="font-bold">Protecting a Free Marketplace.</p>
                <p>Belmont is committed to strict adherence to the Sherman Act and all competition laws. Under no circumstances should commission rates, fee splits, or business strategies be discussed with agents from competing brokerages within our forums or chatrooms.</p>
                <p>Commission rates are determined independently by Belmont Brokerage and are always negotiable with individual clients.</p>
              </div>
            </section>

            <section>
              <div className="flex items-center gap-3 mb-6">
                <FileText className={`h-6 w-6 ${darkMode ? 'text-slate-200' : 'text-slate-900'}`} />
                <h2 className={`text-xl font-black uppercase tracking-tight ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>Privacy & Data Protection</h2>
              </div>
              <div className={`prose prose-sm space-y-4 ${darkMode ? 'prose-invert text-slate-400' : 'prose-slate text-slate-600'}`}>
                <p>Your data is secured using military-grade encryption. Lead information, agent notes, and transaction histories are protected under industry-standard security protocols and are never shared without explicit authorization.</p>
              </div>
            </section>

            <section className={`p-8 rounded-3xl border transition-colors ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-100'}`}>
              <h3 className={`text-xs font-black uppercase tracking-widest mb-4 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>DRE Information</h3>
              <p className={`text-sm font-bold ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>Corporate License: #02065145</p>
              <p className={`text-[10px] mt-2 leading-relaxed ${darkMode ? 'text-slate-500' : 'text-slate-500'}`}>
                Belmont fully supports the Equal Housing Opportunity principles. We do not discriminate based on race, color, religion, sex, handicap, familial status, or national origin. For compliance concerns, email legal@belmont.vc
              </p>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LegalView;