import React, { useState, useEffect } from 'react';
import { View } from '../types';
import { LIBRARY_DATA } from '../constants';
// Added X to the lucide-react imports
import { BookOpen, ArrowLeft, Highlighter, StickyNote, Save, ChevronRight, Upload, Plus, FileText, CheckCircle, Search, Trash2, X } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

const Library: React.FC<Props> = ({ navigate, darkMode = false }) => {
  const [activeBookId, setActiveBookId] = useState<string | null>(null);
  const [userBooks, setUserBooks] = useState<any[]>([]);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [highlights, setHighlights] = useState<Record<string, number[]>>({});
  const [userNotes, setUserNotes] = useState<Record<string, Record<number, string>>>({});
  
  // New Book Form State
  const [newBookTitle, setNewBookTitle] = useState('');
  const [newBookAuthor, setNewBookAuthor] = useState('');
  const [newBookContent, setNewBookContent] = useState('');

  // Load persistence
  useEffect(() => {
    const savedBooks = localStorage.getItem('belmont_library_user_books');
    const savedHighlights = localStorage.getItem('belmont_library_highlights');
    const savedNotes = localStorage.getItem('belmont_library_notes');
    
    if (savedBooks) setUserBooks(JSON.parse(savedBooks));
    if (savedHighlights) setHighlights(JSON.parse(savedHighlights));
    if (savedNotes) setUserNotes(JSON.parse(savedNotes));
  }, []);

  // Save persistence
  useEffect(() => {
    localStorage.setItem('belmont_library_user_books', JSON.stringify(userBooks));
    localStorage.setItem('belmont_library_highlights', JSON.stringify(highlights));
    localStorage.setItem('belmont_library_notes', JSON.stringify(userNotes));
  }, [userBooks, highlights, userNotes]);

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newBookTitle || !newBookContent) return;
    
    const newBook = {
      id: 'custom_' + Date.now(),
      title: newBookTitle,
      author: newBookAuthor || 'Anonymous',
      coverColor: 'bg-indigo-600',
      isCustom: true,
      sections: [
        {
          id: 1,
          title: "Imported Content",
          content: newBookContent,
          prompt: "What are your key takeaways from this section?"
        }
      ]
    };
    
    setUserBooks([...userBooks, newBook]);
    setNewBookTitle('');
    setNewBookAuthor('');
    setNewBookContent('');
    setShowUploadModal(false);
  };

  const toggleHighlight = (bookId: string, sectionId: number) => {
    setHighlights(prev => {
      const bookHighlights = prev[bookId] || [];
      if (bookHighlights.includes(sectionId)) {
        return { ...prev, [bookId]: bookHighlights.filter(id => id !== sectionId) };
      }
      return { ...prev, [bookId]: [...bookHighlights, sectionId] };
    });
  };

  const updateNote = (bookId: string, sectionId: number, text: string) => {
    setUserNotes(prev => ({
      ...prev,
      [bookId]: {
        ...(prev[bookId] || {}),
        [sectionId]: text
      }
    }));
  };

  const allBooks = [...LIBRARY_DATA, ...userBooks];

  if (activeBookId) {
    const book = allBooks.find(b => b.id === activeBookId);
    const bookHighlights = highlights[activeBookId] || [];
    const bookNotes = userNotes[activeBookId] || {};

    return (
      <div className={`min-h-screen transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-white text-slate-900'}`}>
        <div className={`p-6 flex justify-between items-center sticky top-0 z-30 transition-colors border-b ${darkMode ? 'bg-slate-900 text-white border-slate-800 shadow-2xl' : 'bg-slate-900 text-white border-slate-700'}`}>
          <button onClick={() => setActiveBookId(null)} className="flex items-center font-bold text-sm text-slate-400 hover:text-white transition-colors">
            <ArrowLeft className="h-4 w-4 mr-2" /> Back to Bookshelf
          </button>
          <div className="flex items-center gap-4">
             <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-emerald-400">
               <CheckCircle className="h-3 w-3" /> Auto-Saving Notes
             </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto px-6 py-12">
          <div className="text-center mb-16">
            <div className={`w-32 h-48 ${book?.coverColor} mx-auto mb-6 rounded-xl shadow-2xl flex items-center justify-center p-4 text-white font-black text-center text-[10px] border-4 border-white transform hover:scale-105 transition-transform`}>
              {book?.title}
            </div>
            <h1 className={`text-4xl font-black tracking-tighter mb-2 transition-colors ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>{book?.title}</h1>
            <p className={`font-serif italic text-lg ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>by {book?.author}</p>
          </div>

          <div className="space-y-24 pb-24">
            {book?.sections.map((section: any) => (
              <div key={section.id} className="group relative">
                <div className={`border-l-4 pl-8 transition-all ${bookHighlights.includes(section.id) ? 'border-yellow-400' : (darkMode ? 'border-slate-800' : 'border-slate-200')}`}>
                  <div className="flex justify-between items-center mb-6">
                    <h2 className={`text-2xl font-black uppercase tracking-tight transition-colors ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>{section.title}</h2>
                    <button 
                      onClick={() => toggleHighlight(activeBookId, section.id)}
                      className={`p-3 rounded-full border transition-all ${bookHighlights.includes(section.id) ? 'bg-yellow-400 border-yellow-500 text-black shadow-lg scale-110' : (darkMode ? 'bg-slate-900 border-slate-700 text-slate-500 hover:text-white' : 'bg-white border-slate-200 text-slate-400 hover:text-slate-600')}`}
                      title="Highlight Section"
                    >
                      <Highlighter className="h-5 w-5" />
                    </button>
                  </div>
                  <div className={`text-lg leading-relaxed font-medium mb-12 whitespace-pre-wrap transition-all p-6 rounded-3xl ${bookHighlights.includes(section.id) ? (darkMode ? 'bg-yellow-900/20 text-yellow-100' : 'bg-yellow-50 text-slate-900 border-2 border-yellow-100 shadow-sm') : (darkMode ? 'text-slate-400' : 'text-slate-700')}`}>
                    {section.content}
                  </div>
                </div>
                
                <div className={`rounded-[32px] p-8 border shadow-inner transition-colors ${darkMode ? 'bg-slate-900/50 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
                  <div className="flex items-center gap-3 mb-6 text-blue-600">
                    <StickyNote className="h-5 w-5" />
                    <span className="text-[10px] font-black uppercase tracking-widest">Digital Field Notes</span>
                  </div>
                  <p className={`font-black text-xl mb-6 leading-tight transition-colors ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>{section.prompt}</p>
                  <textarea 
                    className={`w-full border-2 rounded-2xl p-6 text-sm font-medium focus:outline-none focus:ring-4 focus:ring-blue-500/10 shadow-sm min-h-[200px] transition-colors ${
                      darkMode ? 'bg-slate-950 border-slate-800 text-slate-100 placeholder:text-slate-700' : 'bg-white border-slate-200 text-slate-900'
                    }`}
                    placeholder="Capture your thoughts, observations, and action items..."
                    value={bookNotes[section.id] || ''}
                    onChange={(e) => updateNote(activeBookId, section.id, e.target.value)}
                  />
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center pt-12 border-t border-slate-200 dark:border-slate-800">
             <p className="text-slate-400 font-black uppercase text-xs tracking-widest mb-4">You've reached the end of this module</p>
             <button onClick={() => { setActiveBookId(null); window.scrollTo(0, 0); }} className="bg-blue-600 text-white px-8 py-3 rounded-full font-bold shadow-xl hover:bg-blue-700 transition-all">Back to Library</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen py-12 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      <div className="max-w-7xl mx-auto">
        <button onClick={() => navigate(View.AGENT_PORTAL)} className={`flex items-center font-bold mb-12 transition-colors ${darkMode ? 'text-slate-500 hover:text-slate-100' : 'text-slate-500 hover:text-slate-800'}`}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Exit Library
        </button>

        <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
          <div>
            <h2 className={`text-4xl font-black tracking-tighter flex items-center gap-4 transition-colors ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              <BookOpen className="h-10 w-10 text-blue-600" />
              PROFESSIONAL <span className="text-blue-500">STUDY HUB</span>
            </h2>
            <p className={`font-bold uppercase tracking-widest text-[10px] mt-2 ${darkMode ? 'text-slate-500' : 'text-slate-500'}`}>Curated & Personal Training Repository</p>
          </div>
          
          <div className="flex items-center gap-3">
            <div className={`flex items-center p-2 rounded-2xl shadow-sm border transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
              <Search className="h-4 w-4 mx-3 text-slate-400" />
              <input 
                type="text" 
                placeholder="Filter catalog..." 
                className={`px-4 py-2 text-xs font-bold uppercase tracking-widest focus:outline-none bg-transparent ${darkMode ? 'text-slate-100 placeholder-slate-600' : 'text-slate-900'}`} 
              />
            </div>
            <button 
              onClick={() => setShowUploadModal(true)}
              className="bg-blue-600 hover:bg-blue-700 text-white p-4 rounded-2xl shadow-xl shadow-blue-500/20 transition-all active:scale-95 flex items-center gap-2 font-black uppercase text-[10px] tracking-widest"
            >
              <Upload className="h-5 w-5" /> Import PDF
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* UPLOAD PLACEHOLDER */}
          <div 
            onClick={() => setShowUploadModal(true)}
            className={`rounded-3xl border-4 border-dashed p-8 flex flex-col items-center justify-center text-center cursor-pointer hover:border-blue-500 hover:bg-blue-50/10 transition-all group min-h-[350px] ${darkMode ? 'border-slate-800' : 'border-slate-200'}`}
          >
             <div className="w-16 h-16 bg-blue-100 dark:bg-blue-900/30 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
               <Plus className="h-8 w-8 text-blue-600" />
             </div>
             <h3 className="font-black text-sm uppercase tracking-widest mb-1">Add to Bookshelf</h3>
             <p className="text-[10px] font-bold text-slate-400 uppercase">PDF, Training Docs, Personal Notes</p>
          </div>

          {allBooks.map(book => (
            <div 
              key={book.id} 
              onClick={() => { setActiveBookId(book.id); window.scrollTo(0,0); }}
              className={`rounded-[40px] shadow-xl border overflow-hidden hover:shadow-2xl transition-all hover:-translate-y-2 cursor-pointer group flex flex-col h-full ${
                darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'
              }`}
            >
              <div className={`h-64 ${book.coverColor} flex items-center justify-center p-8 text-white relative`}>
                <div className="absolute inset-0 opacity-10 flex flex-col justify-between p-4">
                  {[...Array(6)].map((_, i) => <div key={i} className="h-px bg-white w-full" />)}
                </div>
                {book.isCustom ? <FileText className="h-16 w-16 opacity-30 group-hover:scale-125 transition-transform duration-500" /> : <BookOpen className="h-16 w-16 opacity-30 group-hover:scale-125 transition-transform duration-500" />}
                <div className="absolute inset-0 flex items-center justify-center p-8 text-center font-black text-xs uppercase tracking-widest leading-tight">
                  {book.title}
                </div>
              </div>
              <div className="p-8 flex-grow flex flex-col">
                <div className="flex justify-between items-start mb-2">
                  <h3 className={`font-black text-lg leading-tight line-clamp-2 transition-colors ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>{book.title}</h3>
                  {book.isCustom && <button onClick={(e) => { e.stopPropagation(); setUserBooks(userBooks.filter(b => b.id !== book.id)); }} className="text-red-500 hover:text-red-700 transition-colors"><Trash2 className="h-4 w-4" /></button>}
                </div>
                <p className={`text-xs font-bold uppercase tracking-widest mb-6 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>{book.author}</p>
                <div className="mt-auto flex items-center text-blue-600 text-[10px] font-black uppercase tracking-widest group-hover:gap-2 transition-all">
                  Study Workbook <ChevronRight className="h-4 w-4" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upload Modal Simulation */}
      {showUploadModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fadeIn">
           <div className={`max-w-lg w-full rounded-[40px] shadow-2xl border p-10 relative transition-all ${darkMode ? 'bg-slate-900 border-slate-700' : 'bg-white border-slate-200'}`}>
              <button 
                onClick={() => setShowUploadModal(false)}
                className="absolute top-8 right-8 p-2 rounded-full hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
              >
                <X className="h-6 w-6 text-slate-400" />
              </button>

              <div className="flex items-center gap-4 mb-8">
                <div className="p-4 bg-indigo-600 rounded-3xl shadow-xl shadow-indigo-500/20">
                   <Upload className="h-8 w-8 text-white" />
                </div>
                <div>
                  <h3 className={`text-2xl font-black tracking-tight uppercase ${darkMode ? 'text-white' : 'text-slate-900'}`}>Import Workbook</h3>
                  <p className="text-indigo-500 font-bold text-[10px] uppercase tracking-widest">Belmont Study Material Sync</p>
                </div>
              </div>

              <form onSubmit={handleUpload} className="space-y-6">
                 <div>
                   <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block ml-1">Document Title</label>
                   <input 
                    required
                    className={`w-full px-5 py-4 border-2 rounded-2xl focus:outline-none transition-colors font-bold text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' : 'bg-slate-50 border-slate-100 text-slate-900 focus:border-blue-500'}`}
                    placeholder="e.g. Sales Training PDF 2025"
                    value={newBookTitle}
                    onChange={e => setNewBookTitle(e.target.value)}
                   />
                 </div>
                 <div>
                   <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block ml-1">Author / Source</label>
                   <input 
                    className={`w-full px-5 py-4 border-2 rounded-2xl focus:outline-none transition-colors font-bold text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' : 'bg-slate-50 border-slate-100 text-slate-900 focus:border-blue-500'}`}
                    placeholder="e.g. Belmont Corporate"
                    value={newBookAuthor}
                    onChange={e => setNewBookAuthor(e.target.value)}
                   />
                 </div>
                 <div>
                   <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block ml-1">Document Content</label>
                   <textarea 
                    required
                    rows={6}
                    className={`w-full px-5 py-4 border-2 rounded-2xl focus:outline-none transition-colors font-medium text-sm leading-relaxed ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' : 'bg-slate-50 border-slate-100 text-slate-900 focus:border-blue-500'}`}
                    placeholder="Paste your PDF text or notes here to generate an interactive study guide..."
                    value={newBookContent}
                    onChange={e => setNewBookContent(e.target.value)}
                   />
                 </div>
                 <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-500/20 active:scale-95 transition-all">
                   Convert to Interactive Workbook
                 </button>
              </form>
           </div>
        </div>
      )}
    </div>
  );
};

export default Library;