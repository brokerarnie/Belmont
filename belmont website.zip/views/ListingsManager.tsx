
import React, { useState } from 'react';
import { View, User, Listing } from '../types';
import { PlusCircle, Home, Trash2, Edit, ArrowLeft, CheckCircle } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  listings: Listing[];
  setListings: React.Dispatch<React.SetStateAction<Listing[]>>;
  user: User | null;
}

const ListingsManager: React.FC<Props> = ({ navigate, listings, setListings, user }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [formData, setFormData] = useState({
    address: '', city: '', price: '', beds: '', baths: '', type: 'Single Family', category: 'sale' as const, description: ''
  });

  const agentListings = listings.filter(l => l.agentInfo?.agentId === user?.id || !l.agentInfo);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newListing: Listing = {
      id: Date.now(),
      address: formData.address,
      city: formData.city,
      zip: '91367',
      price: parseInt(formData.price) || 0,
      beds: parseInt(formData.beds) || 0,
      baths: parseInt(formData.baths) || 0,
      sqft: 2000,
      type: formData.type,
      category: formData.category,
      status: 'Active',
      description: formData.description,
      image: 'https://picsum.photos/seed/home' + Date.now() + '/800/600',
      agentInfo: {
        name: user?.name || 'Agent',
        license: 'DRE #02065145',
        phone: '818-555-0101',
        email: user?.email || '',
        agentId: user?.id
      }
    };
    setListings([newListing, ...listings]);
    setShowAdd(false);
    setFormData({ address: '', city: '', price: '', beds: '', baths: '', type: 'Single Family', category: 'sale', description: '' });
  };

  const deleteListing = (id: number) => {
    if (confirm('Delete this listing?')) {
      setListings(listings.filter(l => l.id !== id));
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 py-12 px-4">
      <div className="max-w-7xl mx-auto">
        <button onClick={() => navigate(View.AGENT_PORTAL)} className="flex items-center text-slate-500 hover:text-slate-800 font-bold mb-8">
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Dashboard
        </button>

        <div className="flex flex-col md:flex-row justify-between items-center mb-12 gap-6">
          <h2 className="text-4xl font-black text-slate-900 tracking-tighter uppercase">My Inventory</h2>
          <button 
            onClick={() => setShowAdd(!showAdd)} 
            className="bg-slate-900 text-white px-8 py-4 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-black transition-all shadow-xl flex items-center gap-2"
          >
            {showAdd ? 'Cancel' : <><PlusCircle className="h-4 w-4" /> Add New Listing</>}
          </button>
        </div>

        {showAdd && (
          <div className="bg-white p-10 rounded-[40px] shadow-2xl border border-slate-200 mb-12 animate-fadeIn">
            <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <div className="md:col-span-2">
                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Street Address</label>
                <input className="w-full p-4 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-blue-500" required value={formData.address} onChange={e=>setFormData({...formData, address: e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">City</label>
                <input className="w-full p-4 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-blue-500" required value={formData.city} onChange={e=>setFormData({...formData, city: e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Price ($)</label>
                <input type="number" className="w-full p-4 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-blue-500" required value={formData.price} onChange={e=>setFormData({...formData, price: e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Beds</label>
                <input type="number" className="w-full p-4 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-blue-500" value={formData.beds} onChange={e=>setFormData({...formData, beds: e.target.value})} />
              </div>
              <div>
                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Baths</label>
                <input type="number" className="w-full p-4 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-blue-500" value={formData.baths} onChange={e=>setFormData({...formData, baths: e.target.value})} />
              </div>
              <div className="md:col-span-3">
                <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Description</label>
                <textarea className="w-full p-4 bg-slate-50 border rounded-2xl focus:ring-2 focus:ring-blue-500 min-h-[100px]" value={formData.description} onChange={e=>setFormData({...formData, description: e.target.value})} />
              </div>
              <button type="submit" className="md:col-span-3 bg-blue-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-blue-500/20">Publish to Classifieds</button>
            </form>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {agentListings.map((listing) => (
            <div key={listing.id} className="bg-white rounded-[40px] shadow-xl border border-slate-100 overflow-hidden group hover:shadow-2xl transition-all">
              <div className="h-56 relative overflow-hidden">
                <img src={listing.image} alt={listing.address} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
                <div className="absolute top-4 right-4 flex gap-2">
                  <span className="bg-white/90 backdrop-blur px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest text-slate-900 shadow-sm border border-slate-200">
                    {listing.status}
                  </span>
                </div>
              </div>
              <div className="p-8">
                <h3 className="text-xl font-black text-slate-900 tracking-tighter mb-1 truncate">{listing.address}</h3>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">{listing.city}</p>
                <div className="text-2xl font-black text-blue-600 mb-6">${listing.price.toLocaleString()}</div>
                <div className="grid grid-cols-3 gap-4 border-t border-slate-50 pt-6">
                  <div className="text-center">
                    <div className="text-sm font-black text-slate-900">{listing.beds}</div>
                    <div className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Beds</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-black text-slate-900">{listing.baths}</div>
                    <div className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">Baths</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-black text-slate-900">{listing.sqft}</div>
                    <div className="text-[8px] font-bold text-slate-400 uppercase tracking-widest">SqFt</div>
                  </div>
                </div>
                <div className="mt-8 flex gap-3">
                  <button className="flex-grow bg-slate-100 text-slate-700 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-200 transition">Edit</button>
                  <button onClick={() => deleteListing(listing.id)} className="p-3 bg-red-50 text-red-600 rounded-xl hover:bg-red-100 transition border border-red-100">
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ListingsManager;
