
import React, { useState, useEffect } from 'react';
import { View, User } from '../types';
import { ArrowLeft, Lock, ShieldCheck, RefreshCw, AlertTriangle, ShieldAlert, UserPlus, Mail } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  onLogin: (user: User) => void;
  isAgent: boolean;
}

type AuthStep = 'CREDENTIALS' | 'VERIFY' | 'SUCCESS';

const LoginView: React.FC<Props> = ({ navigate, onLogin, isAgent }) => {
  const [step, setStep] = useState<AuthStep>('CREDENTIALS');
  const [isSignUp, setIsSignUp] = useState(false);
  const [name, setName] = useState('');
  const [email, setEmail] = useState(isAgent ? 'brokerarnie@gmail.com' : '');
  const [password, setPassword] = useState('password');
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const mockValidOtp = "123456";

  const handleCredentialSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    // Simulate server-side verification check
    setTimeout(() => {
      setLoading(false);
      const verifiedList = JSON.parse(localStorage.getItem('belmont_verified_emails') || '[]');
      
      // If it's a professional or a new email, trigger verification
      if (isAgent || !verifiedList.includes(email) || isSignUp) {
        setStep('VERIFY');
      } else {
        completeLogin(true);
      }
    }, 1000);
  };

  const handleOtpChange = (value: string, index: number) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);

    // Auto-focus next
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handleVerifyOtp = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    setTimeout(() => {
      setLoading(false);
      if (otp.join('') === mockValidOtp) {
        completeLogin(true);
      } else {
        setError("Invalid security code. Please try again.");
        setOtp(['', '', '', '', '', '']);
        document.getElementById('otp-0')?.focus();
      }
    }, 1200);
  };

  const completeLogin = (isVerified: boolean) => {
    if (isVerified) {
      const verifiedList = JSON.parse(localStorage.getItem('belmont_verified_emails') || '[]');
      if (!verifiedList.includes(email)) {
        verifiedList.push(email);
        localStorage.setItem('belmont_verified_emails', JSON.stringify(verifiedList));
      }
    }

    onLogin({
      id: isAgent ? '001' : 'user_' + Date.now(),
      name: isSignUp ? name : (isAgent ? 'Arnold Daniels' : email.split('@')[0]),
      email: email,
      role: isAgent ? 'Broker' : 'User',
      isAgent: isAgent,
      isVerified: isVerified
    });
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col p-6 sm:p-12 font-sans relative overflow-hidden">
      {/* Visual Security Background */}
      <div className="absolute inset-0 opacity-5 pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-blue-500 via-transparent to-transparent"></div>
        <div className="grid grid-cols-12 gap-4 h-full p-4">
           {Array.from({ length: 48 }).map((_, i) => (
             <div key={i} className="border border-white/10 rounded-sm"></div>
           ))}
        </div>
      </div>

      <div className="max-w-7xl mx-auto w-full relative z-10">
        <button 
          onClick={() => navigate(View.HOME)} 
          className="group flex items-center space-x-3 text-slate-400 hover:text-white transition-all font-bold text-xs uppercase tracking-widest"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Cancel & Back</span>
        </button>
      </div>

      <div className="flex-grow flex items-center justify-center relative z-10">
        <div className="max-w-md w-full animate-fadeIn">
          
          {step === 'CREDENTIALS' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-10">
              <div className="flex flex-col items-center text-center mb-10">
                <div className="p-4 bg-blue-600/10 rounded-full mb-4 border border-blue-500/20">
                  {isSignUp ? <UserPlus className="h-8 w-8 text-blue-500" /> : <Lock className="h-8 w-8 text-blue-500" />}
                </div>
                <h2 className="text-2xl font-black text-white tracking-tight uppercase">
                  {isSignUp ? 'Create Belmont Account' : (isAgent ? 'Professional Authentication' : 'Secure Member Login')}
                </h2>
                <p className="text-slate-500 text-xs mt-2 font-bold uppercase tracking-widest">
                  {isSignUp ? 'New User Registration' : 'Belmont Specialist Gateway v5.0'}
                </p>
              </div>

              <form onSubmit={handleCredentialSubmit} className="space-y-6">
                <div className="space-y-4">
                  {isSignUp && (
                    <div className="space-y-1">
                      <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Full Name</label>
                      <input 
                        type="text" 
                        required
                        className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-white font-medium transition" 
                        placeholder="Your Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                      />
                    </div>
                  )}
                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Email</label>
                    <input 
                      type="email" 
                      className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-white font-medium transition" 
                      placeholder="email@provider.com"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Password</label>
                    <input 
                      type="password" 
                      className="w-full px-4 py-3 bg-slate-950 border border-slate-800 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-600 text-white font-medium transition" 
                      placeholder="••••••••"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                  </div>
                </div>

                <button 
                  type="submit" 
                  disabled={loading}
                  className="w-full bg-blue-600 hover:bg-blue-500 text-white py-4 rounded-lg font-black uppercase tracking-widest text-xs transition-all shadow-xl shadow-blue-900/20 active:scale-[0.98] flex items-center justify-center gap-3"
                >
                  {loading ? <RefreshCw className="h-4 w-4 animate-spin" /> : isSignUp ? 'Register Account' : 'Log In to Network'}
                </button>
              </form>

              {!isAgent && (
                <div className="mt-6 text-center">
                  <button 
                    onClick={() => setIsSignUp(!isSignUp)}
                    className="text-[10px] font-black uppercase text-blue-500 hover:underline tracking-widest"
                  >
                    {isSignUp ? 'Already have an account? Sign In' : "Don't have an account? Create one"}
                  </button>
                </div>
              )}

              <div className="mt-8 flex items-center justify-center gap-2 text-[9px] font-bold text-slate-600 uppercase tracking-widest border-t border-slate-800 pt-6">
                <ShieldCheck className="h-3 w-3" /> Secure Belmont Connection
              </div>
            </div>
          )}

          {step === 'VERIFY' && (
            <div className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl p-10">
              <div className="flex flex-col items-center text-center mb-8">
                <div className="p-4 bg-amber-500/10 rounded-full mb-4 border border-amber-500/20">
                  <ShieldAlert className="h-8 w-8 text-amber-500" />
                </div>
                <h2 className="text-xl font-black text-white tracking-tight uppercase">Verification Required</h2>
                <p className="text-slate-400 text-sm mt-3 leading-relaxed">
                  We sent a 6-digit security code to <span className="text-blue-400 font-bold">{email}</span>. Please enter it below to authorize this session.
                </p>
                <div className="mt-2 text-[10px] font-mono text-amber-500/80 bg-amber-500/5 px-2 py-0.5 rounded border border-amber-500/10 uppercase">
                  Development Hint: Code is 123456
                </div>
              </div>

              <form onSubmit={handleVerifyOtp} className="space-y-8">
                <div className="flex justify-between gap-2">
                  {otp.map((digit, i) => (
                    <input
                      key={i}
                      id={`otp-${i}`}
                      type="text"
                      maxLength={1}
                      className="w-12 h-14 bg-slate-950 border border-slate-800 rounded-xl text-center text-xl font-black text-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-600 transition-all"
                      value={digit}
                      onChange={(e) => handleOtpChange(e.target.value, i)}
                      onKeyDown={(e) => {
                        if (e.key === 'Backspace' && !digit && i > 0) {
                          document.getElementById(`otp-${i-1}`)?.focus();
                        }
                      }}
                      required
                    />
                  ))}
                </div>

                {error && (
                  <div className="p-3 bg-red-900/20 border border-red-900/40 rounded-lg flex items-center gap-3 text-red-400 text-xs font-bold animate-fadeIn">
                    <AlertTriangle className="h-4 w-4 shrink-0" />
                    {error}
                  </div>
                )}

                <div className="space-y-3">
                  <button 
                    type="submit" 
                    disabled={loading || otp.some(d => !d)}
                    className="w-full bg-blue-600 hover:bg-blue-500 disabled:opacity-30 text-white py-4 rounded-lg font-black uppercase tracking-widest text-xs transition-all shadow-xl shadow-blue-900/20 active:scale-[0.98]"
                  >
                    {loading ? <RefreshCw className="h-4 w-4 animate-spin mx-auto" /> : 'Authorize Identity'}
                  </button>
                  <button 
                    type="button"
                    onClick={() => { setStep('CREDENTIALS'); setOtp(['','','','','','']); }}
                    className="w-full text-[10px] font-black uppercase text-slate-500 hover:text-white transition-colors tracking-widest"
                  >
                    Back to Login
                  </button>
                </div>
              </form>
            </div>
          )}

          <div className="mt-8 text-center">
            <p className="text-[9px] text-slate-700 font-mono uppercase tracking-[0.4em]">
              Belmont Security Protocol 10.2.1-X
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginView;
