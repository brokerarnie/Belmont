
import React, { useEffect } from 'react';
import { View } from '../types';
import { ArrowLeft, ShieldCheck, Info } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

const MlsSearchView: React.FC<Props> = ({ navigate, darkMode = false }) => {
  // Ensure the widget script re-evaluates the page when this view mounts
  useEffect(() => {
    // If the TheMLS widget has an initialization function, we'll try to trigger it
    // Most IDX widgets use an interval or onload listener on the idxFrame
    const frame = document.getElementById('idxFrame') as HTMLIFrameElement;
    if (frame) {
      frame.onload = () => {
        console.log("IDX Frame Loaded");
      };
    }
  }, []);

  return (
    <div className={`min-h-screen flex flex-col transition-colors duration-300 ${darkMode ? 'bg-slate-950' : 'bg-white'}`}>
      {/* Search Header */}
      <div className={`p-4 flex items-center shadow-lg sticky top-24 z-30 transition-colors ${darkMode ? 'bg-slate-900 text-white border-b border-slate-800' : 'bg-slate-900 text-white'}`}>
        <button 
          onClick={() => navigate(View.HOME)} 
          className="flex items-center text-slate-300 hover:text-white font-bold transition-all text-sm uppercase tracking-widest"
        >
          <ArrowLeft className="h-4 w-4 mr-2" /> 
          Back to Directory
        </button>
        <div className="ml-8 border-l border-slate-700 pl-8 flex items-center gap-4">
          <h1 className="text-xl font-black tracking-tight uppercase">Agent Listings Search</h1>
          <div className="hidden md:flex items-center gap-2 bg-blue-500/10 border border-blue-500/20 px-3 py-1 rounded-full">
            <ShieldCheck className="h-3 w-3 text-blue-400" />
            <span className="text-[8px] font-black uppercase tracking-widest text-blue-400">Verified MLS Feed</span>
          </div>
        </div>
      </div>
      
      {/* Information Bar for Users */}
      <div className={`px-4 py-2 border-b flex items-center justify-center gap-2 text-[10px] font-bold uppercase tracking-widest ${darkMode ? 'bg-slate-900/50 border-slate-800 text-slate-500' : 'bg-blue-50 border-blue-100 text-blue-600'}`}>
        <Info className="h-3 w-3" />
        Searching San Fernando Valley & Greater Los Angeles Region
      </div>
      
      {/* IDX Container: Using a flex-grow wrapper with a very large min-height to allow the widget to expand */}
      <div className={`flex-grow w-full relative ${darkMode ? 'bg-slate-950' : 'bg-white'}`} style={{ minHeight: 'calc(100vh - 180px)' }}>
        <iframe 
          id="idxFrame"  
          style={{ 
            padding: 0, 
            margin: 0, 
            paddingTop: '0px', 
            border: '0px solid transparent', 
            backgroundColor: 'transparent',
            width: '100%',
            height: '100%',
            minHeight: '1200px' // Increased min-height to prevent "halfway" cut off
          }} 
          frameBorder="0" 
          scrolling="yes" // Changed to "yes" to ensure usability even if the auto-resize script fails
          src="https://www.themls.com/IDXNET/Default.aspx?wid=eDpmopexkqvS868t23wjvff44sFqsay%2bAmb82%2bflvkYEQL" 
          width="100%" 
          height="100%"
          title="Belmont Agent Listings"
        ></iframe>
      </div>

      {/* Regulatory Footer inside Search */}
      <div className={`p-4 text-center border-t transition-colors ${darkMode ? 'bg-slate-900 border-slate-800 text-slate-600' : 'bg-slate-50 border-slate-200 text-slate-400'}`}>
        <p className="text-[9px] font-black uppercase tracking-widest">
          Listing data provided by TheMLS™ // Information Deemed Reliable But Not Guaranteed
        </p>
      </div>
    </div>
  );
};

export default MlsSearchView;
