
import React, { useState, useEffect } from 'react';
import { View, User, Agent } from '../types';
import { MOCK_AGENTS } from '../constants';
import { 
  UserCircle, MessageCircle, UserPlus, Star, 
  ShieldAlert, Heart, Music, 
  ArrowLeft, Users, Mail, Bell, Search,
  Edit2, Camera, MoreVertical, LogOut, Sun, Moon,
  Play, Pause, CheckCircle2, UserMinus, Pin, Settings, BookOpen, ExternalLink, Trash2,
  ChevronRight, Layout, Share2, Plus, Inbox, Edit3, Reply, Forward, X
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  logout: () => void;
  darkMode?: boolean;
  onToggleDarkMode: () => void;
}

interface Blog {
  id: number;
  title: string;
  date: string;
  excerpt: string;
}

interface PrivateMail {
  id: string;
  from: string;
  subject: string;
  date: string;
  body: string;
  unread: boolean;
  sent?: boolean;
}

const MyMontView: React.FC<Props> = ({ navigate, user, logout, darkMode = false, onToggleDarkMode }) => {
  const [time, setTime] = useState(new Date());
  const [status, setStatus] = useState("Available for referrals!");
  const [isEditingStatus, setIsEditingStatus] = useState(false);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'profile' | 'friends' | 'blogs' | 'mail'>('profile');

  const [activeMailView, setActiveMailView] = useState<'inbox' | 'sent' | 'compose'>('inbox');
  const [inbox, setInbox] = useState<PrivateMail[]>([]);
  const [selectedMail, setSelectedMail] = useState<PrivateMail | null>(null);
  const [replyMode, setReplyMode] = useState(false);
  const [replyContent, setReplyContent] = useState('');
  const [composeTo, setComposeTo] = useState('');
  const [composeSubject, setComposeSubject] = useState('');
  const [composeBody, setComposeBody] = useState('');

  const isOwnProfile = true; 
  const agentIdNum = user?.id || "001";
  const agentName = user?.name || "Professional Specialist";
  
  const [allFriends, setAllFriends] = useState<any[]>([]);
  const [top8Ids, setTop8Ids] = useState<string[]>([]);
  const [blogs, setBlogs] = useState<Blog[]>([]);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const triggerToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleSendPM = () => {
    if (!composeTo || !composeBody) return;
    triggerToast(`Message sent to ${composeTo}!`);
    setActiveMailView('inbox');
    setComposeTo('');
    setComposeSubject('');
    setComposeBody('');
  };

  const handleReply = () => {
    if (!selectedMail || !replyContent) return;
    triggerToast(`Reply sent to ${selectedMail.from}!`);
    setReplyMode(false);
    setReplyContent('');
    setSelectedMail(null);
  };

  const handleInvite = () => {
    const referralLink = `https://belmont.com/join?ref=AGENT${agentIdNum}`;
    navigator.clipboard.writeText(referralLink);
    triggerToast("Professional Referral Link copied!");
  };

  return (
    <div className={`min-h-screen font-sans transition-colors duration-300 pb-12 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#e5e7eb] text-slate-900'}`}>
      {toast && (
        <div className="fixed top-24 right-8 z-[100] animate-fadeIn">
          <div className="bg-[#436ca1] text-white px-6 py-3 border-2 border-white shadow-2xl flex items-center gap-3">
             <div className="bg-white/20 p-1 rounded-full"><CheckCircle2 className="h-4 w-4" /></div>
             <span className="text-xs font-black uppercase tracking-widest">{toast}</span>
          </div>
        </div>
      )}

      <header className="py-4 px-8 flex items-center justify-between bg-black border-b border-slate-800 text-white sticky top-0 z-50 shadow-2xl">
        <div className="flex items-center space-x-6">
          <button 
            onClick={onToggleDarkMode}
            className="text-amber-500 hover:scale-110 active:scale-95 transition-all transform duration-200 focus:outline-none flex items-center justify-center p-1 rounded-full hover:bg-white/5"
            title="Toggle Dark Mode"
          >
            <UserCircle className="h-10 w-10" strokeWidth={1.5} />
          </button>

          <div className="flex flex-col">
            <div className="flex items-baseline space-x-2">
              <button 
                onClick={() => navigate(View.AGENT_PORTAL)}
                className="text-amber-500 font-black text-2xl tracking-tighter hover:text-amber-400 transition-colors"
              >
                BELMONT
              </button>
              <span className="text-slate-400 font-mono text-sm uppercase opacity-80">SPECIALIST {agentIdNum}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-6">
          <button 
            onClick={logout}
            className="px-5 py-2 rounded-md font-bold text-xs transition border bg-slate-900 hover:bg-slate-800 text-slate-100 border-slate-700"
          >
            Log Out
          </button>
        </div>
      </header>

      <div className={`bg-[#436ca1] text-white py-1 transition-colors ${darkMode ? 'bg-blue-900/40' : ''}`}>
        <div className="max-w-4xl mx-auto flex items-center justify-center gap-6 text-[11px] font-bold uppercase tracking-tight">
          <button onClick={() => setActiveTab('profile')} className={`hover:underline ${activeTab === 'profile' ? 'text-amber-300' : ''}`}>Profile</button>
          <span className="opacity-30">|</span>
          <button onClick={() => navigate(View.PROFESSIONALS)} className="hover:underline">Registry</button>
          <span className="opacity-30">|</span>
          <button onClick={handleInvite} className="hover:underline text-amber-300">Share Referral ID</button>
          <span className="opacity-30">|</span>
          <button onClick={() => setActiveTab('mail')} className={`hover:underline ${activeTab === 'mail' ? 'text-amber-300' : ''}`}>Mail</button>
          <span className="opacity-30">|</span>
          <button onClick={() => setActiveTab('blogs')} className={`hover:underline ${activeTab === 'blogs' ? 'text-amber-300' : ''}`}>Field Blog</button>
        </div>
      </div>

      <div className="max-w-5xl mx-auto mt-8 px-4 flex flex-col md:flex-row gap-6 animate-fadeIn">
        
        <div className="w-full md:w-80 space-y-4">
          <div className={`p-4 border shadow-sm transition-colors relative ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}>
            <h1 className={`text-xl font-black mb-4 ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>{agentName}</h1>
            
            <div className="aspect-square bg-slate-100 dark:bg-slate-800 mb-4 border border-slate-300 dark:border-slate-700 overflow-hidden group relative">
              <img src="https://via.placeholder.com/400?text=Registry+Photo" className="w-full h-full object-cover" alt="Profile" />
            </div>

            <div className={`p-3 border transition-colors ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
              <p className="text-[10px] font-black uppercase mb-2">Professional Status:</p>
              <div className="flex items-center justify-between group">
                <p className="text-xs font-medium italic">"{status}"</p>
                <button onClick={() => setIsEditingStatus(true)}><Edit2 className="h-3 w-3 text-slate-400 opacity-0 group-hover:opacity-100" /></button>
              </div>
            </div>

            <div className="mt-6 space-y-4 pt-6 border-t border-slate-200 dark:border-slate-800">
               <div>
                  <label className="text-[9px] font-black uppercase text-slate-500 block mb-1">State License / Bond #</label>
                  <div className="flex items-center justify-between">
                     <span className="text-xs font-mono font-bold">#REG-0028194</span>
                     <Settings className="h-3.5 w-3.5 text-slate-400 cursor-pointer" />
                  </div>
               </div>
               <div>
                  <label className="text-[9px] font-black uppercase text-slate-500 block mb-1">Business Contact</label>
                  <div className="flex items-center justify-between">
                     <span className="text-xs font-bold">(818) 555-0199</span>
                     <Settings className="h-3.5 w-3.5 text-slate-400 cursor-pointer" />
                  </div>
               </div>
            </div>
          </div>
        </div>

        <div className="flex-grow space-y-6">
          {activeTab === 'profile' && (
            <div className={`p-6 border shadow-sm transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}>
              <h2 className={`text-2xl font-black mb-2 tracking-tight ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>
                {agentName} <span className="text-blue-600 font-light">Specialist Profile</span>
              </h2>
              <div className="space-y-8 mt-6">
                <section>
                  <h3 className="text-xs font-black uppercase tracking-widest text-[#ff6600] mb-3 border-b-2 border-[#ff6600]/20 pb-1">Professional Overview:</h3>
                  <p className="text-xs leading-relaxed text-slate-400 italic">No biography provided. Click Edit Profile to add your professional background and service specialties.</p>
                </section>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                   <button className="bg-slate-100 dark:bg-slate-800 p-4 border rounded-xl text-center text-[10px] font-black uppercase tracking-widest hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all">Update Specialties</button>
                   <button className="bg-slate-100 dark:bg-slate-800 p-4 border rounded-xl text-center text-[10px] font-black uppercase tracking-widest hover:bg-blue-50 dark:hover:bg-blue-900/20 transition-all">Edit Service Details</button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'mail' && (
             <div className="p-12 text-center opacity-30 bg-white dark:bg-slate-900 border rounded-2xl">
               <Mail className="h-16 w-16 mx-auto mb-4" />
               <p className="font-black uppercase tracking-widest text-sm">Professional Inbox Empty</p>
             </div>
          )}

          {activeTab === 'blogs' && (
             <div className="p-12 text-center opacity-30 bg-white dark:bg-slate-900 border rounded-2xl">
               <BookOpen className="h-16 w-16 mx-auto mb-4" />
               <p className="font-black uppercase tracking-widest text-sm">No field notes shared yet</p>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MyMontView;
