
import React, { useState, useEffect } from 'react';
import { View, User, Agent } from '../types';
import { MOCK_AGENTS } from '../constants';
import { 
  UserCircle, MessageCircle, UserPlus, Star, 
  Share2, ShieldAlert, Heart, Music, 
  ArrowLeft, Users, Mail, Bell, Search,
  Edit2, Camera, MoreVertical, LogOut, Sun, Moon,
  Play, Pause, CheckCircle2, UserMinus
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  logout: () => void;
  darkMode?: boolean;
  onToggleDarkMode: () => void;
}

const MySpaceView: React.FC<Props> = ({ navigate, user, logout, darkMode = false, onToggleDarkMode }) => {
  const [time, setTime] = useState(new Date());
  const [status, setStatus] = useState("closing deals and taking names!");
  const [isEditingStatus, setIsEditingStatus] = useState(false);
  const [activeTab, setActiveTab] = useState<'profile' | 'friends' | 'mail'>('profile');
  
  // Interactive States
  const [isPlaying, setIsPlaying] = useState(false);
  const [isFriend, setIsFriend] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isBlocked, setIsBlocked] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const triggerToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const agentName = user?.name || "Arnold Daniels";
  const agentId = user?.id || "agent_001";

  // Mock "Top 8" from existing mock agents
  const top8 = MOCK_AGENTS.concat(MOCK_AGENTS).slice(0, 8); // Ensure we have 8

  return (
    <div className={`min-h-screen font-sans transition-colors duration-300 pb-12 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#e5e7eb] text-slate-900'}`}>
      {/* Toast Notification */}
      {toast && (
        <div className="fixed top-24 right-8 z-[100] animate-fadeIn">
          <div className="bg-[#436ca1] text-white px-6 py-3 border-2 border-white shadow-2xl flex items-center gap-3">
             <div className="bg-white/20 p-1 rounded-full"><CheckCircle2 className="h-4 w-4" /></div>
             <span className="text-xs font-black uppercase tracking-widest">{toast}</span>
          </div>
        </div>
      )}

      {/* Primary Black Header (Top Bar) - Matches Agent Dashboard */}
      <header className="py-4 px-8 flex items-center justify-between bg-black border-b border-slate-800 text-white sticky top-0 z-50 shadow-2xl">
        <div className="flex items-center space-x-6">
          <button 
            onClick={onToggleDarkMode}
            className="text-amber-500 hover:scale-110 active:scale-95 transition-all transform duration-200 focus:outline-none flex items-center justify-center p-1 rounded-full hover:bg-white/5"
            title="Toggle Dark Mode"
          >
            <UserCircle className="h-10 w-10" strokeWidth={1.5} />
          </button>

          <div className="flex flex-col">
            <div className="flex items-baseline space-x-2">
              <button 
                onClick={() => navigate(View.AGENT_PORTAL)}
                className="text-amber-500 font-black text-2xl tracking-tighter hover:text-amber-400 transition-colors"
              >
                BELMONT
              </button>
              <span className="text-slate-400 font-mono text-sm uppercase opacity-80">{agentId}</span>
            </div>
            <div className="flex items-center space-x-2 text-[10px] font-mono text-amber-500/80 uppercase">
              <span>{time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}</span>
              <span className="text-slate-700">|</span>
              <span>{time.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: 'numeric' })}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-6">
          <div className="text-right hidden sm:block">
            <span className="text-slate-400 text-xs mr-2 uppercase tracking-widest font-bold">Authenticated:</span>
            <span className="font-bold text-sm text-white">{user?.name || agentId}</span>
          </div>
          <button 
            onClick={logout}
            className="px-5 py-2 rounded-md font-bold text-xs transition border bg-slate-900 hover:bg-slate-800 text-slate-100 border-slate-700"
          >
            Log Out
          </button>
        </div>
      </header>

      {/* Nostalgic MySpace Sub-Nav */}
      <div className={`bg-[#436ca1] text-white py-1 transition-colors ${darkMode ? 'bg-blue-900/40' : ''}`}>
        <div className="max-w-4xl mx-auto flex items-center justify-center gap-6 text-[11px] font-bold uppercase tracking-tight">
          <button onClick={() => navigate(View.HOME)} className="hover:underline">Home</button>
          <span className="opacity-30">|</span>
          <button onClick={() => navigate(View.PROFESSIONALS)} className="hover:underline">Browse</button>
          <span className="opacity-30">|</span>
          <button onClick={() => triggerToast("Invite sent to network!")} className="hover:underline">Invite</button>
          <span className="opacity-30">|</span>
          <button className="hover:underline">Film</button>
          <span className="opacity-30">|</span>
          <button onClick={() => navigate(View.CHAT)} className="hover:underline">Mail</button>
          <span className="opacity-30">|</span>
          <button className="hover:underline">Blog</button>
          <span className="opacity-30">|</span>
          <button onClick={() => navigate(View.GAMES)} className="hover:underline">Games</button>
          <span className="opacity-30">|</span>
          <button onClick={() => navigate(View.FORUMS)} className="hover:underline">Forums</button>
        </div>
      </div>

      <div className="max-w-5xl mx-auto mt-8 px-4 flex flex-col md:flex-row gap-6 animate-fadeIn">
        
        {/* Left Column */}
        <div className="w-full md:w-80 space-y-4">
          <div className={`p-4 border shadow-sm transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}>
            <h1 className={`text-xl font-black mb-4 ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>{agentName}</h1>
            <div className="aspect-square bg-slate-100 dark:bg-slate-800 mb-4 border border-slate-300 dark:border-slate-700 overflow-hidden group relative">
              <img 
                src={user?.isAgent ? "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&q=80&w=400" : "https://via.placeholder.com/400?text=My+Profile"} 
                className="w-full h-full object-cover" 
                alt="Profile"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                 <button onClick={() => triggerToast("Camera module coming soon!")} className="bg-white text-black px-4 py-2 rounded-full text-xs font-bold flex items-center gap-2">
                   <Camera className="h-4 w-4" /> Change Photo
                 </button>
              </div>
            </div>

            <div className="text-[11px] font-bold space-y-1 mb-4">
               <p className={darkMode ? 'text-slate-400' : 'text-slate-500'}>Male</p>
               <p className={darkMode ? 'text-slate-400' : 'text-slate-500'}>34 years old</p>
               <p className={darkMode ? 'text-slate-400' : 'text-slate-500'}>WOODLAND HILLS, CALIFORNIA</p>
            </div>

            <div className={`p-3 border transition-colors ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
              <p className="text-[10px] font-black uppercase mb-2">My Status:</p>
              {isEditingStatus ? (
                <div className="flex gap-1">
                  <input 
                    className="flex-grow p-1 text-xs border rounded" 
                    value={status} 
                    onChange={e => setStatus(e.target.value)}
                    autoFocus
                  />
                  <button onClick={() => { setIsEditingStatus(false); triggerToast("Status Updated!"); }} className="bg-blue-600 text-white px-2 py-0.5 rounded text-[10px] font-bold">OK</button>
                </div>
              ) : (
                <div className="flex items-center justify-between">
                  <p className="text-xs font-medium italic">"{status}"</p>
                  <button onClick={() => setIsEditingStatus(true)}><Edit2 className="h-3 w-3 text-slate-400" /></button>
                </div>
              )}
            </div>

            {/* Interaction Buttons Section */}
            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-800 space-y-2">
               <button 
                onClick={() => navigate(View.CHAT)}
                className="w-full text-left text-[11px] font-bold hover:underline flex items-center gap-2 text-blue-600"
               >
                 <MessageCircle className="h-3 w-3" /> Send Message
               </button>
               <button 
                onClick={() => { setIsFriend(!isFriend); triggerToast(isFriend ? "Removed from Friends" : "Added to Friends!"); }}
                className={`w-full text-left text-[11px] font-bold hover:underline flex items-center gap-2 ${isFriend ? 'text-emerald-600' : 'text-blue-600'}`}
               >
                 {isFriend ? <UserMinus className="h-3 w-3" /> : <UserPlus className="h-3 w-3" />} 
                 {isFriend ? "Unfriend" : "Add to Friends"}
               </button>
               <button 
                onClick={() => { setIsFavorite(!isFavorite); triggerToast(isFavorite ? "Removed from Favorites" : "Added to Favorites!"); }}
                className={`w-full text-left text-[11px] font-bold hover:underline flex items-center gap-2 ${isFavorite ? 'text-amber-500' : 'text-blue-600'}`}
               >
                 <Star className={`h-3 w-3 ${isFavorite ? 'fill-amber-500' : ''}`} /> {isFavorite ? "Remove Favorite" : "Add to Favorites"}
               </button>
               <button 
                onClick={() => { if(window.confirm("Block this agent?")) { setIsBlocked(true); triggerToast("Agent Blocked"); } }}
                className="w-full text-left text-[11px] font-bold hover:underline flex items-center gap-2 text-red-600"
               >
                 <ShieldAlert className="h-3 w-3" /> Block User
               </button>
            </div>
          </div>

          <div className={`p-4 border shadow-sm transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}>
            <h3 className="text-xs font-black uppercase tracking-widest text-[#ff6600] mb-3 border-b border-slate-100 dark:border-slate-800 pb-1">Belmont Details</h3>
            <div className="space-y-3 text-[11px]">
               <div className="flex justify-between">
                 <span className="font-bold">Member Since:</span>
                 <span className={darkMode ? 'text-slate-400' : 'text-slate-600'}>01/2025</span>
               </div>
               <div className="flex justify-between">
                 <span className="font-bold">Total Sales:</span>
                 <span className={darkMode ? 'text-slate-400' : 'text-slate-600'}>$12.4M</span>
               </div>
               <div className="flex justify-between">
                 <span className="font-bold">License:</span>
                 <span className={darkMode ? 'text-slate-400' : 'text-slate-600'}>DRE #02065145</span>
               </div>
               <div className="flex justify-between">
                 <span className="font-bold">Zodiac:</span>
                 <span className={darkMode ? 'text-slate-400' : 'text-slate-600'}>Capricorn</span>
               </div>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="flex-grow space-y-6">
          <div className={`p-6 border shadow-sm transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}>
            <div className="mb-8">
              <h2 className={`text-2xl font-black mb-2 tracking-tight ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>
                {agentName} <span className="text-blue-600 font-light">is in your extended network</span>
              </h2>
              
              {/* NOW PLAYING SECTION */}
              <div className={`p-4 border-2 border-dashed transition-colors relative group/player ${darkMode ? 'bg-slate-800/50 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                <div className="flex items-center gap-3 mb-2">
                  <Music className={`h-4 w-4 ${isPlaying ? 'text-emerald-500 animate-bounce' : 'text-blue-500'}`} />
                  <span className="text-[10px] font-black uppercase tracking-widest">Now Playing</span>
                  {isPlaying && <div className="flex gap-0.5 h-2 items-end"><div className="w-0.5 h-1 bg-blue-500 animate-pulse"></div><div className="w-0.5 h-2 bg-blue-500 animate-pulse delay-75"></div><div className="w-0.5 h-1.5 bg-blue-500 animate-pulse delay-150"></div></div>}
                </div>
                <div className="flex items-center gap-4">
                  <button 
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="w-12 h-12 bg-[#436ca1] text-white rounded shadow-lg flex items-center justify-center transition-transform active:scale-95"
                  >
                    {isPlaying ? <Pause className="h-6 w-6 fill-white" /> : <Play className="h-6 w-6 fill-white ml-1" />}
                  </button>
                  <div>
                    <p className={`text-xs font-black ${darkMode ? 'text-white' : 'text-[#113355]'}`}>The Real Estate Anthem (Remix)</p>
                    <p className={`text-[10px] font-bold ${darkMode ? 'text-slate-500' : 'text-slate-500'}`}>Broker Boyz ft. DJ Closer</p>
                    <div className="mt-1 w-48 h-1 bg-slate-200 dark:bg-slate-700 rounded-full overflow-hidden">
                       <div className={`h-full bg-blue-500 transition-all duration-300 ${isPlaying ? 'w-2/3' : 'w-0'}`}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-8">
              <section>
                <h3 className="text-xs font-black uppercase tracking-widest text-[#ff6600] mb-3 border-b-2 border-[#ff6600]/20 pb-1">About Me:</h3>
                <p className={`text-xs leading-relaxed transition-colors ${darkMode ? 'text-slate-400' : 'text-slate-700'}`}>
                  Specializing in luxury residential properties in the Woodland Hills area. I've been with Belmont since the beginning and love helping new agents find their footing. If you're looking for a mentor or a co-listing partner, hit me up! 🚀
                </p>
              </section>

              <section>
                <h3 className="text-xs font-black uppercase tracking-widest text-[#ff6600] mb-3 border-b-2 border-[#ff6600]/20 pb-1">Who I'd like to meet:</h3>
                <p className={`text-xs leading-relaxed transition-colors ${darkMode ? 'text-slate-400' : 'text-slate-700'}`}>
                  Hardworking professionals, developers looking for hungry listing agents, and anyone who appreciates a good escrow closing party.
                </p>
              </section>

              <section>
                <h3 className="text-xs font-black uppercase tracking-widest text-[#ff6600] mb-3 border-b-2 border-[#ff6600]/20 pb-1">Belmont Interests:</h3>
                <div className="grid grid-cols-2 gap-x-8 gap-y-4 text-xs">
                  <div>
                    <span className="font-bold block text-blue-600 mb-1">General</span>
                    <p className={darkMode ? 'text-slate-500' : 'text-slate-600'}>Real Estate, Golf, Crypto, Classic Cars</p>
                  </div>
                  <div>
                    <span className="font-bold block text-blue-600 mb-1">Music</span>
                    <p className={darkMode ? 'text-slate-500' : 'text-slate-600'}>Lo-fi beats for focused CRM work, 80s Rock</p>
                  </div>
                  <div>
                    <span className="font-bold block text-blue-600 mb-1">Movies</span>
                    <p className={darkMode ? 'text-slate-500' : 'text-slate-600'}>The Big Short, Wall Street, Glengarry Glen Ross</p>
                  </div>
                  <div>
                    <span className="font-bold block text-blue-600 mb-1">Books</span>
                    <p className={darkMode ? 'text-slate-500' : 'text-slate-600'}>Quantum Leap Advantage, Sell or Be Sold</p>
                  </div>
                </div>
              </section>
            </div>
          </div>

          {/* Friend Space - THE TOP 8 */}
          <div className={`p-6 border shadow-sm transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}>
             <div className="flex justify-between items-baseline border-b-2 border-[#ff6600]/20 pb-1 mb-6">
                <h3 className="text-xs font-black uppercase tracking-widest text-[#ff6600]">Friend Space</h3>
                <span className="text-[10px] font-bold text-slate-500">{agentName} has <span className="text-[#ff6600]">142</span> Friends.</span>
             </div>

             <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                {top8.map((friend, i) => (
                  <div key={`${friend.id}-${i}`} className="text-center group cursor-pointer">
                    <p className="text-[10px] font-bold text-blue-600 mb-1 group-hover:underline truncate">{friend.name}</p>
                    <div className="aspect-square bg-slate-200 dark:bg-slate-800 overflow-hidden border border-slate-300 dark:border-slate-700">
                       <img 
                        src={friend.photo || `https://picsum.photos/seed/${friend.id}/100/100`} 
                        className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all" 
                        alt={friend.name}
                       />
                    </div>
                  </div>
                ))}
             </div>

             <div className="mt-6 text-right">
                <button className="text-[10px] font-bold text-blue-600 hover:underline">View All Friends [142]</button>
             </div>
          </div>

          {/* Comment Wall */}
          <div className={`p-6 border shadow-sm transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-300'}`}>
             <div className="border-b-2 border-[#ff6600]/20 pb-1 mb-6">
                <h3 className="text-xs font-black uppercase tracking-widest text-[#ff6600]">Comments</h3>
             </div>
             
             <div className="space-y-4">
                <div className={`p-4 border transition-colors ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                   <div className="flex gap-4">
                      <div className="w-16 h-16 bg-slate-200 shrink-0 border border-slate-300">
                         <img src="https://via.placeholder.com/60" alt="Friend" />
                      </div>
                      <div className="flex-grow">
                         <p className="text-[11px] font-bold text-blue-600 hover:underline cursor-pointer">SarahC</p>
                         <p className="text-[10px] text-slate-500 mb-2">02/04/2025 10:15 AM</p>
                         <p className="text-xs leading-relaxed">Arnie! That CMA report you sent over was pure fire. My client is signing the listing agreement as we speak! Lunch is on me next week. 💸</p>
                      </div>
                   </div>
                </div>

                <div className={`p-4 border transition-colors ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
                   <div className="flex gap-4">
                      <div className="w-16 h-16 bg-slate-200 shrink-0 border border-slate-300">
                         <img src="https://via.placeholder.com/60" alt="Friend" />
                      </div>
                      <div className="flex-grow">
                         <p className="text-[11px] font-bold text-blue-600 hover:underline cursor-pointer">BelmontAdmin</p>
                         <p className="text-[10px] text-slate-500 mb-2">02/03/2025 04:45 PM</p>
                         <p className="text-xs leading-relaxed">Don't forget about the team sync tomorrow at 9 AM in the main boardroom. We're discussing the new commission splits!</p>
                      </div>
                   </div>
                </div>
             </div>

             <div className="mt-6 flex gap-2">
                <textarea 
                  className={`flex-grow p-3 text-xs border focus:outline-none focus:ring-1 focus:ring-blue-500 transition-colors ${
                    darkMode ? 'bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-600' : 'bg-white border-slate-300'
                  }`} 
                  placeholder="Add a comment..." 
                  rows={3}
                />
                <button onClick={() => triggerToast("Comment posted!")} className="bg-[#436ca1] text-white px-6 py-2 rounded-sm text-xs font-bold uppercase tracking-widest h-fit mt-auto">Post</button>
             </div>
          </div>
        </div>
      </div>

      {/* Profile Exit Button */}
      <div className="max-w-5xl mx-auto mt-12 px-4 flex justify-center">
         <button 
           onClick={() => navigate(View.AGENT_PORTAL)}
           className={`px-8 py-3 rounded-full font-black uppercase tracking-[0.2em] text-xs transition-all flex items-center gap-2 border shadow-lg ${
             darkMode ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-100' : 'bg-white border-slate-200 text-slate-500 hover:text-slate-800'
           }`}
         >
           <ArrowLeft className="h-4 w-4" /> Exit MySpace
         </button>
      </div>
    </div>
  );
};

export default MySpaceView;
