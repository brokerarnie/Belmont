
import React, { useState, useRef } from 'react';
import { View } from '../types';
import { 
  ArrowLeft, Mail, Lock, CheckCircle, Home, Building, Building2, Layers, 
  LayoutGrid, PlusSquare, Square, CheckSquare, Image as ImageIcon,
  MapPin, Eye, Edit3, Trash2, Camera, ChevronRight, Wind, Zap,
  Dog, Cat, Accessibility, Plus, Sun, ShoppingCart, Key, Users
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

type PostStep = 'intro' | 'account' | 'details' | 'preview' | 'success';

const PostProperty: React.FC<Props> = ({ navigate, darkMode = false }) => {
  const [step, setStep] = useState<PostStep>('intro');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isCompressing, setIsCompressing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Form State matching search filters
  const [formData, setFormData] = useState({
    address: '',
    city: '',
    zip: '',
    price: '',
    beds: '',
    baths: '',
    sqft: '',
    primaryType: 'Apartment',
    intent: 'lease', // 'lease' or 'buy'
    otherUnitsOnLot: 'no',
    category: 'rentals',
    rentPeriod: 'monthly',
    amenities: {
      privateRoom: false,
      privateBath: false,
      catsOk: false,
      dogsOk: false,
      furnished: false,
      noSmoking: false,
      wheelchair: false,
      ac: false,
      evCharging: false,
      solar: false,
    },
    laundry: [] as string[],
    parking: [] as string[],
    photos: [] as string[], // Base64 compressed strings
  });

  // Categories updated to remove redundants matching Marketplace view
  const categories = [
    { label: 'Parking & Storages', value: 'parking' },
    { label: 'Office & Commercial', value: 'office' },
    { label: 'Rooms & Shares', value: 'rooms' },
    { label: 'Sublets & Temporary', value: 'sublets' },
    { label: 'Vacation Rentals', value: 'vacation' },
  ];

  const laundryOptions = ['w/d in unit', 'w/d hookups', 'laundry in bldg', 'laundry on site', 'no laundry on site'];
  // Removed valet parking
  const parkingOptions = ['carport', 'attached garage', 'detached garage', 'off-street parking', 'street parking', 'no parking'];

  // Image Compression Utility
  const compressImage = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = (event) => {
        const img = new Image();
        img.src = event.target?.result as string;
        img.onload = () => {
          const canvas = document.createElement('canvas');
          const MAX_WIDTH = 1200;
          const MAX_HEIGHT = 1200;
          let width = img.width;
          let height = img.height;

          if (width > height) {
            if (width > MAX_WIDTH) {
              height *= MAX_WIDTH / width;
              width = MAX_WIDTH;
            }
          } else {
            if (height > MAX_HEIGHT) {
              width *= MAX_HEIGHT / height;
              height = MAX_HEIGHT;
            }
          }

          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          // Compress to JPEG with 60% quality
          const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
          resolve(dataUrl);
        };
      };
    });
  };

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;
    
    setIsCompressing(true);
    const compressedPhotos: string[] = [];
    for (let i = 0; i < files.length; i++) {
      const compressed = await compressImage(files[i]);
      compressedPhotos.push(compressed);
    }
    setFormData(prev => ({ ...prev, photos: [...prev.photos, ...compressedPhotos] }));
    setIsCompressing(false);
  };

  const removePhoto = (index: number) => {
    setFormData(prev => ({ ...prev, photos: prev.photos.filter((_, i) => i !== index) }));
  };

  const handleNext = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === 'account') setStep('details');
    else if (step === 'details') setStep('preview');
    else if (step === 'preview') setStep('success');
  };

  const toggleAmenity = (key: keyof typeof formData.amenities) => {
    setFormData(prev => ({
      ...prev,
      amenities: { ...prev.amenities, [key]: !prev.amenities[key] }
    }));
  };

  const toggleMulti = (key: 'laundry' | 'parking', value: string) => {
    setFormData(prev => ({
      ...prev,
      [key]: prev[key].includes(value) 
        ? prev[key].filter(v => v !== value) 
        : [...prev[key], value]
    }));
  };

  return (
    <div className={`min-h-screen py-12 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'}`}>
      <div className="max-w-4xl mx-auto">
        <button 
          onClick={() => navigate(View.HOME)} 
          className={`flex items-center font-bold mb-8 transition-all ${darkMode ? 'text-slate-400 hover:text-slate-100' : 'text-slate-500 hover:text-slate-800'}`}
        >
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Directory
        </button>

        <div className={`rounded-3xl shadow-2xl border overflow-hidden transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          {/* Form Progress Header */}
          <div className={`border-b p-6 flex flex-col md:flex-row justify-between items-center gap-4 transition-colors ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
            <div>
              <h1 className="text-xl font-black uppercase tracking-tighter">List Property Intelligence</h1>
              <p className="text-[10px] font-bold text-blue-500 uppercase tracking-widest">Step: {step === 'details' ? 'Specifications' : step === 'preview' ? 'Final Review' : 'Identity'}</p>
            </div>
            <div className="flex gap-2">
               {['account', 'details', 'preview'].map((s, idx) => (
                 <div key={s} className={`h-1.5 w-12 rounded-full transition-all ${
                   (step === 'success' || (idx === 0 && step !== 'intro') || (idx === 1 && (step === 'details' || step === 'preview')) || (idx === 2 && step === 'preview')) ? 'bg-blue-600' : (darkMode ? 'bg-slate-700' : 'bg-slate-200')
                 }`} />
               ))}
            </div>
          </div>

          <div className="p-8 md:p-12">
            {step === 'intro' && (
              <div className="animate-fadeIn max-w-2xl mx-auto text-center">
                <div className="p-4 bg-blue-600/10 rounded-3xl w-fit mx-auto mb-6">
                   <Home className="h-12 w-12 text-blue-600" />
                </div>
                <h2 className="text-3xl font-black mb-4 uppercase tracking-tighter">Marketplace Onboarding</h2>
                <p className={`mb-10 leading-relaxed font-medium ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>
                  Post your residential or commercial property to the Belmont ecosystem. 
                  Our advanced filtering system ensures your listing is found by the most qualified tenants and buyers in the Valley.
                </p>
                <button 
                  onClick={() => setStep('account')}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl shadow-blue-500/20 transition-all flex items-center justify-center gap-3"
                >
                  Begin Listing Process <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            )}

            {step === 'account' && (
              <div className="animate-fadeIn max-w-md mx-auto">
                <div className="text-center mb-10">
                   <h2 className="text-2xl font-black uppercase tracking-tighter mb-2">Create Publisher Account</h2>
                   <p className={`text-[10px] font-bold uppercase tracking-widest ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>Verified listing identity required</p>
                </div>
                
                <form onSubmit={handleNext} className="space-y-6">
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block ml-1">Email Address</label>
                    <input type="email" required className={`w-full px-4 py-4 border-2 rounded-2xl focus:outline-none transition-all font-bold text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' : 'bg-slate-50 border-slate-100 text-slate-900 focus:border-blue-500'}`} placeholder="your@email.com" value={email} onChange={e => setEmail(e.target.value)} />
                  </div>
                  <div>
                    <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2 block ml-1">Access Password</label>
                    <input type="password" required className={`w-full px-4 py-4 border-2 rounded-2xl focus:outline-none transition-all font-bold text-sm ${darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' : 'bg-slate-50 border-slate-100 text-slate-900 focus:border-blue-500'}`} placeholder="••••••••" value={password} onChange={e => setPassword(e.target.value)} />
                  </div>
                  <button type="submit" className="w-full bg-slate-900 hover:bg-black text-white py-5 rounded-2xl font-black uppercase tracking-widest text-xs transition-all shadow-xl">
                    Verify Identity & Continue
                  </button>
                </form>
              </div>
            )}

            {step === 'details' && (
              <div className="animate-fadeIn">
                <div className="mb-10 flex items-center justify-between">
                   <div>
                      <h2 className="text-2xl font-black uppercase tracking-tighter">Property Intelligence</h2>
                      <p className={`text-[10px] font-bold uppercase tracking-widest ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>Map all searchable attributes</p>
                   </div>
                   <div className="p-3 bg-blue-600 rounded-2xl shadow-xl shadow-blue-500/20">
                      <LayoutGrid className="h-6 w-6 text-white" />
                   </div>
                </div>

                <form onSubmit={handleNext} className="space-y-12">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                     <div className="space-y-8">
                        <section>
                          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 mb-4 flex items-center gap-2">
                             <LayoutGrid className="h-3 w-3" /> 1. Primary Type
                          </h3>
                          <div className="grid grid-cols-3 gap-2">
                             {[
                               { id: 'Home', icon: <Home className="h-4 w-4" /> },
                               { id: 'Apartment', icon: <Building2 className="h-4 w-4" /> },
                               { id: 'Townhome', icon: <Building className="h-4 w-4" /> }
                             ].map(t => (
                               <button key={t.id} type="button" onClick={() => setFormData({...formData, primaryType: t.id})} className={`py-3 rounded-xl border-2 font-black text-[10px] uppercase transition-all flex flex-col items-center gap-1 ${formData.primaryType === t.id ? 'bg-blue-600 border-blue-600 text-white shadow-lg' : (darkMode ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-slate-50 border-slate-100 text-slate-400')}`}>
                                 {t.icon}
                                 {t.id}
                               </button>
                             ))}
                          </div>
                        </section>

                        <section>
                          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 mb-4 flex items-center gap-2">
                             <Key className="h-3 w-3" /> 2. Intent
                          </h3>
                          <div className="flex gap-2">
                             {[
                               { id: 'lease', label: 'Lease', icon: <Key className="h-3.5 w-3.5" /> },
                               { id: 'buy', label: 'Buy', icon: <ShoppingCart className="h-3.5 w-3.5" /> }
                             ].map(intent => (
                               <button key={intent.id} type="button" onClick={() => setFormData({...formData, intent: intent.id, category: intent.id === 'buy' ? 'sale' : 'rentals'})} className={`flex-1 py-3 rounded-xl border-2 font-black text-[10px] uppercase flex items-center justify-center gap-2 transition-all ${formData.intent === intent.id ? 'bg-blue-600 border-blue-600 text-white shadow-lg' : (darkMode ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-slate-50 border-slate-100 text-slate-400')}`}>
                                 {intent.icon} {intent.label}
                               </button>
                             ))}
                          </div>
                        </section>

                        <section>
                          <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 mb-4 flex items-center gap-2">
                             <Users className="h-3 w-3" /> 3. Anyone else living on the same lot?
                          </h3>
                          <div className="flex gap-2">
                             {['yes', 'no'].map(o => (
                               <button key={o} type="button" onClick={() => setFormData({...formData, otherUnitsOnLot: o})} className={`flex-1 py-3 rounded-xl border-2 font-black text-[10px] uppercase flex items-center justify-center gap-2 transition-all ${formData.otherUnitsOnLot === o ? 'bg-blue-600 border-blue-600 text-white shadow-lg' : (darkMode ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-slate-50 border-slate-100 text-slate-400')}`}>
                                 {formData.otherUnitsOnLot === o ? <CheckSquare className="h-3.5 w-3.5" /> : <Square className="h-3.5 w-3.5" />} {o}
                               </button>
                             ))}
                          </div>
                        </section>
                     </div>

                     <section>
                        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 mb-4 flex items-center gap-2">
                           <LayoutGrid className="h-3 w-3" /> 4. Marketplace Category
                        </h3>
                        <div className="grid grid-cols-1 gap-2 max-h-[160px] overflow-y-auto scrollbar-hide pr-2">
                           {categories.map(cat => (
                             <button key={cat.value} type="button" onClick={() => setFormData({...formData, category: cat.value})} className={`p-3 text-left rounded-xl border-2 font-black text-[10px] uppercase transition-all ${formData.category === cat.value ? 'bg-blue-900/30 border-blue-600 text-blue-400 shadow-md' : (darkMode ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-slate-50 border-slate-100 text-slate-600')}`}>
                                {cat.label}
                             </button>
                           ))}
                        </div>
                     </section>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                     <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Street Address</label>
                        <input required className={`w-full p-4 border-2 rounded-2xl focus:outline-none transition-all font-bold text-xs ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-100'}`} value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} />
                     </div>
                     <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">City</label>
                        <input required className={`w-full p-4 border-2 rounded-2xl focus:outline-none transition-all font-bold text-xs ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-100'}`} value={formData.city} onChange={e => setFormData({...formData, city: e.target.value})} />
                     </div>
                     <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Zip Code</label>
                        <input required className={`w-full p-4 border-2 rounded-2xl focus:outline-none transition-all font-bold text-xs ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-100'}`} value={formData.zip} onChange={e => setFormData({...formData, zip: e.target.value})} />
                     </div>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                     <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Price ($)</label>
                        <input type="number" required className={`w-full p-4 border-2 rounded-2xl focus:outline-none font-black text-xs ${darkMode ? 'bg-slate-950 border-slate-800 text-blue-500' : 'bg-slate-50 border-slate-100 text-blue-600'}`} value={formData.price} onChange={e => setFormData({...formData, price: e.target.value})} />
                     </div>
                     <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Beds</label>
                        <input type="number" className={`w-full p-4 border-2 rounded-2xl focus:outline-none font-black text-xs ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-100'}`} value={formData.beds} onChange={e => setFormData({...formData, beds: e.target.value})} />
                     </div>
                     <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Baths</label>
                        <input type="number" className={`w-full p-4 border-2 rounded-2xl focus:outline-none font-black text-xs ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-100'}`} value={formData.baths} onChange={e => setFormData({...formData, baths: e.target.value})} />
                     </div>
                     <div className="space-y-2">
                        <label className="text-[10px] font-black uppercase text-slate-500 tracking-widest ml-1">Sq Ft</label>
                        <input type="number" className={`w-full p-4 border-2 rounded-2xl focus:outline-none font-black text-xs ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-100'}`} value={formData.sqft} onChange={e => setFormData({...formData, sqft: e.target.value})} />
                     </div>
                  </div>

                  {/* Photo Upload Section */}
                  <section>
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 mb-6 flex items-center gap-2">
                       <Camera className="h-3 w-3" /> 5. Property Photos
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
                       {formData.photos.map((photo, i) => (
                         <div key={i} className="aspect-square relative group rounded-2xl overflow-hidden border-2 border-slate-200 dark:border-slate-800 shadow-sm">
                            <img src={photo} className="w-full h-full object-cover" alt="Property" />
                            <button 
                              type="button" 
                              onClick={() => removePhoto(i)}
                              className="absolute top-2 right-2 p-1.5 bg-red-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              <Trash2 className="h-3 w-3" />
                            </button>
                         </div>
                       ))}
                       <button 
                         type="button"
                         disabled={isCompressing}
                         onClick={() => fileInputRef.current?.click()}
                         className={`aspect-square rounded-2xl border-4 border-dashed border-slate-200 dark:border-slate-800 flex flex-col items-center justify-center gap-2 transition-all hover:border-blue-500 hover:bg-blue-50/10 ${isCompressing ? 'opacity-50 cursor-not-allowed' : ''}`}
                       >
                         {isCompressing ? (
                           <div className="flex flex-col items-center animate-pulse">
                              <Zap className="h-6 w-6 text-blue-500 mb-2 animate-bounce" />
                              <span className="text-[8px] font-black uppercase">Compressing...</span>
                           </div>
                         ) : (
                           <>
                             <Plus className="h-6 w-6 text-slate-400" />
                             <span className="text-[8px] font-black uppercase tracking-widest text-slate-500 text-center">Add Property<br/>Photos</span>
                           </>
                         )}
                         <input type="file" multiple accept="image/*" className="hidden" ref={fileInputRef} onChange={handlePhotoUpload} />
                       </button>
                    </div>
                  </section>

                  {/* Map Preview Section */}
                  <section>
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 mb-4 flex items-center gap-2">
                       <MapPin className="h-3 w-3" /> 6. Neighborhood Location
                    </h3>
                    <div className={`w-full h-48 rounded-[32px] border-2 overflow-hidden relative transition-colors ${darkMode ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'}`}>
                       <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(#4a4a4a 1px, transparent 0)', backgroundSize: '20px 20px' }}></div>
                       <div className="absolute inset-0 flex items-center justify-center">
                          {formData.address ? (
                            <div className="relative animate-bounce">
                               <MapPin className="h-10 w-10 text-red-600 fill-red-600/20" />
                               <div className="absolute -top-12 left-1/2 -translate-x-1/2 bg-white dark:bg-slate-900 border-2 px-3 py-1 rounded-full shadow-xl whitespace-nowrap">
                                  <p className="text-[9px] font-black uppercase text-blue-600">{formData.address}</p>
                               </div>
                            </div>
                          ) : (
                            <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest">Enter address to preview map position</p>
                          )}
                       </div>
                    </div>
                  </section>

                  {/* Amenities */}
                  <section>
                    <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 mb-6 flex items-center gap-2">
                       <PlusSquare className="h-3 w-3" /> 7. Searchable Amenities
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                       <AmenityToggle label="Cats OK" icon={<Cat className="h-3.5 w-3.5" />} active={formData.amenities.catsOk} onClick={() => toggleAmenity('catsOk')} darkMode={darkMode} />
                       <AmenityToggle label="Dogs OK" icon={<Dog className="h-3.5 w-3.5" />} active={formData.amenities.dogsOk} onClick={() => toggleAmenity('dogsOk')} darkMode={darkMode} />
                       <AmenityToggle label="Furnished" active={formData.amenities.furnished} onClick={() => toggleAmenity('furnished')} darkMode={darkMode} />
                       <AmenityToggle label="A/C" icon={<Wind className="h-3.5 w-3.5" />} active={formData.amenities.ac} onClick={() => toggleAmenity('ac')} darkMode={darkMode} />
                       <AmenityToggle label="EV Charging" icon={<Zap className="h-3.5 w-3.5" />} active={formData.amenities.evCharging} onClick={() => toggleAmenity('evCharging')} darkMode={darkMode} />
                       <AmenityToggle label="Solar" icon={<Sun className="h-3.5 w-3.5" />} active={formData.amenities.solar} onClick={() => toggleAmenity('solar')} darkMode={darkMode} />
                       <AmenityToggle label="Wheelchair" icon={<Accessibility className="h-3.5 w-3.5" />} active={formData.amenities.wheelchair} onClick={() => toggleAmenity('wheelchair')} darkMode={darkMode} />
                       <AmenityToggle label="No Smoking" active={formData.amenities.noSmoking} onClick={() => toggleAmenity('noSmoking')} darkMode={darkMode} />
                       <AmenityToggle label="Private Bath" active={formData.amenities.privateBath} onClick={() => toggleAmenity('privateBath')} darkMode={darkMode} />
                       <AmenityToggle label="Private Room" active={formData.amenities.privateRoom} onClick={() => toggleAmenity('privateRoom')} darkMode={darkMode} />
                    </div>
                  </section>

                  {/* Logistics */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                     <section>
                        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 mb-4">Laundry Profile</h3>
                        <div className="flex flex-wrap gap-2">
                           {laundryOptions.map(opt => (
                             <button key={opt} type="button" onClick={() => toggleMulti('laundry', opt)} className={`px-4 py-2 rounded-full border-2 text-[9px] font-black uppercase tracking-widest transition-all ${formData.laundry.includes(opt) ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-100 dark:border-slate-800 text-slate-500'}`}>
                               {opt}
                             </button>
                           ))}
                        </div>
                     </section>
                     <section>
                        <h3 className="text-[10px] font-black uppercase tracking-[0.2em] text-blue-500 mb-4">Parking Profile</h3>
                        <div className="flex flex-wrap gap-2">
                           {parkingOptions.map(opt => (
                             <button key={opt} type="button" onClick={() => toggleMulti('parking', opt)} className={`px-4 py-2 rounded-full border-2 text-[9px] font-black uppercase tracking-widest transition-all ${formData.parking.includes(opt) ? 'bg-blue-600 border-blue-600 text-white' : 'border-slate-100 dark:border-slate-800 text-slate-500'}`}>
                               {opt}
                             </button>
                           ))}
                        </div>
                     </section>
                  </div>

                  <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white py-6 rounded-3xl font-black uppercase tracking-[0.3em] text-sm shadow-2xl shadow-blue-500/30 transition-all active:scale-[0.98] flex items-center justify-center gap-3">
                    <Eye className="h-5 w-5" /> Preview Listing Portfolio
                  </button>
                </form>
              </div>
            )}

            {step === 'preview' && (
              <div className="animate-fadeIn">
                 <div className="text-center mb-12">
                    <h2 className="text-3xl font-black uppercase tracking-tighter mb-2">Final Approval</h2>
                    <p className={`text-[10px] font-bold uppercase tracking-widest ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>Review your property card</p>
                 </div>

                 <div className="max-w-sm mx-auto mb-16">
                    <div className={`rounded-[40px] shadow-2xl border overflow-hidden transition-all duration-300 transform scale-105 ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
                      <div className="h-64 relative overflow-hidden bg-slate-200 dark:bg-slate-800">
                        {formData.photos.length > 0 ? (
                          <img src={formData.photos[0]} className="w-full h-full object-cover" alt="Preview" />
                        ) : (
                          <div className="w-full h-full flex flex-col items-center justify-center text-slate-400">
                             <ImageIcon className="h-10 w-10 mb-2 opacity-20" />
                             <span className="text-[8px] font-black uppercase">No Photos Uploaded</span>
                          </div>
                        )}
                        <div className="absolute top-5 left-5 flex flex-col gap-2">
                          <span className="bg-[#111827]/70 backdrop-blur-md text-white px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-wider">
                            {formData.category}
                          </span>
                        </div>
                      </div>
                      <div className="p-8">
                        <div className={`text-2xl font-black tracking-tight mb-2 ${darkMode ? 'text-blue-400' : 'text-[#111827]'}`}>
                          ${parseInt(formData.price).toLocaleString()}
                        </div>
                        <h3 className={`text-lg font-bold truncate mb-1 ${darkMode ? 'text-slate-100' : 'text-slate-800'}`}>
                          {formData.address}
                        </h3>
                        <p className={`text-[10px] font-extrabold uppercase tracking-widest mb-6 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
                          {formData.city}, CA {formData.zip}
                        </p>
                        
                        <div className={`flex items-center justify-between border-t pt-6 ${darkMode ? 'border-slate-800' : 'border-slate-50'}`}>
                          <div className="flex gap-4">
                            <div className="text-left">
                              <div className={`text-sm font-black leading-none ${darkMode ? 'text-slate-200' : 'text-slate-900'}`}>{formData.beds}</div>
                              <div className={`text-[8px] font-bold uppercase tracking-widest mt-0.5 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`}>Beds</div>
                            </div>
                            <div className="text-left">
                              <div className={`text-sm font-black leading-none ${darkMode ? 'text-slate-200' : 'text-slate-900'}`}>{formData.baths}</div>
                              <div className={`text-[8px] font-bold uppercase tracking-widest mt-0.5 ${darkMode ? 'text-slate-600' : 'text-slate-400'}`}>Baths</div>
                            </div>
                          </div>
                          <span className="text-[8px] font-black text-blue-500 uppercase tracking-widest">LIVE_PREVIEW</span>
                        </div>
                      </div>
                    </div>
                 </div>

                 <div className="flex flex-col sm:flex-row gap-4">
                    <button 
                      onClick={() => setStep('details')}
                      className={`flex-1 py-5 rounded-2xl font-black uppercase tracking-widest text-xs border transition-all flex items-center justify-center gap-2 ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700 hover:text-white' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-slate-800'}`}
                    >
                      <Edit3 className="h-4 w-4" /> Return to Edit
                    </button>
                    <button 
                      onClick={() => setStep('success')}
                      className="flex-[2] bg-emerald-600 hover:bg-emerald-700 text-white py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-xs shadow-xl shadow-emerald-500/20 active:scale-95 transition-all flex items-center justify-center gap-3"
                    >
                      <CheckCircle className="h-5 w-5" /> Approve & Publish Listing
                    </button>
                 </div>
              </div>
            )}

            {step === 'success' && (
              <div className="text-center py-10 animate-fadeIn max-w-lg mx-auto">
                <div className={`h-24 w-24 rounded-full flex items-center justify-center mx-auto mb-8 transition-colors shadow-2xl ${darkMode ? 'bg-green-950/40 text-green-500' : 'bg-green-100 text-green-600'}`}>
                  <CheckCircle className="h-12 w-12" />
                </div>
                <h2 className="text-3xl font-black mb-4 uppercase tracking-tighter">Property Live!</h2>
                <p className={`mb-12 font-medium leading-relaxed ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                  Your listing at <span className="text-blue-500 font-bold">{formData.address}</span> has been indexed. It is now searchable by the entire Belmont Network.
                </p>
                <div className="flex flex-col sm:flex-row gap-4">
                  <button onClick={() => navigate(View.CLASSIFIEDS)} className="flex-1 bg-slate-900 text-white py-4 rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl active:scale-95 transition-all">View Marketplace</button>
                  <button onClick={() => navigate(View.HOME)} className={`flex-1 py-4 rounded-2xl font-black uppercase tracking-widest text-xs border transition-all ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-600'}`}>Return Home</button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

// Internal Helper for cleaner code
const AmenityToggle: React.FC<{ label: string; icon?: React.ReactNode; active: boolean; onClick: () => void; darkMode: boolean }> = ({ label, icon, active, onClick, darkMode }) => (
  <button 
    type="button"
    onClick={onClick}
    className={`flex items-center justify-between p-3 rounded-xl border-2 transition-all ${
      active 
        ? (darkMode ? 'bg-blue-900/40 border-blue-600 text-white' : 'bg-blue-50 border-blue-500 text-blue-900')
        : (darkMode ? 'bg-slate-800 border-slate-700 text-slate-500' : 'bg-white border-slate-100 text-slate-500')
    }`}
  >
     <div className="flex items-center gap-2">
        {icon && <span className={active ? 'text-blue-500' : 'opacity-40'}>{icon}</span>}
        <span className="text-[9px] font-black uppercase tracking-tight truncate">{label}</span>
     </div>
     <div className={`w-3.5 h-3.5 rounded-full border flex items-center justify-center transition-all ${active ? 'bg-blue-500 border-blue-500' : 'border-slate-200 dark:border-slate-800'}`}>
        {active && <div className="w-1.5 h-1.5 bg-white rounded-full" />}
     </div>
  </button>
);

export default PostProperty;
