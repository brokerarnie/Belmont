
import React, { useState, useEffect, useMemo } from 'react';
import { View, Agent, User } from '../types';
import { MOCK_AGENTS } from '../constants';
import { 
  ArrowLeft, Search, Phone, Mail, ShieldCheck, Lock, X, 
  CheckCircle2, Calculator, DollarSign, ExternalLink, 
  TrendingUp, TrendingDown, ArrowUpRight, Percent, RefreshCw, Info, PieChart,
  Building2, MapPin, Activity, HelpCircle, AlertCircle, ShieldAlert,
  DraftingCompass, HardHat, Users, Sparkles, Shield
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  onLogin: (user: User) => void;
  proType: Agent['type'];
  darkMode?: boolean;
}

const ProfessionalsView: React.FC<Props> = ({ navigate, user, onLogin, proType, darkMode = false }) => {
  const [activeTab, setActiveTab] = useState<Agent['type']>(proType);
  const [currentCategory, setCurrentCategory] = useState<string>('all');
  const [professionals, setProfessionals] = useState<Agent[]>(MOCK_AGENTS);
  const [searchTerm, setSearchTerm] = useState('');
  const [showLoginModal, setShowLoginModal] = useState(false);

  // Refinance Lead State
  const [showRefiLeadForm, setShowRefiLeadForm] = useState(false);
  const [refiSubmitted, setRefiSubmitted] = useState(false);
  const [refiData, setRefiData] = useState({
    address: '', name: '', phone: '', email: '', 
    propertyType: 'Residential', loanType: 'Rate & Term', 
    estValue: '', balance: ''
  });

  // Advanced Calculator State (Compact)
  const [showCalculator, setShowCalculator] = useState(false);
  const [calc, setCalc] = useState({ 
    homePrice: 850000, 
    downPayment: 170000, 
    rate: 6.75, 
    term: 30,
    taxes: 885, 
    insurance: 150,
    hoa: 0
  });

  // Mock Rate Data with Month-over-Month comparison
  const ratesData = [
    { label: '30Y Fixed (Reg)', current: '6.625%', lastMonth: '6.450%', direction: 'up' },
    { label: '30Y Jumbo', current: '7.125%', lastMonth: '7.375%', direction: 'down' },
    { label: '15Y Fixed', current: '6.125%', lastMonth: '5.950%', direction: 'up' },
    { label: 'High Balance', current: '6.875%', lastMonth: '6.875%', direction: 'flat' },
    { label: 'FHA 30Y', current: '6.125%', lastMonth: '6.325%', direction: 'down' }
  ];

  const categoriesMap: Record<string, { label: string; value: string }[]> = {
    agent: [
      { label: 'ALL', value: 'all' },
      { label: 'RESIDENTIAL AGENTS', value: 'Residential Agents' },
      { label: 'COMMERCIAL AGENTS', value: 'Commercial Agents' },
      { label: 'LEASING AGENTS', value: 'Leasing Agents' },
      { label: 'BUSINESS SALES/ACQUISITIONS', value: 'Business Sales/Acquisitions' },
    ],
    loan_officer: [
      { label: 'ALL', value: 'all' },
      { label: 'RESIDENTIAL LOAN OFFICERS', value: 'Residential Loan Officers' },
      { label: 'COMMERCIAL LOAN OFFICERS', value: 'Commercial Loan Officers' },
    ],
    insurance_agent: [
      { label: 'ALL', value: 'all' },
      { label: 'HOMEOWNERS INSURANCE', value: 'Homeowners Insurance' },
      { label: 'COMMERCIAL PROPERTY', value: 'Commercial Property' },
      { label: 'LIFE & UMBRELLA', value: 'Life & Umbrella' },
    ],
    architect_engineer: [
      { label: 'ALL', value: 'all' },
      { label: 'RESIDENTIAL DESIGN', value: 'Residential Design' },
      { label: 'COMMERCIAL DESIGN', value: 'Commercial Design' },
      { label: 'ADU SPECIALISTS', value: 'ADU Specialists' },
      { label: 'HISTORICAL PRESERVATION', value: 'Historical Preservation' },
      { label: 'SEISMIC RETROFITTING', value: 'Seismic Retrofitting' },
      { label: 'FOUNDATION ENGINEERING', value: 'Foundation Engineering' },
      { label: 'HILLSIDE CONSTRUCTION', value: 'Hillside Construction' },
    ],
    maid_service: [
      { label: 'ALL', value: 'all' },
      { label: 'RESIDENTIAL CLEANING', value: 'Residential Cleaning' },
      { label: 'COMMERCIAL CLEANING', value: 'Commercial Cleaning' },
      { label: 'MOVE-IN / MOVE-OUT', value: 'Move-in / Move-out' },
      { label: 'POST-CONSTRUCTION', value: 'Post-Construction' },
      { label: 'HOUSEKEEPING', value: 'Maid & Housekeeping' },
    ],
    cpa: [
      { label: 'ALL', value: 'all' },
      { label: 'TAX PLANNING', value: 'Tax Planning' },
      { label: 'REAL ESTATE ACCOUNTING', value: 'Real Estate Accounting' },
      { label: 'AUDIT SERVICES', value: 'Audit Services' },
    ],
    attorney: [
      { label: 'ALL', value: 'all' },
      { label: 'LITIGATION', value: 'Real Estate Litigation' },
      { label: 'TRANSACTIONAL', value: 'Transactional Law' },
      { label: 'LEASES', value: 'Commercial Leases' },
    ],
    contractor: [
      { label: 'ALL', value: 'all' },
      { label: 'GENERAL CONTRACTOR', value: 'General Contractor' },
      { label: 'ELECTRICAL', value: 'Electrical' },
      { label: 'PLUMBING', value: 'Plumbing' },
      { label: 'REMODELING', value: 'Remodeling' },
    ],
    valuation: [
      { label: 'ALL', value: 'all' }
    ]
  };

  useEffect(() => {
    setActiveTab(proType);
    setCurrentCategory('all');
  }, [proType]);

  const filteredPros = useMemo(() => {
    return professionals.filter(pro => {
      const typeMatch = pro.type === activeTab;
      const nameMatch = pro.name.toLowerCase().includes(searchTerm.toLowerCase());
      const catMatch = currentCategory === 'all' || pro.specialties.includes(currentCategory);
      return typeMatch && nameMatch && catMatch;
    });
  }, [professionals, activeTab, searchTerm, currentCategory]);

  const mortgageResults = useMemo(() => {
    const loanAmount = calc.homePrice - calc.downPayment;
    const monthlyRate = (calc.rate / 100) / 12;
    const numberOfPayments = calc.term * 12;
    const pi = loanAmount * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments)) / (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
    const total = pi + calc.taxes + calc.insurance + calc.hoa;
    return {
      pi: pi || 0,
      total: total || 0,
      loanAmount: loanAmount,
      downPercent: Math.round((calc.downPayment / calc.homePrice) * 100)
    };
  }, [calc]);

  const handleProfileClick = () => {
    if (!user || !user.isAgent) {
      setShowLoginModal(true);
    } else {
      navigate(View.AGENT_MYMONT);
    }
  };

  const handleRefiSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRefiSubmitted(true);
  };

  const proTabs = [
    { id: 'agent', label: 'R.E. Agents', icon: <Users className="h-4 w-4" /> },
    { id: 'loan_officer', label: 'Lenders', icon: <DollarSign className="h-4 w-4" /> },
    { id: 'insurance_agent', label: 'Insurance', icon: <Shield className="h-4 w-4" /> },
    { id: 'architect_engineer', label: 'Architects / Engineers', icon: <Building2 className="h-4 w-4" /> },
    { id: 'maid_service', label: 'Cleaning Services', icon: <Sparkles className="h-4 w-4" /> },
    { id: 'contractor', label: 'Contractors', icon: <Building2 className="h-4 w-4" /> },
    { id: 'attorney', label: 'Attorneys', icon: <ShieldCheck className="h-4 w-4" /> },
    { id: 'cpa', label: 'CPAs', icon: <PieChart className="h-4 w-4" /> },
  ];

  return (
    <div className={`min-h-screen py-6 px-4 sm:px-6 lg:px-8 relative transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f8fafc] text-slate-900'}`}>
      <div className="max-w-7xl mx-auto">
        
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end mb-4 gap-4">
          <div>
            <button 
              onClick={() => navigate(View.HOME)} 
              className={`flex items-center font-bold mb-4 text-[10px] uppercase tracking-widest transition-all border px-4 py-1.5 rounded-sm shadow-sm ${
                darkMode ? 'text-slate-400 border-slate-700 bg-slate-900 hover:bg-slate-800' : 'text-slate-50 border-slate-300 bg-white hover:text-slate-700'
              }`}
            >
              <ArrowLeft className="h-3 w-3 mr-2" /> BACK TO DIRECTORY
            </button>
            <h1 className={`text-4xl font-black tracking-tighter uppercase leading-none ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>
              BELMONT <span className="text-blue-600 font-light">{activeTab === 'agent' ? 'real estate agents' : activeTab.replace('_', ' ').replace('maid service', 'cleaning service')}s</span>
            </h1>
          </div>
          
          <div className={`flex items-center gap-4 text-[11px] font-bold uppercase tracking-tighter transition-colors ${darkMode ? 'text-slate-500' : 'text-slate-600'}`}>
             <div className="flex items-center gap-2 pr-4 border-r border-slate-200 dark:border-slate-800 h-4">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span>Registry Hub Active</span>
             </div>
             <p className="hidden md:block">Woodland Hills / San Fernando Valley Region</p>
          </div>
        </div>

        {/* Global Professional Tabs */}
        <div className="flex overflow-x-auto scrollbar-hide gap-1 mb-8 p-1 bg-slate-100 dark:bg-slate-900/50 rounded-xl border border-slate-200 dark:border-slate-800">
           {proTabs.map(tab => (
             <button
               key={tab.id}
               onClick={() => { setActiveTab(tab.id as any); setCurrentCategory('all'); }}
               className={`flex items-center gap-2 px-6 py-3 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                 activeTab === tab.id 
                  ? 'bg-blue-600 text-white shadow-lg' 
                  : 'text-slate-500 hover:text-blue-500 hover:bg-white dark:hover:bg-slate-800'
               }`}
             >
               {tab.icon} {tab.label}
             </button>
           ))}
        </div>

        {/* Live Market Rates Ticker - Loan Officer Exclusive */}
        {activeTab === 'loan_officer' && (
          <div className={`mb-8 w-full border rounded-xl overflow-hidden transition-colors relative h-10 flex items-center ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
            <div className="absolute left-0 top-0 bottom-0 bg-indigo-600 px-4 flex items-center gap-2 z-20 shadow-xl">
               <Activity className="h-3.5 w-3.5 text-white animate-pulse" />
               <span className="text-[9px] font-black text-white uppercase tracking-widest">LIVE_RATES</span>
            </div>
            
            <div className="flex-grow overflow-hidden relative h-full">
              <div className="absolute whitespace-nowrap animate-ticker-reverse flex items-center h-full gap-16 pl-[150px]">
                {[...ratesData, ...ratesData].map((rate, i) => (
                  <div key={i} className="flex items-center gap-4 group">
                    <span className="text-[10px] font-black text-slate-500 uppercase tracking-tighter">{rate.label}:</span>
                    <span className={`text-sm font-black ${darkMode ? 'text-white' : 'text-slate-900'}`}>{rate.current}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Action Bar */}
        <div className={`${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-[#eee] border-slate-300'} border p-4 mb-8 flex flex-col gap-4 animate-fadeIn transition-colors shadow-sm`}>
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="relative flex-grow w-full max-w-md">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-500" />
              <input 
                type="text" 
                placeholder={`Search ${activeTab.replace('_', ' ').replace('maid service', 'cleaning service').replace('/', '')} registry...`} 
                className={`w-full pl-10 pr-4 py-2 border focus:outline-none font-bold text-xs transition-colors ${
                  darkMode ? 'bg-slate-800 border-slate-700 text-slate-200 placeholder-slate-600' : 'bg-white border-slate-400 text-slate-800 placeholder-slate-400'
                }`}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex items-center gap-3 w-full md:w-auto">
              {activeTab === 'loan_officer' && (
                <>
                  <button onClick={() => setShowCalculator(true)} className={`flex-1 md:flex-none border px-5 py-2.5 text-[10px] font-black uppercase transition-all flex items-center justify-center gap-2 rounded-sm shadow-sm ${darkMode ? 'bg-blue-900/30 border-blue-800 text-blue-400 hover:bg-blue-900/50' : 'bg-blue-600 border-blue-700 text-white hover:bg-blue-700'}`}>
                    <Calculator className="h-4 w-4" /> Loan Calculator
                  </button>
                </>
              )}
            </div>
          </div>

          <div className={`flex flex-wrap gap-1 border-t pt-3 ${darkMode ? 'border-slate-800' : 'border-slate-300'}`}>
            {categoriesMap[activeTab]?.map((cat) => (
              <button 
                key={cat.value}
                onClick={() => setCurrentCategory(cat.value)}
                className={`px-4 py-1.5 text-[10px] font-black uppercase tracking-tight transition-all border rounded-sm ${
                  currentCategory === cat.value 
                    ? (darkMode ? 'bg-blue-600 border-blue-600 text-white' : 'bg-slate-900 border-slate-900 text-white')
                    : (darkMode ? 'bg-slate-800 border-slate-700 text-slate-400 hover:bg-slate-700' : 'bg-[#f8f8f8] border-slate-300 text-slate-600 hover:bg-slate-100 shadow-sm')
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Directory Listing */}
        <div className="animate-fadeIn">
          <div className={`flex flex-col border overflow-hidden shadow-xl transition-colors ${darkMode ? 'border-slate-800 bg-slate-900' : 'border-slate-200 bg-white'}`}>
            {filteredPros.length > 0 ? filteredPros.map((pro) => (
              <div key={pro.id} className={`flex flex-col sm:flex-row items-start sm:items-center gap-4 p-6 border-b transition-colors last:border-b-0 group ${darkMode ? 'border-slate-800 hover:bg-slate-800/50' : 'border-slate-100 hover:bg-slate-50'}`}>
                <div className="flex-grow min-w-0">
                  <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                    <h3 className={`text-base font-black tracking-tight ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>{pro.name}</h3>
                    <span className={`text-[11px] font-mono font-bold ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>[{pro.license}]</span>
                    <div className="flex flex-wrap gap-1">
                      {pro.specialties.map((s, i) => (
                        <span key={i} className={`text-[9px] font-black uppercase tracking-widest whitespace-nowrap px-2 py-0.5 border rounded-sm ${
                          darkMode ? 'text-slate-400 bg-slate-800 border-slate-700' : 'text-slate-500 bg-slate-50 border-slate-200'
                        }`}>
                          {s}
                        </span>
                      ))}
                    </div>
                  </div>
                  <p className={`text-[12px] mt-2 leading-relaxed italic max-w-4xl ${darkMode ? 'text-slate-400' : 'text-slate-600'}`}>"{pro.bio}"</p>
                </div>
                <div className="flex gap-2 shrink-0 ml-auto pt-3 sm:pt-0">
                  <button className={`px-5 py-2 text-[10px] font-black border rounded-sm transition-all flex items-center gap-2 uppercase shadow-sm ${darkMode ? 'text-slate-300 border-slate-700 hover:bg-slate-800' : 'text-slate-700 border-slate-300 hover:bg-slate-100'}`}>
                    <Mail className="h-3.5 w-3.5" /> Email
                  </button>
                  <button className={`px-5 py-2 text-[10px] font-black border rounded-sm transition-all flex items-center gap-2 uppercase shadow-sm ${darkMode ? 'text-slate-300 border-slate-700 hover:bg-slate-800' : 'text-slate-700 border-slate-300 hover:bg-slate-100'}`}>
                    <Phone className="h-3.5 w-3.5" /> Call
                  </button>
                </div>
              </div>
            )) : (
              <div className={`py-32 text-center flex flex-col items-center ${darkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
                <Search className={`h-12 w-12 mb-4 opacity-10`} />
                <p className="font-black uppercase tracking-widest text-xs opacity-40">No verified {activeTab === 'agent' ? 'real estate agent' : activeTab.replace('_', ' ').replace('maid service', 'cleaning service')}s found in this sector</p>
              </div>
            )}
          </div>
        </div>

        {/* Refinance Request Modal ... (rest of component) */}
      </div>
      <style>{`
        @keyframes ticker-reverse {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(0%); }
        }
        .animate-ticker-reverse {
          animation: ticker-reverse 40s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default ProfessionalsView;