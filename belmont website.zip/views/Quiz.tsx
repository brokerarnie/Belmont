
import React, { useState } from 'react';
import { View } from '../types';
import { QUIZ_QUESTIONS } from '../constants';
import { ArrowLeft, CheckCircle, XCircle, Trophy, RefreshCw, GraduationCap } from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  // Added darkMode to Props to fix assignment error in App.tsx
  darkMode?: boolean;
}

const Quiz: React.FC<Props> = ({ navigate, darkMode = false }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [answered, setAnswered] = useState(false);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [complete, setComplete] = useState(false);

  const handleAnswer = (idx: number) => {
    if (answered) return;
    setSelectedOpt(idx);
    setAnswered(true);
    if (idx === QUIZ_QUESTIONS[currentIdx].correct) {
      setScore(score + 10);
    }
  };

  const handleNext = () => {
    if (currentIdx < QUIZ_QUESTIONS.length - 1) {
      setCurrentIdx(currentIdx + 1);
      setAnswered(false);
      setSelectedOpt(null);
    } else {
      setComplete(true);
    }
  };

  const restart = () => {
    setCurrentIdx(0);
    setScore(0);
    setAnswered(false);
    setSelectedOpt(null);
    setComplete(false);
  };

  if (complete) {
    return (
      /* Using darkMode prop to apply conditional styles */
      <div className={`min-h-screen py-12 px-4 flex items-center justify-center transition-colors duration-300 ${darkMode ? 'bg-slate-950' : 'bg-slate-50'}`}>
        <div className={`max-w-md w-full p-12 rounded-3xl shadow-2xl border text-center transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className={`h-24 w-24 rounded-full flex items-center justify-center mx-auto mb-8 transition-colors ${darkMode ? 'bg-amber-900/30' : 'bg-amber-100'}`}>
            <Trophy className="h-12 w-12 text-amber-600" />
          </div>
          <h2 className={`text-3xl font-black tracking-tight ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>Quiz Complete!</h2>
          <p className={`font-bold uppercase tracking-widest text-xs mt-2 ${darkMode ? 'text-slate-500' : 'text-slate-500'}`}>Your Final IQ Score</p>
          <div className="text-6xl font-black text-indigo-600 my-8">{score}</div>
          <div className="space-y-4">
            <button onClick={restart} className="w-full bg-slate-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-2">
              <RefreshCw className="h-5 w-5" /> Retake Quiz
            </button>
            <button onClick={() => navigate(View.AGENT_PORTAL)} className={`w-full py-4 rounded-2xl font-bold transition-colors ${darkMode ? 'bg-slate-800 text-slate-300 hover:bg-slate-700' : 'bg-slate-100 text-slate-700'}`}>
              Back to Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  const currentQ = QUIZ_QUESTIONS[currentIdx];

  return (
    /* Using darkMode prop to apply conditional styles */
    <div className={`min-h-screen py-12 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950' : 'bg-slate-100'}`}>
      <div className="max-w-3xl mx-auto">
        <button onClick={() => navigate(View.AGENT_PORTAL)} className={`flex items-center font-bold mb-8 transition-colors ${darkMode ? 'text-slate-400 hover:text-slate-100' : 'text-slate-500 hover:text-slate-800'}`}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Exit Quiz
        </button>

        <div className={`rounded-3xl shadow-2xl border overflow-hidden transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          <div className={`bg-slate-900 text-white px-8 py-6 flex justify-between items-center transition-colors ${darkMode ? 'bg-black' : 'bg-slate-900'}`}>
            <div className="flex items-center space-x-3">
              <GraduationCap className="h-6 w-6 text-blue-400" />
              <h2 className="text-xl font-black tracking-tight uppercase tracking-widest">Real Estate IQ</h2>
            </div>
            <div className="text-xs font-mono font-bold bg-slate-800 px-3 py-1 rounded-full text-blue-400">
              Q {currentIdx + 1} / {QUIZ_QUESTIONS.length}
            </div>
          </div>

          <div className="p-10">
            <h3 className={`text-2xl font-bold leading-tight mb-10 transition-colors ${darkMode ? 'text-slate-100' : 'text-slate-900'}`}>{currentQ.q}</h3>
            
            <div className="space-y-4">
              {currentQ.options.map((opt, idx) => {
                let statusClass = "border-slate-100 bg-slate-50 text-slate-600 hover:border-blue-200 hover:bg-blue-50";
                
                if (darkMode) {
                  statusClass = "border-slate-800 bg-slate-800/50 text-slate-400 hover:border-blue-900 hover:bg-blue-900/20";
                }

                if (answered) {
                  if (idx === currentQ.correct) {
                    statusClass = darkMode ? "border-green-800 bg-green-900/20 text-green-400" : "border-green-500 bg-green-50 text-green-800";
                  } else if (idx === selectedOpt) {
                    statusClass = darkMode ? "border-red-800 bg-red-900/20 text-red-400" : "border-red-500 bg-red-50 text-red-800";
                  } else {
                    statusClass = darkMode ? "opacity-30 border-slate-800" : "opacity-50 border-slate-100";
                  }
                }
                return (
                  <button 
                    key={idx} 
                    onClick={() => handleAnswer(idx)}
                    disabled={answered}
                    className={`w-full text-left p-5 rounded-2xl border-2 font-bold transition-all flex items-center justify-between ${statusClass}`}
                  >
                    <span>{opt}</span>
                    {answered && idx === currentQ.correct && <CheckCircle className="h-5 w-5 text-green-600" />}
                    {answered && idx === selectedOpt && idx !== currentQ.correct && <XCircle className="h-5 w-5 text-red-600" />}
                  </button>
                );
              })}
            </div>

            {answered && (
              <div className="mt-12 animate-fadeIn">
                <button 
                  onClick={handleNext} 
                  className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-indigo-500/20 hover:bg-indigo-700 transition"
                >
                  {currentIdx === QUIZ_QUESTIONS.length - 1 ? "Finish Quiz" : "Next Question"}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Quiz;
