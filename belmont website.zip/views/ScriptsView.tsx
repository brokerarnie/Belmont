
import React, { useState } from 'react';
import { View, User } from '../types';
import { 
  ArrowLeft, FileText, MessageSquare, ThumbsUp, ThumbsDown, 
  Plus, Search, Copy, Share2, Info, ChevronDown, CheckCircle2, PhoneCall, Zap, X, PlusCircle, Users
} from 'lucide-react';

interface ScriptComment {
  id: string;
  author: string;
  text: string;
  date: string;
}

interface Script {
  id: string;
  title: string;
  category: string;
  content: string;
  author: string;
  ups: number;
  downs: number;
  myVote?: 'up' | 'down';
  comments: ScriptComment[];
  isOfficial: boolean;
}

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  darkMode?: boolean;
}

const OFFICIAL_TOM_FERRY_SCRIPTS: Script[] = [
  {
    id: 'tf-past-client-text',
    title: 'Past Client Text',
    category: 'Sphere/Past',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 156, downs: 2, comments: [],
    content: `YOUR TEXT: "Hi (name) the market’s really moving and home values are going up, up, up. Curious about your home’s new value?"\n\nTHEIR TEXT: "Sure, sounds great."\n\nYOUR TEXT: "Wonderful, I’ll put together your home’s value. Have you done any upgrades? Once it’s ready do you want to meet for coffee, or just stop by the house?"\n\n[IF THEY ASK “HOW’S THE MARKET?”]\nYOUR TEXT: "It depends ... it’s different for: buyers, sellers, investors or renters. When’s a good time to talk?"`
  },
  {
    id: 'tf-coi-1',
    title: 'Past Client / Center of Influence #1',
    category: 'Sphere/Past',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 98, downs: 1, comments: [],
    content: `Hi … this is (name) with (company). It’s been a while [OR] I hope you and your family are well.\n\nReal quick, I was wondering if I could help you with any real estate questions you might have. Great!\n\nExamples:\n• Are you curious about the value of your home?\n• Do you want to know what is going on in your neighborhood?\n• Do you want to know general market conditions?\n• Is it time to sell your home?\n• Should you be refinancing now?\n\nAs you know … I want to be your resource for everything real estate related. Please call me if you ever have questions … okay? Terrific!`
  },
  {
    id: 'tf-coi-2',
    title: 'Past Client / Center of Influence #2',
    category: 'Sphere/Past',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 112, downs: 3, comments: [],
    content: `Hi this is (name) with (company). How are you? Terrific!\n\n(Name), I called because I wanted to ask you a favor. I’ve set a goal for myself to help (amount of families) buy or sell a home this year and as you know, referrals are the lifeline of my business.\n\n(Name), can i ask you a question? Great! Would you feel comfortable referring people to me as a real estate agent? Excellent!\n\nWho do you know right now that is looking to buy or sell a home? Great!\n\nWhat are their names and the best number where I can reach them? Super!\n\nStatistics show that four to five people you know will be buying or selling a home this year. Did you know that? Interesting.`
  },
  {
    id: 'tf-expired-door',
    title: 'Expired: Door Knocking',
    category: 'Expired',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 189, downs: 5, comments: [],
    content: `Hi, I’m (name) with (company). I noticed your home didn’t sell ... and I was curious… why it didn’t sell? If we had written an all cash, great terms offer yesterday ... where would you be moving to?\n\n• Is that something you’d still like to do?\n\nI’ve discovered there’s only three reasons a great home like yours doesn’t sell ...\n1. The marketing and exposure on the home wasn’t enough to attract the buyers and agents in the area.\n2. The home didn’t show well or capture the buyer’s emotions ... or\n3. The pricing strategy ... I’m curious ... Where did your agent fail?`
  },
  {
    id: 'tf-expired-phone',
    title: 'Expired: Phone Call',
    category: 'Expired',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 210, downs: 4, comments: [],
    content: `Hi ... I am looking for (name). This is (name) with (company). I noticed your home was no longer posted online ... and I was calling to see ... is it on ... or off the market?\n\n• Are you taking your home off the market?\n• Are you getting a lot of calls?\n• You may be asking yourself ... where were these agents when my home was on the market, right?\n\nIf you had ... sold this home ... where were you moving to?\n\n*If I brought you an all cash buyer, close in 30 days, where would you like to move to?\n\nWhat type of feedback did you get from the people who saw your home? Tell me more about that.`
  },
  {
    id: 'tf-buyer-prequal',
    title: 'Buyer Pre-Qualifying',
    category: 'Buyers',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 144, downs: 0, comments: [],
    content: `What price range are you looking in? (x)\n\nWho has been helping you with your home search? (x) Good for you!\n\nAre you currently renting the property you live in, or do you own? When does your lease end?\n\nDo you need to sell before buying? If yes: Excellent! What we can do is meet to discuss what your home is worth in today’s market ... as well as ... what is available for you to purchase. Would ___ at ___ work for you?\n\nWhen would be a good time for us to meet ... so I can help you find the home you are looking for? Would ___ or ___ at my office work for you? (x) Perfect!`
  },
  {
    id: 'tf-listing-appointment',
    title: 'Listing Appointment Pre-Qualifying',
    category: 'Listings',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 225, downs: 2, comments: [],
    content: `Hi (name) … it’s (name) with (company) … I’m calling to confirm our appointment for (day/time) … does that time still work for you?\n\nI’m committed to getting your property sold at the highest price in the shortest time frame. I want to be 100% prepared before I come out … so I have some additional questions for you:\n\n• Let’s confirm ... when we sell your home... you’re moving to (city), correct?\n• And you want to be there by (time frame) right?\n• Assuming you ... choose me ... to represent you ... how soon can we begin marketing your property?\n• Tell me again... your main reasons for selling this property?\n• How did you determine that price?\n• And ... how much do you owe on the property?`
  },
  {
    id: 'tf-universal-qualifying',
    title: 'Universal Qualifying Questions',
    category: 'General',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 310, downs: 6, comments: [],
    content: `If you sell your home, where are you moving to? Terrific!\n\nHow soon would you like to be there? Tell me about that...\n\nSo, what’s causing you to move to (x)? Tell me more about that.\n\nWho is involved in the process of (x)? How do you feel about it?\n\nWhat has to happen in order for you to?\n\nDo you have a plan “B”... in case this doesn’t work out?\n\nLet’s go ahead and set an appointment... Which is better for you... mornings or afternoons?`
  },
  {
    id: 'tf-open-house-welcome',
    title: 'Open House: Welcome',
    category: 'Open House',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 88, downs: 1, comments: [],
    content: `Welcome … Please come in. I’m (name) with (company) ...\n\nWhat’s your name? Nice to meet you (name)\n\nDo you live in the neighborhood ... or are you out looking at houses today?\n\nThe sellers have asked everyone to sign in ... for protection purposes ... would you sign in please ...\n\nCome in and take a look around ...`
  },
  {
    id: 'tf-fsbo-phone-1',
    title: 'FSBO Phone #1',
    category: 'FSBO',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 198, downs: 12, comments: [],
    content: `Hi, I’m looking for the owner of the home for sale. This is (name) with (company). As an area specialist, my goal is to know about all the homes for sale in the market place for the buyers I’m working with. Do you mind if I ask you a few questions about your property? Excellent!\n\n• Are the rooms a good size? How is the kitchen?\n• Have the bathrooms been remodeled?\n• Would you tell me about the yard?\n• Tell me about your neighborhood: do you feel it’s nice for raising a family?\n\nSounds like you have a great home, why are you selling? Great! Where are you moving? Terrific!`
  },
  {
    id: 'tf-obj-commission',
    title: 'Objection: Discount Commission',
    category: 'Objections',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 412, downs: 15, comments: [],
    content: `"I have a friend in the business who will give me a discount commission. Will you do the same?"\n\nRESPONSE: "No … I would suggest working with your friend instead… (pause) … (Name), I’m curious … is your friend willing to do all the extra work I’m willing to do? And do they have my contacts, resources and skills?"`
  },
  {
    id: 'tf-obj-wait',
    title: 'Objection: Wait 3-6 Months',
    category: 'Objections',
    author: 'Tom Ferry',
    isOfficial: true,
    ups: 345, downs: 5, comments: [],
    content: `"I’m not buying for another three to six months."\n\nRESPONSE: "Great, then it is an excellent time to do some research together. We’ll have time to get to know each other."`
  }
];

const INITIAL_COMMUNITY_SCRIPTS: Script[] = [
  {
    id: 'comm-1',
    title: 'The Valley 5% Peak Hook',
    category: 'Listings',
    author: 'MikeV',
    isOfficial: false,
    ups: 65, downs: 2,
    comments: [{ id: 'rc1', author: 'SarahC', text: 'This is crushing it in Woodland Hills right now.', date: '1d ago' }],
    content: `AGENT: "Hi, I'm calling because we just saw a massive shift in local inventory. Most agents haven't noticed that prices in your specific zip code just hit a 5% peak. If I could show you exactly how to capture that peak value before the spring rush, would you be open to a 5 minute summary?"`
  }
];

const ScriptsView: React.FC<Props> = ({ navigate, user, darkMode = false }) => {
  const [activeTab, setActiveTab] = useState<'community' | 'official'>('community');
  const [scripts, setScripts] = useState<Script[]>([...OFFICIAL_TOM_FERRY_SCRIPTS, ...INITIAL_COMMUNITY_SCRIPTS]);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Form State
  const [newTitle, setNewTitle] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newCat, setNewCat] = useState('General');

  // Comments State
  const [commentText, setCommentText] = useState('');

  const filteredScripts = scripts.filter(s => {
    const matchesTab = activeTab === 'official' ? s.isOfficial : !s.isOfficial;
    const matchesSearch = s.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          s.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          s.category.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesTab && matchesSearch;
  });

  const handleVote = (id: string, type: 'up' | 'down') => {
    setScripts(prev => prev.map(s => {
      if (s.id !== id) return s;
      const newS = { ...s };
      if (s.myVote === type) {
        newS.myVote = undefined;
        if (type === 'up') newS.ups -= 1; else newS.downs -= 1;
      } else {
        if (s.myVote === 'up') newS.ups -= 1;
        if (s.myVote === 'down') newS.downs -= 1;
        newS.myVote = type;
        if (type === 'up') newS.ups += 1; else newS.downs += 1;
      }
      return newS;
    }));
  };

  const handlePostScript = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newContent.trim()) return;
    const ns: Script = {
      id: Date.now().toString(),
      title: newTitle,
      category: newCat,
      content: newContent,
      author: user?.name || 'Belmont Agent',
      ups: 0, downs: 0,
      comments: [],
      isOfficial: false
    };
    setScripts([ns, ...scripts]);
    setNewTitle('');
    setNewContent('');
    setActiveTab('community');
  };

  const handleAddComment = (id: string) => {
    if (!commentText.trim()) return;
    setScripts(prev => prev.map(s => {
      if (s.id !== id) return s;
      return {
        ...s,
        comments: [...s.comments, {
          id: Date.now().toString(),
          author: user?.name || 'Anonymous',
          text: commentText,
          date: 'Just now'
        }]
      };
    }));
    setCommentText('');
  };

  return (
    <div className={`min-h-screen py-10 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f0f4f8] text-slate-900'}`}>
      <div className="max-w-5xl mx-auto">
        
        {/* Back Button */}
        <button 
          onClick={() => navigate(View.AGENT_PORTAL)} 
          className={`flex items-center gap-2 mb-8 px-4 py-2 border rounded-full text-xs font-black uppercase tracking-widest transition-all ${
            darkMode ? 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white' : 'bg-white border-slate-200 text-blue-600 hover:bg-slate-50 shadow-sm'
          }`}
        >
          <ArrowLeft className="h-4 w-4" /> Back to Dashboard
        </button>

        {/* Design matching screenshot */}
        <div className={`rounded-xl border overflow-hidden shadow-sm transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
          
          {/* Tabs - prioritized as Community first */}
          <div className={`flex border-b transition-colors ${darkMode ? 'border-slate-800' : 'border-slate-200'}`}>
            <button 
              onClick={() => setActiveTab('community')}
              className={`flex-1 py-5 text-center text-sm font-black uppercase tracking-[0.1em] transition-all border-r ${
                activeTab === 'community' 
                  ? (darkMode ? 'bg-blue-900/40 text-blue-400 border-b-2 border-b-blue-400' : 'bg-[#fffbeb] text-[#9a3412] border-b-2 border-b-[#9a3412]') 
                  : (darkMode ? 'text-slate-500 hover:bg-slate-800' : 'text-slate-500 hover:bg-slate-50')
              }`}
            >
              Community Scripts
            </button>
            <button 
              onClick={() => setActiveTab('official')}
              className={`flex-1 py-5 text-center text-sm font-black uppercase tracking-[0.1em] transition-all ${
                activeTab === 'official' 
                  ? (darkMode ? 'bg-blue-900/40 text-blue-400 border-b-2 border-b-blue-400' : 'bg-[#fffbeb] text-[#9a3412] border-b-2 border-b-[#9a3412]') 
                  : (darkMode ? 'text-slate-500 hover:bg-slate-800' : 'text-slate-500 hover:bg-slate-50')
              }`}
            >
              Tom Ferry
            </button>
          </div>

          <div className="p-8">
            {/* Share Form - Matching Screenshot UI */}
            {activeTab === 'community' && (
              <div className="mb-12 animate-fadeIn border p-8 rounded-2xl bg-white dark:bg-slate-950 shadow-sm">
                <div className="flex items-center gap-2 mb-6">
                   <PlusCircle className="h-5 w-5 text-emerald-500" />
                   <h3 className="text-lg font-black tracking-tight uppercase">Share a New Script</h3>
                </div>
                <form onSubmit={handlePostScript} className="space-y-4">
                  <input 
                    className={`w-full px-4 py-3 rounded-lg border-2 focus:outline-none transition-colors font-bold text-sm ${
                      darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' : 'bg-white border-slate-100 text-slate-800 focus:border-blue-500'
                    }`}
                    placeholder="Script Title"
                    value={newTitle}
                    onChange={e => setNewTitle(e.target.value)}
                  />
                  <textarea 
                    rows={4}
                    className={`w-full px-4 py-3 rounded-lg border-2 focus:outline-none transition-colors font-medium text-sm ${
                      darkMode ? 'bg-slate-800 border-slate-700 text-white focus:border-blue-600' : 'bg-white border-slate-100 text-slate-800 focus:border-blue-500'
                    }`}
                    placeholder="Write your script here..."
                    value={newContent}
                    onChange={e => setNewContent(e.target.value)}
                  />
                  <div className="flex justify-end">
                    <button type="submit" className="bg-[#111827] text-white px-10 py-3 rounded-lg font-black uppercase text-xs tracking-widest hover:bg-black transition-all active:scale-[0.98] shadow-md">
                      Post Script
                    </button>
                  </div>
                </form>
              </div>
            )}

            {/* List Header */}
            <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-10">
              <h2 className="text-2xl font-black tracking-tighter uppercase flex items-center gap-3">
                {activeTab === 'official' ? <><FileText className="text-amber-500" /> Tom Ferry Official</> : <><Users className="text-blue-500" /> Member Submissions</>}
              </h2>
              <div className="relative w-full md:w-72">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <input 
                  className={`w-full pl-10 pr-4 py-2.5 border rounded-full text-xs font-bold focus:outline-none ${darkMode ? 'bg-slate-800 border-slate-700' : 'bg-slate-50 border-slate-200'}`}
                  placeholder="Search scripts..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                />
              </div>
            </div>

            {/* Content List */}
            <div className="space-y-10">
              {filteredScripts.length > 0 ? filteredScripts.map((script) => (
                <div key={script.id} className={`p-8 rounded-3xl border-2 transition-all group ${darkMode ? 'bg-slate-950 border-slate-800 hover:border-slate-700' : 'bg-white border-slate-50 hover:border-slate-200 shadow-sm'}`}>
                  <div className="flex flex-col lg:flex-row gap-10">
                    
                    {/* Script Body */}
                    <div className="flex-grow">
                      <div className="flex justify-between items-start mb-6">
                        <div>
                          <span className={`text-[9px] font-black uppercase px-2 py-0.5 border rounded-sm tracking-[0.2em] mb-2 inline-block ${darkMode ? 'bg-blue-950/20 text-blue-400 border-blue-900/40' : 'bg-blue-50 text-blue-600 border-blue-100 shadow-sm'}`}>
                            {script.category}
                          </span>
                          <h3 className="text-2xl font-black tracking-tight">{script.title}</h3>
                        </div>
                        <div className="flex gap-2">
                           <button 
                             onClick={() => { navigator.clipboard.writeText(script.content); alert('Copied!'); }}
                             className={`p-3 rounded-xl transition-all border ${darkMode ? 'bg-slate-800 border-slate-700 text-slate-400 hover:text-white' : 'bg-slate-50 border-slate-100 text-slate-400 hover:text-blue-600 shadow-sm'}`}
                             title="Copy Script"
                           >
                             <Copy className="h-4 w-4" />
                           </button>
                        </div>
                      </div>

                      <div className={`p-6 rounded-2xl font-medium text-sm leading-relaxed whitespace-pre-wrap transition-colors ${darkMode ? 'bg-slate-900 text-slate-300' : 'bg-[#fcfdfd] border-2 border-slate-100 text-slate-700 shadow-inner'}`}>
                        {script.content}
                      </div>

                      <div className="mt-8 flex items-center justify-between border-t pt-6 border-slate-100 dark:border-slate-800">
                         <div className="flex items-center gap-3">
                           <div className={`w-8 h-8 rounded-full flex items-center justify-center text-[10px] font-black uppercase ${darkMode ? 'bg-slate-800 text-slate-400' : 'bg-slate-200 text-slate-500'}`}>
                             {script.author[0]}
                           </div>
                           <div className="flex flex-col">
                             <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">Author</span>
                             <span className="text-xs font-black uppercase">{script.author}</span>
                           </div>
                         </div>
                         
                         <div className="flex items-center gap-2">
                            <button 
                              onClick={() => handleVote(script.id, 'up')}
                              className={`px-4 py-2 rounded-xl border-2 flex items-center gap-2 text-[10px] font-black uppercase transition-all active:scale-95 ${script.myVote === 'up' ? 'bg-emerald-500 border-emerald-500 text-white' : (darkMode ? 'border-slate-800 text-slate-500' : 'bg-white border-slate-100 text-slate-400 hover:border-emerald-200')}`}
                            >
                              <ThumbsUp className="h-3.5 w-3.5" /> {script.ups}
                            </button>
                            <button 
                              onClick={() => handleVote(script.id, 'down')}
                              className={`px-4 py-2 rounded-xl border-2 flex items-center gap-2 text-[10px] font-black uppercase transition-all active:scale-95 ${script.myVote === 'down' ? 'bg-red-500 border-red-500 text-white' : (darkMode ? 'border-slate-800 text-slate-500' : 'bg-white border-slate-100 text-slate-400 hover:border-red-200')}`}
                            >
                              <ThumbsDown className="h-3.5 w-3.5" /> {script.downs}
                            </button>
                         </div>
                      </div>
                    </div>

                    {/* Feedback Area */}
                    <div className={`w-full lg:w-80 shrink-0 p-6 border rounded-3xl transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-[#fcfdfd] border-slate-200'}`}>
                       <div className="flex items-center gap-2 mb-6 border-b pb-3 border-slate-100 dark:border-slate-800">
                          <MessageSquare className="h-4 w-4 text-blue-500" />
                          <h4 className="text-[10px] font-black uppercase tracking-widest text-slate-500">Field Notes ({script.comments.length})</h4>
                       </div>
                       
                       <div className="space-y-5 mb-6 max-h-[250px] overflow-y-auto scrollbar-hide">
                          {script.comments.length > 0 ? script.comments.map(c => (
                            <div key={c.id} className="text-xs">
                               <div className="flex justify-between font-black uppercase text-blue-600 mb-1">
                                 <span>{c.author}</span>
                                 <span className="text-[8px] text-slate-400 font-mono tracking-tighter">{c.date}</span>
                               </div>
                               <p className={darkMode ? 'text-slate-400' : 'text-slate-600'}>"{c.text}"</p>
                            </div>
                          )) : (
                            <div className="h-full flex flex-col items-center justify-center text-center opacity-30 py-8">
                               <Info className="h-8 w-8 mb-2" />
                               <p className="text-[10px] font-bold uppercase">No notes yet</p>
                            </div>
                          )}
                       </div>

                       <div className="mt-auto">
                          <div className="flex gap-1">
                             <input 
                               className={`flex-grow px-4 py-2.5 rounded-xl border text-[11px] font-bold focus:outline-none ${darkMode ? 'bg-slate-800 border-slate-700 text-white' : 'bg-white border-slate-200 shadow-inner'}`}
                               placeholder="Add a field note..."
                               value={commentText}
                               onChange={e => setCommentText(e.target.value)}
                             />
                             <button 
                               onClick={() => handleAddComment(script.id)}
                               className="bg-[#111827] text-white p-2.5 rounded-xl hover:bg-black transition-all active:scale-90 shadow-md"
                             >
                                <Plus className="h-4 w-4" />
                             </button>
                          </div>
                       </div>
                    </div>
                  </div>
                </div>
              )) : (
                <div className="py-24 text-center border-4 border-dashed rounded-[40px] opacity-30">
                  <Search className="h-16 w-16 mx-auto mb-4" />
                  <p className="font-black uppercase tracking-widest">No scripts found in this category</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Training Footer */}
        <div className={`mt-20 p-12 border-4 border-double text-center transition-colors rounded-[50px] ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-slate-900 text-white border-white/10 shadow-2xl'}`}>
           <h3 className="text-3xl font-black uppercase tracking-tighter mb-4">Elite Conversion Drills</h3>
           <p className="text-sm font-medium text-slate-300 max-w-2xl mx-auto mb-10 leading-relaxed">
             "Dialogues are meant to be used somewhat loosely. Practice daily so the script becomes natural to you. Mastery of dialogue is the foundation of high-income real estate."
           </p>
           <button 
            onClick={() => navigate(View.AGENT_CHAT)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-12 py-5 rounded-2xl font-black uppercase tracking-[0.2em] text-xs transition-all active:scale-95 shadow-xl shadow-blue-500/20"
           >
             Start Roleplay Session
           </button>
        </div>

        <div className={`mt-20 text-center border-t pt-10 transition-colors ${darkMode ? 'border-slate-900' : 'border-slate-200'}`}>
           <div className={`text-[9px] font-mono uppercase tracking-[0.5em] transition-colors ${darkMode ? 'text-slate-800' : 'text-slate-400'}`}>
             BELMONT_SCRIPT_SYSTEM_v4.5 // REPOSITORY_ACTIVE
           </div>
        </div>
      </div>
    </div>
  );
};

export default ScriptsView;
