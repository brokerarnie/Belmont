
import React, { useState, useMemo } from 'react';
import { View } from '../types';
import { ArrowLeft, FileSpreadsheet, Calculator, Info, ShieldCheck, Printer, Copy, RefreshCw } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

interface Props {
  navigate: (view: View) => void;
  darkMode?: boolean;
}

const SellerNetSheet: React.FC<Props> = ({ navigate, darkMode = false }) => {
  const { t } = useLanguage();
  const [inputs, setInputs] = useState({
    salePrice: 850000,
    mortgageBalance: 425000,
    commissionRate: 5,
    closingCosts: 1.5, // %
    repairsCredits: 0,
    propertyTaxProration: 2500
  });

  const results = useMemo(() => {
    const totalCommission = inputs.salePrice * (inputs.commissionRate / 100);
    const estimatedClosing = inputs.salePrice * (inputs.closingCosts / 100);
    const totalDebits = inputs.mortgageBalance + totalCommission + estimatedClosing + inputs.repairsCredits + inputs.propertyTaxProration;
    const netProceeds = inputs.salePrice - totalDebits;

    return {
      commission: totalCommission,
      closing: estimatedClosing,
      totalDebits,
      net: netProceeds
    };
  }, [inputs]);

  return (
    <div className={`min-h-screen py-10 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f4f7f9] text-slate-900'}`}>
      <div className="max-w-6xl mx-auto">
        <button 
          onClick={() => navigate(View.AGENT_PORTAL)} 
          className={`flex items-center font-bold mb-8 text-[10px] uppercase tracking-widest transition-all border px-3 py-1 rounded-sm ${
            darkMode ? 'text-slate-400 border-slate-700 bg-slate-900 hover:bg-slate-800' : 'text-slate-50 border-slate-300 bg-white hover:text-slate-700 shadow-sm'
          }`}
        >
          <ArrowLeft className="h-3 w-3 mr-2" /> {t('dashboard')}
        </button>

        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-black tracking-tighter uppercase flex items-center gap-3">
              <FileSpreadsheet className="h-10 w-10 text-emerald-600" />
              {t('netSheet')}
            </h1>
            <p className={`text-[10px] font-black uppercase tracking-[0.3em] mt-2 ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>
              Estimated Equity & Net Proceeds Analysis
            </p>
          </div>
          <div className="flex gap-2">
             <button className="p-3 bg-white dark:bg-slate-900 border rounded-xl hover:bg-slate-50 transition-all shadow-sm"><Printer className="h-5 w-5" /></button>
             <button className="p-3 bg-white dark:bg-slate-900 border rounded-xl hover:bg-slate-50 transition-all shadow-sm"><Copy className="h-5 w-5" /></button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5 space-y-6">
            <div className={`p-8 rounded-[32px] border shadow-xl transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
               <h3 className="text-xs font-black uppercase tracking-widest text-slate-500 mb-8 border-b pb-4">Variable Inputs</h3>
               
               <div className="space-y-6">
                  <InputGroup label="Expected Sale Price" value={inputs.salePrice} onChange={(v: any) => setInputs({...inputs, salePrice: v})} prefix="$" />
                  <InputGroup label="Current Mortgage Balance" value={inputs.mortgageBalance} onChange={(v: any) => setInputs({...inputs, mortgageBalance: v})} prefix="$" />
                  <div className="grid grid-cols-2 gap-4">
                    <InputGroup label="Total Commission (%)" value={inputs.commissionRate} onChange={(v: any) => setInputs({...inputs, commissionRate: v})} suffix="%" />
                    <InputGroup label="Est. Closing Costs (%)" value={inputs.closingCosts} onChange={(v: any) => setInputs({...inputs, closingCosts: v})} suffix="%" />
                  </div>
                  <InputGroup label="Repairs / Seller Credits" value={inputs.repairsCredits} onChange={(v: any) => setInputs({...inputs, repairsCredits: v})} prefix="$" />
                  <InputGroup label="Property Tax Prorations" value={inputs.propertyTaxProration} onChange={(v: any) => setInputs({...inputs, propertyTaxProration: v})} prefix="$" />
               </div>

               <div className="mt-10 p-5 rounded-2xl bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/40 flex items-start gap-4">
                  <Info className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                  <p className="text-[10px] font-bold text-amber-700 dark:text-amber-500 leading-relaxed uppercase tracking-wider">
                    Disclaimer: This is an estimate based on current market data. Final net proceeds will be calculated by the escrow officer.
                  </p>
               </div>
            </div>
          </div>

          <div className="lg:col-span-7">
            <div className={`p-10 rounded-[40px] border shadow-2xl transition-colors h-full flex flex-col justify-between ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-100'}`}>
               <div>
                  <div className="flex justify-between items-center mb-10 pb-6 border-b border-black/5 dark:border-white/5">
                     <h3 className="text-2xl font-black uppercase tracking-tighter">Financial Summary</h3>
                     <div className="flex items-center gap-2 px-3 py-1 bg-emerald-500/10 border border-emerald-500/20 rounded-full">
                        <ShieldCheck className="h-4 w-4 text-emerald-500" />
                        <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest">Audit Verified</span>
                     </div>
                  </div>

                  <div className="space-y-6">
                    <SummaryRow label="Gross Sales Price" value={inputs.salePrice} />
                    <SummaryRow label="Mortgage Payoff" value={inputs.mortgageBalance} isDebit />
                    <SummaryRow label={`Total Commission (${inputs.commissionRate}%)`} value={results.commission} isDebit />
                    <SummaryRow label={`Closing Fees (${inputs.closingCosts}%)`} value={results.closing} isDebit />
                    <SummaryRow label="Credits & Tax Adjustments" value={inputs.repairsCredits + inputs.propertyTaxProration} isDebit />
                    
                    <div className={`mt-10 p-10 rounded-3xl border-4 border-double transition-all text-center ${darkMode ? 'bg-slate-950 border-blue-900/40' : 'bg-blue-50 border-blue-100 shadow-inner'}`}>
                       <p className="text-xs font-black text-blue-600 uppercase tracking-[0.2em] mb-3">Estimated Net Proceeds</p>
                       <div className={`text-6xl font-black tracking-tighter ${results.net >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
                          ${results.net.toLocaleString(undefined, {minimumFractionDigits: 0})}
                       </div>
                       <div className="mt-4 flex items-center justify-center gap-2 text-slate-500">
                          <Calculator className="h-4 w-4" />
                          <span className="text-[10px] font-bold uppercase tracking-widest">Calculated Real-Time</span>
                       </div>
                    </div>
                  </div>
               </div>

               <div className="mt-12 flex justify-center">
                  <button onClick={() => setInputs({salePrice: 850000, mortgageBalance: 425000, commissionRate: 5, closingCosts: 1.5, repairsCredits: 0, propertyTaxProration: 2500})} className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-400 hover:text-blue-500 transition-colors">
                     <RefreshCw className="h-3 w-3" /> Reset Sheet
                  </button>
               </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const InputGroup = ({ label, value, onChange, prefix, suffix }: any) => (
  <div>
    <label className="text-[9px] font-black uppercase text-slate-400 tracking-widest mb-2 block ml-1">{label}</label>
    <div className="relative">
      {prefix && <span className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400 font-black text-sm">{prefix}</span>}
      <input 
        type="number"
        className={`w-full p-4 border-2 rounded-2xl focus:outline-none transition-all font-black text-sm ${prefix ? 'pl-8' : 'pl-4'} ${suffix ? 'pr-8' : 'pr-4'} bg-slate-50 border-slate-100 focus:border-blue-500 dark:bg-slate-950 dark:border-slate-800`}
        value={value}
        onChange={(e) => onChange(parseFloat(e.target.value) || 0)}
      />
      {suffix && <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-black text-sm">{suffix}</span>}
    </div>
  </div>
);

const SummaryRow = ({ label, value, isDebit }: any) => (
  <div className="flex justify-between items-center group">
    <span className={`text-xs font-black uppercase tracking-tight transition-colors ${isDebit ? 'text-slate-400' : 'text-slate-600 dark:text-slate-300'}`}>{label}</span>
    <span className={`text-lg font-black tracking-tight ${isDebit ? 'text-red-500' : 'text-slate-900 dark:text-white'}`}>
       {isDebit ? '-' : ''}${value.toLocaleString(undefined, {minimumFractionDigits: 2})}
    </span>
  </div>
);

export default SellerNetSheet;
