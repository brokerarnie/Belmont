
import React, { useState } from 'react';
import { View, User } from '../types';
import { 
  ArrowLeft, Settings, Trash2, ShieldAlert, UserCircle, 
  Bell, Lock, Eye, EyeOff, Save, CheckCircle2, AlertTriangle, X 
} from 'lucide-react';

interface Props {
  navigate: (view: View) => void;
  user: User | null;
  onLogout: () => void;
  darkMode?: boolean;
}

const SettingsView: React.FC<Props> = ({ navigate, user, onLogout, darkMode = false }) => {
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [deleteStep, setDeleteStep] = useState(1);
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  const [settings, setSettings] = useState({
    name: user?.name || '',
    email: user?.email || '',
    notifications: true,
    publicProfile: true,
    twoFactor: user?.isVerified || false
  });

  const handleSave = () => {
    setIsSaving(true);
    setTimeout(() => {
      setIsSaving(false);
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }, 1000);
  };

  const handleDeleteAccount = () => {
    // Clear all local data associated with the user
    localStorage.removeItem('belmont_verified_emails');
    localStorage.removeItem('belmont_payout_pool'); // Example of clearing specific agent data
    onLogout();
    navigate(View.HOME);
  };

  if (!user) {
    navigate(View.HOME);
    return null;
  }

  return (
    <div className={`min-h-screen py-10 px-4 transition-colors duration-300 ${darkMode ? 'bg-slate-950 text-slate-100' : 'bg-[#f4f7f9] text-slate-900'}`}>
      <div className="max-w-4xl mx-auto">
        <button 
          onClick={() => navigate(user.isAgent ? View.AGENT_PORTAL : View.HOME)} 
          className={`flex items-center font-bold mb-8 text-[10px] uppercase tracking-widest transition-all border px-3 py-1 rounded-sm ${
            darkMode ? 'text-slate-400 border-slate-800 bg-slate-900 hover:bg-slate-800' : 'text-slate-500 border-slate-300 bg-white hover:text-slate-700 shadow-sm'
          }`}
        >
          <ArrowLeft className="h-3 w-3 mr-2" /> {user.isAgent ? 'DASHBOARD' : 'HOME'}
        </button>

        <div className="flex items-center gap-4 mb-12">
          <div className="p-3 bg-blue-600 rounded-2xl shadow-lg">
            <Settings className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-black uppercase tracking-tighter">Account Settings</h1>
            <p className={`text-[10px] font-bold uppercase tracking-widest ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>Manage your Belmont identity</p>
          </div>
        </div>

        <div className="space-y-6">
          {/* Profile Section */}
          <section className={`p-8 rounded-[32px] border transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
            <h2 className="text-sm font-black uppercase tracking-widest mb-8 flex items-center gap-2">
              <UserCircle className="h-5 w-5 text-blue-500" /> General Profile
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 mb-2 block">Display Name</label>
                <input 
                  className={`w-full p-4 border rounded-2xl focus:outline-none transition-all font-bold text-sm ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-100'}`}
                  value={settings.name}
                  onChange={e => setSettings({...settings, name: e.target.value})}
                />
              </div>
              <div>
                <label className="text-[10px] font-black uppercase text-slate-500 mb-2 block">Email Address</label>
                <input 
                  disabled
                  className={`w-full p-4 border rounded-2xl transition-all font-bold text-sm opacity-50 cursor-not-allowed ${darkMode ? 'bg-slate-950 border-slate-800 text-white' : 'bg-slate-50 border-slate-100'}`}
                  value={settings.email}
                />
                <p className="text-[8px] font-bold uppercase text-slate-400 mt-2">Email changes require broker authorization</p>
              </div>
            </div>
          </section>

          {/* Privacy Section */}
          <section className={`p-8 rounded-[32px] border transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
            <h2 className="text-sm font-black uppercase tracking-widest mb-8 flex items-center gap-2">
              <Lock className="h-5 w-5 text-amber-500" /> Privacy & Security
            </h2>
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 border rounded-2xl">
                 <div>
                    <p className="text-sm font-bold">Two-Factor Authentication</p>
                    <p className="text-[10px] text-slate-500 font-medium">Add an extra layer of security to your session.</p>
                 </div>
                 <button 
                  onClick={() => setSettings({...settings, twoFactor: !settings.twoFactor})}
                  className={`w-12 h-6 rounded-full transition-all relative ${settings.twoFactor ? 'bg-emerald-500' : 'bg-slate-300'}`}
                 >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.twoFactor ? 'left-7' : 'left-1'}`} />
                 </button>
              </div>
              <div className="flex items-center justify-between p-4 border rounded-2xl">
                 <div>
                    <p className="text-sm font-bold">Public Registry Listing</p>
                    <p className="text-[10px] text-slate-500 font-medium">Allow other specialists and public users to find your profile.</p>
                 </div>
                 <button 
                  onClick={() => setSettings({...settings, publicProfile: !settings.publicProfile})}
                  className={`w-12 h-6 rounded-full transition-all relative ${settings.publicProfile ? 'bg-emerald-500' : 'bg-slate-300'}`}
                 >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${settings.publicProfile ? 'left-7' : 'left-1'}`} />
                 </button>
              </div>
            </div>
          </section>

          {/* Danger Zone */}
          <section className={`p-8 rounded-[32px] border border-red-500/20 transition-colors ${darkMode ? 'bg-red-950/10' : 'bg-red-50'}`}>
            <h2 className="text-sm font-black uppercase tracking-widest mb-6 flex items-center gap-2 text-red-600">
              <ShieldAlert className="h-5 w-5" /> Danger Zone
            </h2>
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="max-w-md">
                 <p className="text-sm font-black text-red-600 uppercase tracking-tight">Delete Account Permanently</p>
                 <p className="text-xs font-medium text-red-500/80 leading-relaxed mt-1">Once you delete your account, there is no going back. All CRM leads, messages, and listings associated with your identity will be wiped from this device's cache.</p>
              </div>
              <button 
                onClick={() => setShowDeleteConfirm(true)}
                className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-red-900/20 transition-all flex items-center gap-2 shrink-0"
              >
                <Trash2 className="h-4 w-4" /> Deactivate / Delete
              </button>
            </div>
          </section>
        </div>

        <div className="mt-12 flex items-center justify-center gap-4">
           <button 
            onClick={handleSave}
            disabled={isSaving}
            className="px-10 py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-2xl font-black uppercase tracking-[0.2em] text-xs shadow-xl transition-all active:scale-95 flex items-center gap-3"
           >
              {isSaving ? 'Synchronizing...' : saveSuccess ? <><CheckCircle2 className="h-5 w-5" /> Saved</> : <><Save className="h-5 w-5" /> Save Changes</>}
           </button>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteConfirm && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
          <div className={`max-w-md w-full p-10 rounded-[40px] shadow-2xl border transition-colors ${darkMode ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
             <div className="text-center">
                <div className="p-4 bg-red-100 rounded-full w-fit mx-auto mb-6">
                   <AlertTriangle className="h-10 w-10 text-red-600" />
                </div>
                <h3 className="text-2xl font-black uppercase tracking-tight mb-2">Final Warning</h3>
                
                {deleteStep === 1 ? (
                  <>
                    <p className="text-slate-500 text-sm font-medium leading-relaxed mb-8">
                      Are you sure you want to deactivate your Belmont account? This will log you out immediately and purge your local data store.
                    </p>
                    <div className="flex flex-col gap-3">
                       <button onClick={() => setDeleteStep(2)} className="w-full py-4 bg-red-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs">Proceed to Deletion</button>
                       <button onClick={() => setShowDeleteConfirm(false)} className="w-full py-4 text-slate-500 font-bold text-xs uppercase tracking-widest">Cancel</button>
                    </div>
                  </>
                ) : (
                  <>
                    <p className="text-red-600 text-sm font-black leading-relaxed mb-8 uppercase tracking-widest">
                      Confirmed. Clicking below will wipe your identity.
                    </p>
                    <div className="flex flex-col gap-3">
                       <button onClick={handleDeleteAccount} className="w-full py-4 bg-red-700 text-white rounded-2xl font-black uppercase tracking-widest text-xs animate-pulse">Confirm Permanent Deletion</button>
                       <button onClick={() => setDeleteStep(1)} className="w-full py-4 text-slate-500 font-bold text-xs uppercase tracking-widest">Wait, Go Back</button>
                    </div>
                  </>
                )}
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsView;
